extends RefCounted

var host
var busy = false
var uncertain = false
var deadline = 0
var next_scan = 0
var last_key = ""
var status = "Choose replacement names, then enable automatic replacement."
const TIERS = ["Exotic", "Rare", "Common", "Epic", "Legendary"]
const TRAIN_LEVEL = 35
const TRAIN_MIN_RATING = 17
var report_member_visits = 0

func completed(player, family: int) -> bool:
	# Fourth evolution can already be owned at level 30; it cannot prove level 35.
	if player != null:
		for member in player.miscrits.values():
			if member != null and member.mId == family and member.level >= TRAIN_LEVEL: return true
	return false

func training_report(player, names: Array) -> Dictionary:
	var report = {"rows":[], "eligible":[], "needs_capture":[]}
	var seen = {}
	var families = {}
	var allowed = {}
	var selected_families = {}
	var report_names = names.duplicate()
	var first_tier = TIERS.size()
	for name in names:
		var entry = host.catalog.by_name.get(name, {})
		if not entry.is_empty():
			allowed[int(entry.id)] = true
			selected_families[int(entry.id)] = true
			var tier = TIERS.find(entry.get("rarity", ""))
			if tier >= 0: first_tier = mini(first_tier, tier)
	if first_tier == TIERS.size(): first_tier = 0
	# Missing selected copies never block a usable owned copy in the next tier.
	# Catalog indexing is small; the roster is still traversed only once.
	for entry in host.catalog.entries:
		var tier = TIERS.find(entry.get("rarity", ""))
		if tier >= first_tier: allowed[int(entry.id)] = true
	report_member_visits = 0
	# Index the roster once, rather than scanning it twice for every selected name.
	if player != null:
		for id in player.miscrits:
			report_member_visits += 1
			var member = player.miscrits[id]
			if member == null or member.id != id: continue
			var family = member.mId
			if not allowed.has(family): continue
			if not families.has(family): families[family] = {"complete":false, "id":-1, "rating":-1.0, "level":0}
			var best = families[family]
			if member.level >= TRAIN_LEVEL:
				best.complete = true
				continue
			if member.level < 1: continue
			var rating = member.get_rating_sum()
			if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18: continue
			if rating > best.rating or (rating == best.rating and (member.level > best.level or (member.level == best.level and id < best.id))):
				best.id = id
				best.rating = rating
				best.level = member.level
	for family in families:
		var best = families[family]
		if selected_families.has(family) or best.complete or best.rating < TRAIN_MIN_RATING: continue
		var entry = host.catalog.by_id.get(family, {})
		if not entry.is_empty(): report_names.append(entry.name.to_lower())
	var lead = null if player == null or player.team.is_empty() else player.miscrits.get(player.team[0])
	for name in report_names:
		var entry = host.catalog.by_name.get(name, {})
		if entry.is_empty() or seen.has(int(entry.id)): continue
		var family = int(entry.id)
		seen[family] = true
		var tier = TIERS.find(entry.get("rarity", ""))
		if tier < 0: tier = TIERS.size()
		var row = {"name":name, "family":family, "tier":tier, "state":"Needs 17+", "id":-1, "rating":-1.0, "level":0, "source":"selected" if selected_families.has(family) else "owned_fallback"}
		if player == null:
			row.state = "Sign in to check collection"
		elif families.get(family, {}).get("complete", false):
			row.state = "Complete"
		else:
			var best = families.get(family, {})
			for key in ["id", "rating", "level"]:
				if best.has(key): row[key] = best[key]
			if row.rating >= TRAIN_MIN_RATING:
				row.state = "Lead kept" if lead != null and row.family == lead.mId else "Ready"
				if row.state == "Ready": report.eligible.append(row)
			else:
				report.needs_capture.append(name)
		report.rows.append(row)
	report.rows.sort_custom(func(a,b): return a.name < b.name if a.tier == b.tier else a.tier < b.tier)
	report.needs_capture = report.rows.filter(func(row): return row.name in report.needs_capture).map(func(row): return row.name)
	report.eligible.sort_custom(func(a,b):
		if a.tier != b.tier: return a.tier < b.tier
		if a.rating != b.rating: return a.rating > b.rating
		if a.level != b.level: return a.level > b.level
		return a.id < b.id)
	return report

func selected_plan(player, names: Array) -> Dictionary:
	# Reuse the existing membership validation, without requesting legacy replacements.
	var result = plan(player, [])
	if result.has("error"): return result
	result.changes = []
	result.unfilled = 0
	var pool = training_report(player, names).eligible.slice(0, 3)
	var wanted = pool.map(func(row): return row.id)
	var available = pool.filter(func(row): return row.id not in player.team.slice(1))
	for slot in range(1, player.team.size()):
		if player.team[slot] in wanted or available.is_empty(): continue
		var chosen = available.pop_front()
		result.after[slot] = chosen.id
		result.changes.append({"slot":slot + 1, "id":chosen.id, "rating":chosen.rating})
	while result.after.size() < 4 and not available.is_empty():
		var chosen = available.pop_front()
		result.after.append(chosen.id)
		result.changes.append({"slot":result.after.size(), "id":chosen.id, "rating":chosen.rating})
	return result

func candidates(player, names: Array) -> Array:
	if player == null: return []
	var allowed = {}
	for name in names:
		var entry = host.catalog.by_name.get(name, {})
		if not entry.is_empty(): allowed[int(entry.id)] = true
	var available = []
	for id in player.miscrits:
		var member = player.miscrits[id]
		if member == null or member.id != id or id in player.team or member.level < 1 or member.level >= 35 or not allowed.has(member.mId): continue
		var rating = member.get_rating_sum()
		if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18: continue
		available.append({"id":id, "rating":rating})
	available.sort_custom(func(a,b): return a.id < b.id if a.rating == b.rating else a.rating > b.rating)
	return available

func plan(player, names: Array) -> Dictionary:
	if player == null or player.team.is_empty() or player.team.size() > 4:
		return {"error":"Team is not loaded; replacement paused."}
	var seen = {}
	var slots = []
	for index in range(player.team.size()):
		var id = player.team[index]
		var member = player.miscrits.get(id)
		if seen.has(id) or member == null or member.id != id:
			return {"error":"Team membership is invalid; replacement paused."}
		seen[id] = true
		if index > 0 and member.level >= 35: slots.append(index)
	var result = {"before":player.team.duplicate(), "after":player.team.duplicate(), "changes":[], "unfilled":slots.size()}
	if slots.is_empty(): return result
	var pool = candidates(player, names)
	for index in range(mini(slots.size(), pool.size())):
		var slot = slots[index]
		result.after[slot] = pool[index].id
		result.changes.append({"slot":slot + 1, "id":pool[index].id, "rating":pool[index].rating})
	result.unfilled = slots.size() - result.changes.size()
	return result

func message(text: String):
	if text == status: return
	status = text
	host.announce("team_rotation", text)

func halt(text: String, unknown: bool = false):
	uncertain = uncertain or unknown
	status = text
	host.stop(text)

func watch_timeout():
	if busy and not uncertain and Time.get_ticks_msec() > deadline:
		halt("Team update timed out. Check your team and reopen the game before restarting.", true)

func ensure_ready(force: bool = false) -> bool:
	if busy or uncertain or not host.enabled: return false
	var selected_training = host.config.get("train_selected", false)
	if not selected_training and not host.config.get("auto_replace_max_level", false): return true
	if Server.Player == null or not host.campaign_connected() or not host.campaign_world_ready() or is_instance_valid(BattleAnimator.battle) or not str(Server.current_battle_id).is_empty(): return false
	var player = Server.Player
	var key = str(player.team) + str(host.config.get("replacement_names", [])) + str(selected_training)
	for id in player.team:
		var member = player.miscrits.get(id)
		key += ":" + str(-1 if member == null else member.level)
	var now = Time.get_ticks_msec()
	if not force and key == last_key and now < next_scan: return true
	last_key = key
	next_scan = now + 1000
	var change = selected_plan(player, host.config.get("replacement_names", [])) if selected_training else plan(player, host.config.get("replacement_names", []))
	if change.has("error"):
		halt(change.error)
		return false
	if change.changes.is_empty():
		if selected_training: message("Training best owned 17+ copies to level 35, then checking the next tier. Slot 1 kept; duplicate families skipped.")
		if change.unfilled > 0: message("No selected, owned Miscrits below level 35 are available. Current teammates kept.")
		return true
	busy = true
	deadline = now + 60000
	message("Selecting %d highest-rated 17+ trainee(s) for slots 2–4." % change.changes.size() if selected_training else "Replacing %d level-35 teammate(s) in slots 2–4 with the highest-rated selected Miscrits." % change.changes.size())
	WorldManager.acquire_move_lock()
	UiManager.block_all_inputs("auto_team_replace")
	var response = await host.request_team_update(change.after)
	UiManager.release_inputs_block("auto_team_replace")
	WorldManager.release_move_lock()
	busy = false
	if Server.Player != player:
		halt("Player changed during team update; check your team before restarting.", true)
		return false
	if not response is Dictionary or response.get("success") != true:
		halt("Team update was rejected or unavailable; automation paused.", not response is Dictionary or response.get("code", 0) != 0)
		return false
	if player.team != change.before and player.team != change.after:
		halt("Team changed during the pending update. Check your team before restarting.", true)
		return false
	for id in change.after:
		if not player.miscrits.has(id):
			halt("Updated team member is missing. Reload the team before restarting.", true)
			return false
	# Match the native Team save: never alter the displayed team before success.
	if player.team != change.after: player.set_prop("team", change.after.duplicate())
	next_scan = 0
	var changes = PackedStringArray()
	for item in change.changes:
		changes.append("slot %d: %s (rating %s)" % [item.slot, player.miscrits[item.id].get_name(), str(item.rating)])
	message("Team updated · " + "; ".join(changes))
	if not host.enabled or uncertain: return false
	if not host.campaign_connected() or not host.campaign_world_ready() or is_instance_valid(BattleAnimator.battle) or not str(Server.current_battle_id).is_empty():
		halt("Team updated, but the world or connection changed. Automation paused.")
		return false
	return true
