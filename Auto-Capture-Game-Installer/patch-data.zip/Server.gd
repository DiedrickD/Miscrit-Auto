extends Node

var client: NakamaClient
var _session: NakamaSession
var socket: NakamaSocket

var Miscrits: Array[Miscrit]
var MiscritDict: Dictionary[int, Miscrit]
var friends: Dictionary[String, Friend] = {}
var Player: Player_
var current_battle_id: String
var spectator: bool
var tournament: bool
var clan: bool

var API_URL = "https://worldofmiscrits.com"
var WS_URL = "cache" # "165.232.71.204"  
var CDN_URL = "https://cdn.worldofmiscrits.com"
var SERVER_IP =  "worldofmiscrits.com"  # "165.232.71.204"  
var SERVER_SCHEME = "https" # "http"
var SERVER_PORT = 443
var LEVEL = NakamaLogger.LOG_LEVEL.ERROR
var dev: bool = false
var staging: bool = false
var active_rpcs: Dictionary[String, bool] = {}
var active_opcodes: Dictionary[int, bool] = {}

var version = "2.23.0"
var EVENT_CURRENCY = "Supplies"

signal reconnected()
signal is_dev()
signal on_friend_remove(user_id: String)
signal on_switch_miscrit()

func _ready():
	if OS.get_cmdline_user_args().has("--mama-hunt") or (OS.get_cmdline_user_args().has("--dynamic-search") or OS.get_cmdline_user_args().has("--auto-capture")) or OS.get_cmdline_user_args().has("--mama-test"):
		_mama_start.call_deferred()
	_study_response_log("logger_ready", {"build": "auto-capture-study-v1"})
	if OS.has_feature("debug"):
		if ProjectSettings.has_setting("Server/address"):
			SERVER_IP = ProjectSettings.get_setting("Server/address")
			SERVER_PORT = ProjectSettings.get_setting("Server/port")
			SERVER_SCHEME = ProjectSettings.get_setting("Server/scheme")
			CDN_URL = ProjectSettings.get_setting("Server/cdn")
			API_URL = ProjectSettings.get_setting("Server/api")
			WS_URL = ""
		if ProjectSettings.has_setting("Server/dev"):
			dev = ProjectSettings.get_setting("Server/dev")
	client = Nakama.create_client("a1c737cc188f54ab3658ba5da0e12ee5", SERVER_IP, int(SERVER_PORT), SERVER_SCHEME, 30, LEVEL)
	if staging:
		await Utils.sleep(0.1)
		is_dev.emit()
	 

func login_ready():
	create_socket()
	socket.closed.connect(_on_socket_close)

func create_socket():
	if WS_URL == "cache":
		WS_URL = DataService.get_cache_key("server")
	if WS_URL:
		socket = Nakama.create_socket(WS_URL, 7350)
	else:
		socket = Nakama.create_socket_from(client)
		
func check_register_session(session: NakamaSession):
	var result := 0
	if not session.is_exception():
		_session = session
		if not _session.created:
			return 69
		await Utils.sleep(1)
		if not await check_player():
			_session = null
			result = 1
	else:
		var message = session.get_exception().message
		if message.contains("Invalid username"):
			return 70
		result = session.get_exception().status_code
	return result

func register(email: String, username: String, password: String, token: String) -> int:
	var new_session: NakamaSession = await client.authenticate_email_async(
		email, password, username, true, {"token": token}
	)
	return await check_register_session(new_session)

func register_steam(username: String) -> int:
	var ticket = await Server.get_steam_ticket()
	if not ticket:
		return 163
	
	var new_session: NakamaSession = await client.authenticate_steam_async(ticket, username, true)
	return await check_register_session(new_session)
	
func register_apple(username: String, token: String) -> int:
	var new_session: NakamaSession = await client.authenticate_apple_async(token, username, true)
	return await check_register_session(new_session)
	
func register_google(username: String, token: String) -> int:
	var new_session: NakamaSession = await client.authenticate_google_async(token, username, true)
	return await check_register_session(new_session)

func check_login_session(session: NakamaSession):
	var result := 0
	if not session.is_exception():
		await login_ready()
		var connected: NakamaAsyncResult = await socket.connect_async(session, true, 20)
		if connected.is_exception():
			return connected.get_exception().status_code
		_session = session
	else:
		result = session.get_exception().status_code
	return result

func login(username: String, password: String) -> int:
	var email = ''
	
	if username.contains('@') and username.contains('.'):
		email = username
		username = ''
		
	var new_session: NakamaSession = await client.authenticate_email_async(email, password, username, false)
	return await check_login_session(new_session)

func login_steam() -> int:
	var ticket = await Server.get_steam_ticket()
	if not ticket:
		return 163
	
	var new_session: NakamaSession = await Server.client.authenticate_steam_async(ticket, null, false)
	return await check_login_session(new_session)
	
func login_apple(token: String) -> int:
	var new_session: NakamaSession = await Server.client.authenticate_apple_async(token, null, false)
	return await check_login_session(new_session)
	
func login_google(token: String) -> int:
	var new_session: NakamaSession = await Server.client.authenticate_google_async(token, null, false)
	return await check_login_session(new_session)


func rpc_call(method: String, payload: Dictionary = {}, _socket: bool = false, bypass_sleep: bool = false, bypass_active: bool = false):
	if !bypass_active and active_rpcs.has(method):
		return {"success": false}
	active_rpcs[method] = true
	var data = "{}"
	if payload != {}:
		data = JSON.stringify(payload)
	var res
	if not _socket:
		res = await client.rpc_async(_session, method, data)
	else:
		res = await socket.rpc_async(method, data)
	if !bypass_sleep:
		await Utils.sleep(0.5)
	active_rpcs.erase(method)
	if res.is_exception():
		if res.get_exception().status_code == 401:
			_session = await client.session_refresh_async(_session)
			return await rpc_call(method, payload)
		return {"success": false, "code": res.get_exception().status_code}
	var res_json = JSON.parse_string(res.payload)
	return {
		"success": res_json["success"],
		"data": JSON.parse_string(res_json.get("data", "{}")),
		"code": 0
	}
	
func get_steam_ticket() -> Variant:
	var ticket: Dictionary = SteamEngine.api.getAuthSessionTicket()
	var result = await SteamEngine.api.get_auth_session_ticket_response
	if result[1] != SteamEngine.api.RESULT_OK:
		return
	
	var ticket_string := ''
	for i in range(ticket['size']):
		ticket_string += "%02x" % ticket['buffer'][i]
	return ticket_string

func api_call(function: Callable) -> Variant:
	var res = await function.call()
	if res.is_exception():
		if res.get_exception().status_code == 401:
			_session = await client.session_refresh_async(_session)
			return await function.call()
		return res.get_exception().status_code
	return res

func check_player():
	await get_tree().create_timer(1).timeout # wait for after register hook
	var res_json = await rpc_call("check_player")
	return res_json["success"]


func get_miscrits() -> bool:
	if len(Miscrits):
		Miscrits = []
	var body = await DataService.get_miscrits_data()
	if not body:
		Main.fatal_error("Failed to load game data")
		return false
	else:
		return parse_miscrits_json(body)
		
	
func parse_miscrits_json(data: Array):
	for miscrit in data:
		var curr = Miscrit.new(miscrit)
		Miscrits.append(curr)
		MiscritDict[curr.id] = curr
	for miscrit in Player.miscrits.values():
		miscrit.set_metadata()
	return true


func get_player() -> bool:
	var res_json = await rpc_call("get_player", {})
	if not res_json["success"]:
		Main.fatal_error("get_player", res_json["code"])
		return false
	var data = res_json["data"]
	check_update(data.get("version", "0.0.0"))
	Player = Player_.new(data)
	return true


func get_player_seen():
	var res = await rpc_call("get_player_seen")
	if not res["success"]:
		return
	var data: Dictionary = res["data"]
	for mId in data.keys():
		var miscrit = MiscritDict[int(mId)]
		miscrit.update_seen(data[mId])


func update_location(location: String, area: int) -> bool:
	var area_name = Constants.locations_additional[location][area]
	Player.set_location({"name": area_name, "area_id": area, "location": {"id": Constants.locations[location], "name": location}})
	var res_json = await rpc_call("update_location", {"locationId": Constants.locations[location], "areaId": area}, true, true)
	if not res_json["success"]:
		Main.fatal_error("update_location", res_json.get("code", 666))
		return false
	print("add")
	LocalData.add_one_time_event("visit_%s" % [location])
	return true


func heal(heal_now: bool = false):
	SoundManager.play_once("ui/heal")
	if !heal_now:
		WorldManager.acquire_move_lock()
		UiManager.block_all_inputs("heal")
	var res = await Server.rpc_call("heal_team", {}, true)
	if res["success"]:
		Player.heal_team()
		await WorldManager.player.heal()
		if !heal_now:
			Main.show_popup(tr('GYOUR_MISCRITS_HAVE_BEEN_HEALED'), tr('GSUCCESS'))
	else:
		Main.show_popup(tr('GERRORS_HEAL'))
	if !heal_now:
		WorldManager.release_move_lock()
		UiManager.release_inputs_block("heal")
		

func instant_heal():
	if Player.platinum < 5:
		Main.show_popup(tr('GERRORS_INSTANT_HEAL_NOT_ENOUGH_PLAT'))
		return false
	UiManager.block_all_inputs("heal")
	var res = await Server.rpc_call("instant_heal", {}, true)
	UiManager.release_inputs_block("heal")
	if res["success"]:
		Player.heal_team(true)
		return true
	else:
		Main.show_popup(tr('GERRORS_INSTANT_HEAL'))
		return false

func make_wish(vi: bool = false):
	UiManager.block_all_inputs("well")
	var method = "wish_vi" if vi else "wish_sk"
	var res = await Server.rpc_call(method, {}, true)
	if res["success"]:
		var reward: WishingWellPopup = load("res://scenes/popup/wishing_well.tscn").instantiate()
		UiManager.add_node_to_ui(reward)
		reward.setup(res["data"]["reward"], res["data"]["amount"], vi)
		var timestamp = int(Time.get_unix_time_from_system())
		if vi:
			Server.Player.next_wish_vi = timestamp - timestamp % 86_400 + 86_400
		else:
			Server.Player.next_wish_sk = timestamp - timestamp % 86_400 + 86_400
	else:
		Main.show_popup(tr('GERRORS_WISHING_WELL'))
	UiManager.release_inputs_block("well")

func get_collector_quest():
	var res = await Server.rpc_call("get_collector_quest", {}, true)
	if not res["success"]:
		return null
	else:
		return res["data"]

func _study_log_details(event: String, details: Dictionary, verbose: bool) -> Dictionary:
	if verbose: return details
	if not event.begins_with("capture_hunt_"): return {}
	return {"message":details.get("message", ""), "object_id":details.get("object_id", -1)}

func _study_response_log(event: String, details: Dictionary):
	var verbose = OS.get_cmdline_user_args().has("--mama-test") or OS.get_cmdline_user_args().has("--study-log")
	details = _study_log_details(event, details, verbose)
	if not verbose and details.is_empty(): return
	var entry = {"time_utc": Time.get_datetime_string_from_system(true), "ticks_ms": Time.get_ticks_msec(), "session": _capture_session, "event": event, "details": details}
	var log_path = OS.get_executable_path().get_base_dir().path_join("test-encounters.jsonl" if OS.get_cmdline_user_args().has("--mama-test") else "encounters.jsonl")
	var mode = FileAccess.READ_WRITE if FileAccess.file_exists(log_path) else FileAccess.WRITE
	var log_file = FileAccess.open(log_path, mode)
	if log_file:
		log_file.seek_end()
		log_file.store_line(JSON.stringify(entry))
		log_file.close()
	else:
		printerr("[MISCRITS_STUDY] Cannot open encounter log: ", FileAccess.get_open_error())
	if verbose: print("[MISCRITS_STUDY] ", JSON.stringify(entry))


func create_wild_battle(object_id: int):
	var hunter = get_node_or_null("MamaHunter")
	if hunter:
		if hunter.call("on_search_request", object_id) == false:
			return {"success": false, "data": {}}
	if !socket.is_connected_to_host():
		await socket.connect_async(_session, true, 20)
	_study_response_log("search_request", {"object_id": object_id})
	var res = await Server.rpc_call("create_battle", {"type": "Wild", "payload": {"objectId": object_id}}, true)
	var response_data = res.get("data", {})
	var summary = {"object_id": object_id, "success": res.get("success", false), "code": res.get("code", null), "has_data": res.has("data")}
	if response_data is Dictionary:
		summary["data_keys"] = response_data.keys()
		for key in ["cooldown", "disabled", "limit"]:
			if response_data.has(key):
				summary[key] = response_data[key]
		_study_response_log("search_result", summary)
	else:
		_study_response_log("search_result", summary)
	if hunter:
		hunter.on_search_result(object_id, res)
	return res
	
	
func create_boss_battle(boss: String):
	if !socket.is_connected_to_host():
		await socket.connect_async(_session, true, 20)
	var res = await Server.rpc_call("create_battle", {"type": "Boss", "payload": {"name": boss}}, true)
	return res


func create_campaign_battle():
	if !socket.is_connected_to_host():
		await socket.connect_async(_session, true, 20)
	var res = await Server.rpc_call("create_battle", {"type": "Campaign", "payload": {}}, true)
	return res

func create_global_boss_battle():
	if !socket.is_connected_to_host():
		await socket.connect_async(_session, true, 20)
	var res = await Server.rpc_call("create_battle", {"type": "GlobalBoss", "payload": {}}, true)
	return res

func send_battle_state(opcode: BattleEnum.Opcode, data: Dictionary):
	if Server.spectator:
		return
	if active_opcodes.has(opcode):
		return
	active_opcodes[opcode] = true
	_study_response_log("battle_request", {"match_id": current_battle_id, "opcode": opcode, "opcode_name": _capture_opcode_name(opcode), "data": data})
	await Server.socket.send_match_state_async(current_battle_id, opcode, JSON.stringify(data))
	await Utils.sleep(0.1)
	active_opcodes.erase(opcode)


func add_friend(username: String):
	var res = await api_call(func(): return await client.add_friends_async(_session, null, [username]))
	if res is int:
		return res
	return 0

func add_friend_ids(user_id: String):
	var res = await api_call(func(): return await client.add_friends_async(_session, [user_id]))
	if res is int:
		return res
	return 0

func reject_friend(user_id: String):
	var res = await api_call(func(): return await client.delete_friends_async(_session, [user_id], null))
	if res is int:
		return res
	return 0
	
func leave_clan(group_id: String):
	var res = await api_call(func(): return await client.leave_group_async(_session, group_id))
	if res is int:
		return res
	return 0

func promote_member(group_id: String, user_id: String):
	var res = await api_call(func(): return await client.promote_group_users_async(_session, group_id, [user_id]))
	if res is int:
		return res
	return 0

func demote_member(group_id: String, user_id: String):
	var res = await api_call(func(): return await client.demote_group_users_async(_session, group_id, [user_id]))
	if res is int:
		return res
	return 0
	
func kick_member(group_id: String, user_id: String):
	var res = await api_call(func(): return await client.kick_group_users_async(_session, group_id, [user_id]))
	if res is int:
		return res
	return 0

func make_xmas_wish():
	UiManager.block_all_inputs("xmas")
	var res = await Server.rpc_call("wish_xmas", {}, true)
	if res["success"]:
		var reward: CurrencyReward = load("res://scenes/popup/currency_reward.tscn").instantiate()
		UiManager.add_node_to_ui(reward)
		reward.setup(null, res["data"])
		var timestamp = int(Time.get_unix_time_from_system())
		Server.Player.next_xmas = timestamp - timestamp % 86_400 + 86_400
	else:
		Main.show_popup(tr('GERRORS_WISHING_WELL'))
	UiManager.release_inputs_block("xmas")

func check_update(server_version: String):
	var update = Utils.requires_update(server_version, version)
	if update == 1:
		Main.fatal_error("update", 69)
	elif update == 2:
		Main.fatal_error("update", 420)

func _on_socket_close():
	if not _session:
		return
	var popup: RetrySocket = load("res://scenes/popup/retry_socket.tscn").instantiate()
	UiManager.add_node_to_ui(popup)


func close_connection_and_logout():
	cleanup()
	if is_instance_valid(UiManager.battle_scene):
		UiManager.battle_scene.queue_free()
		
	if get_tree().current_scene.name != "login":
		Loader.add_scene_to_load("res://scenes/login/login.tscn")
		await Loader.scene_loaded


func cleanup():
	if _session:
		await client.session_logout_async(_session)
	_session = null
	Player = null
	friends = {}
	Miscrits.assign([])
	MiscritDict = {}
	await socket.close()
	socket = null
	Notifications.exit_battle()

func _mama_start():
	if OS.get_cmdline_user_args().has("--mama-test"):
		add_child(load("res://mama_hunt_test.gd").new())
		return
	var hunter = load("res://mama_hunter.gd").new()
	hunter.name = "MamaHunter"
	add_child(hunter)

var _capture_session = str(Time.get_unix_time_from_system()) + "-" + str(OS.get_process_id())
var _capture_raw_levels: Dictionary = {}
var _capture_level_match = ""

func _capture_register_start(data: Dictionary):
	_capture_raw_levels.clear()
	_capture_level_match = str(current_battle_id)
	for key in ["player1", "player2"]:
		var side = data.get(key, {})
		for m in side.get("miscrits", []):
			var level = m.get("level")
			if (level is int or level is float) and is_finite(float(level)) and level > 0:
				_capture_raw_levels["%s:%d" % [side.get("user_id", ""), int(m.get("id", -1))]] = level

func _capture_server_level(user_id: String, id: int, fallback):
	if _capture_level_match != str(current_battle_id): return fallback
	return _capture_raw_levels.get("%s:%d" % [user_id, id], fallback)

func _capture_opcode_name(opcode: int) -> String:
	for key in BattleEnum.Opcode:
		if BattleEnum.Opcode[key] == opcode:
			return key
	return "UNKNOWN"

func _capture_side(side) -> Dictionary:
	if not is_instance_valid(side) or side.current_miscrit == null:
		return {}
	var m = side.current_miscrit
	var stats = {}
	var species_stats = {}
	var buffs = {}
	# BattleMiscrit.stats contains HP only. Never mistake it for full combat stats.
	if Player != null and side.user_id == Player.user_id:
		var owned = Player.miscrits.get(m.id)
		if owned != null: stats = owned.stats.duplicate(true)
	if m.metadata != null:
		for key in ["hp", "pa", "ea", "pd", "ed", "spd"]:
			species_stats[key] = PlayerMiscrit.star_map.get(m.metadata.get(key), 0)
	var healing_blocked = false
	if is_instance_valid(side.current_container):
		for effect in side.current_container.status_bar.get_children():
			if effect.type == "Antiheal": healing_blocked = true
			if effect.type in ["pa", "ea", "pd", "ed", "spd"] and (effect.value is int or effect.value is float):
				buffs[effect.type] = effect.value
	var abilities = []
	for a in m.curr_abilities:
		abilities.append({"id": a.id, "name": a.name, "type": a.type, "target": a.target,
			"ap": a.ap, "accuracy": a.accuracy, "element": a.element, "times": a.times,
			"recharge": a.recharge, "cooldown": a.cooldown, "max_uses": a.max_uses,
			"additional": a.additional.duplicate(true), "enchanted": a.id in m.enchants,
			"enchant": a.enchant.duplicate(true), "true_damage": a.true_damage})
	return {"user_id": side.user_id, "id": m.id, "mId": m.mId, "name": m.name,
		"chp": m.chp, "hp": m.stats.get("hp", 0), "level": _capture_server_level(side.user_id, m.id, m.level), "rating": m.rating,
		"stats": stats, "species_stars": species_stats, "buffs": buffs,
		"element": m.metadata.element if m.metadata != null else "",
		"attempts": m.attempts, "captured": m.captured, "handicap": m.handicap,
		"healing_blocked": healing_blocked, "paralyzed": m.paralyzed, "negated": m.negated, "abilities": abilities}

func _capture_snapshot(battle) -> Dictionary:
	return {"match_id": str(current_battle_id), "player": _capture_side(battle.player), "foe": _capture_side(battle.foe),
		"capture_chance": battle.capture_control.chance if is_instance_valid(battle.capture_control) else null,
		"winner": battle.winner, "battle_type": battle.battle_type}

func _capture_skip_skill_animation() -> bool:
	return _study_fast_combat()

var _study_fast_processing = false

func _study_fast_combat() -> bool:
	var battle = BattleAnimator.battle
	return is_instance_valid(battle) and _study_fast_visuals()

func _study_fast_visuals() -> bool:
	var hunter = get_node_or_null("MamaHunter")
	return hunter == null or hunter.config.get("skip_skill_animations", true)

func _study_tween_speed() -> float:
	return 1000000.0 if _study_fast_visuals() else 1.0

func _study_battle_delay(seconds: float):
	if not _study_fast_combat():
		await Utils.sleep(seconds)

func _study_play_animation(player: AnimationPlayer, animation: String):
	player.play(animation)
	if _study_fast_combat():
		player.advance(player.current_animation_length)
	else:
		await player.animation_finished
