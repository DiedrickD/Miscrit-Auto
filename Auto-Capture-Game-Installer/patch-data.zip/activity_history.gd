extends RefCounted

var directory = ""
var prefix = ""
var battles: Array = []
var objects: Array = []
var error = ""
var session = str(Time.get_unix_time_from_system()) + "-" + str(OS.get_process_id())
var sequence = 0

func path(kind: String) -> String:
	return directory.path_join(prefix + kind + "-history.jsonl")

func load_history():
	battles = read_records("battle")
	objects = read_records("object")

func read_records(kind: String) -> Array:
	var rows: Array = []
	var indices = {}
	if not FileAccess.file_exists(path(kind)): return rows
	var file = FileAccess.open(path(kind), FileAccess.READ)
	if file == null:
		error = "Could not read " + kind + " history."
		return rows
	while not file.eof_reached():
		var line = file.get_line().strip_edges()
		if line.is_empty(): continue
		var parser = JSON.new()
		if parser.parse(line) != OK or not parser.data is Dictionary: continue
		var row = parser.data
		if not row.get("key") is String or not row.get("time") is String: continue
		if kind == "battle" and (not row.get("name") is String or not row.get("match") is String): continue
		if kind == "object" and not (row.get("object_id") is int or row.get("object_id") is float): continue
		if indices.has(row.key): rows[indices[row.key]] = row
		else:
			indices[row.key] = rows.size()
			rows.append(row)
	return rows

func append(kind: String, row: Dictionary):
	var file = FileAccess.open(path(kind), FileAccess.READ_WRITE if FileAccess.file_exists(path(kind)) else FileAccess.WRITE)
	if file == null:
		error = "Could not save " + kind + " history; records remain in memory."
		return
	file.seek_end()
	file.store_line(JSON.stringify(row))
	file.flush()
	if file.get_error() != OK: error = "Could not finish writing " + kind + " history."

func timestamp() -> Dictionary:
	return {"time": Time.get_datetime_string_from_system(false, true), "time_utc": Time.get_datetime_string_from_system(true)}

func begin_battle(match_id: String, player_id: String, opponents: Array, kind: String, object_id: int = -1):
	if match_id.is_empty() or player_id.is_empty(): return
	for i in range(opponents.size()):
		var foe = opponents[i]
		if not foe is Dictionary: continue
		var key = player_id + ":" + match_id + ":" + str(i)
		if battles.any(func(row): return row.key == key): continue
		var row = timestamp()
		row.merge({"key": key, "match": match_id, "player": player_id, "name": str(foe.get("name", "Unknown Miscrit")), "rating": foe.get("rating"), "miscrit_id": foe.get("id"), "species_id": foe.get("mId"), "type": kind, "object_id": object_id, "outcome": "In progress"})
		battles.append(row)
		append("battle", row)

func update_battle(match_id: String, outcome: String, foe: Dictionary = {}):
	for row in battles:
		if row.match != match_id: continue
		if outcome == "Captured" and not foe.is_empty():
			if row.miscrit_id != null and row.miscrit_id != foe.get("id"): continue
			if row.miscrit_id == null and row.species_id != null and row.species_id != foe.get("mId"): continue
		if row.outcome == "Captured" or row.outcome == outcome: continue
		# A later generic END must not erase an explicit flee or connection error.
		if outcome in ["Won", "Lost", "Ended"] and row.outcome in ["Fled", "Interrupted"]: continue
		row.outcome = outcome
		row.ended = Time.get_datetime_string_from_system(false, true)
		append("battle", row)

func record_object(id: int, area: String, object_name: String, route: Dictionary = {}):
	sequence += 1
	var row = timestamp()
	row.merge({"key": session + ":" + str(sequence), "object_id": id, "area": area, "name": object_name})
	if not route.is_empty(): row.route = route.duplicate(true)
	objects.append(row)
	append("object", row)

func filtered_battles(minimum: float) -> Array:
	return battles.filter(func(row):
		var rating = row.get("rating")
		return minimum == 0 or ((rating is float or rating is int) and is_finite(float(rating)) and rating >= minimum))
