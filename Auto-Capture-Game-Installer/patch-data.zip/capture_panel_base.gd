extends CanvasLayer

var hunter
var panel: PanelContainer
var body: VBoxContainer
var mode: OptionButton
var ids: LineEdit
var targets: LineEdit
var rating: SpinBox
var level_up: CheckButton
var feedback: Label
var status: Label
var toggle: Button
var history_list: Tree
var history_count: Label
var history_min: SpinBox
var syncing = false
var dragging = false
var drag_offset = Vector2.ZERO
const MODES = ["fight", "capture_any", "capture_targeted", "capture_rated", "manual_target"]

func label(text: String, parent) -> Label:
	var item = Label.new()
	item.text = text
	parent.add_child(item)
	return item

func button(text: String, parent, action: Callable) -> Button:
	var item = Button.new()
	item.text = text
	item.custom_minimum_size.y = 36
	parent.add_child(item)
	item.pressed.connect(action)
	return item

func number(parent, value: float) -> SpinBox:
	var item = SpinBox.new()
	item.min_value = 0
	item.max_value = 18
	item.step = 0.1
	item.value = value
	item.custom_minimum_size.y = 36
	parent.add_child(item)
	return item

func input(parent, title: String, hint: String) -> LineEdit:
	label(title, parent)
	var item = LineEdit.new()
	item.placeholder_text = hint
	item.custom_minimum_size.y = 36
	parent.add_child(item)
	item.text_submitted.connect(func(_text): apply_fields())
	return item

func _ready():
	layer = 110
	panel = PanelContainer.new()
	panel.position = Vector2(16, 64)
	panel.custom_minimum_size.x = 480
	var ui_theme = Theme.new()
	var font = SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	ui_theme.default_font = font
	ui_theme.default_font_size = 16
	panel.theme = ui_theme
	var style = StyleBoxFlat.new()
	style.bg_color = Color("17212f")
	style.border_color = Color("52677e")
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 10
	style.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", style)
	panel.add_theme_font_size_override("font_size", 16)
	add_child(panel)
	var stack = VBoxContainer.new()
	stack.add_theme_constant_override("separation", 8)
	panel.add_child(stack)
	var header = HBoxContainer.new()
	stack.add_child(header)
	var title = label("CAPTURE CONTROLS  ·  Drag to move", header)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.mouse_filter = Control.MOUSE_FILTER_STOP
	title.gui_input.connect(drag_header)
	var collapse = button("Hide", header, func():
		body.visible = not body.visible
		panel.reset_size()
		clamp_panel.call_deferred())
	collapse.pressed.connect(func(): collapse.text = "Hide" if body.visible else "Show")
	toggle = button("Start", stack, func(): hunter.toggle_running())
	body = VBoxContainer.new()
	body.add_theme_constant_override("separation", 8)
	stack.add_child(body)
	status = label("", body)
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.custom_minimum_size = Vector2(440, 60)
	status.max_lines_visible = 3
	status.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	status.add_theme_font_size_override("font_size", 14)
	var tabs = TabContainer.new()
	body.add_child(tabs)
	var control_tab = VBoxContainer.new()
	control_tab.name = "Controls"
	tabs.add_child(control_tab)
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size.y = 300
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	control_tab.add_child(scroll)
	var controls = VBoxContainer.new()
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	controls.add_theme_constant_override("separation", 6)
	scroll.add_child(controls)
	label("Battle mode", controls)
	mode = OptionButton.new()
	for text in ["Fight", "Capture any", "Capture targeted", "Targets + high-rated others", "Pause on selected species"]: mode.add_item(text)
	mode.custom_minimum_size.y = 36
	controls.add_child(mode)
	mode.item_selected.connect(func(_index): apply_immediate("mode", MODES[mode.selected]))
	ids = input(controls, "Object IDs · comma separated", "98, 99")
	targets = input(controls, "Capture targets · comma separated names", "blighted flue, mama")
	label("Minimum capture rating (0–18)", controls)
	rating = number(controls, 11)
	rating.get_line_edit().text_submitted.connect(func(_text): apply_fields())
	level_up = CheckButton.new()
	level_up.text = "Auto level-up · earned XP only"
	level_up.custom_minimum_size.y = 36
	control_tab.add_child(level_up)
	level_up.toggled.connect(func(value): apply_immediate("auto_level_up", value))
	button("Apply IDs, targets & rating", control_tab, apply_fields)
	var hint = label("Enter or Apply saves inputs. Mode and level-up save immediately.", control_tab)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var log_tab = VBoxContainer.new()
	log_tab.name = "Capture History"
	log_tab.add_theme_constant_override("separation", 8)
	tabs.add_child(log_tab)
	label("Show captured Miscrits with rating at least", log_tab)
	history_min = number(log_tab, 0)
	history_min.value_changed.connect(func(_value): refresh_history())
	history_count = label("", log_tab)
	history_list = Tree.new()
	history_list.columns = 3
	history_list.column_titles_visible = true
	history_list.hide_root = true
	history_list.set_column_title(0, "Miscrit")
	history_list.set_column_title(1, "Rating")
	history_list.set_column_title(2, "Captured · local time")
	history_list.set_column_expand(1, false)
	history_list.set_column_custom_minimum_width(1, 55)
	history_list.set_column_expand_ratio(0, 6)
	history_list.set_column_expand_ratio(2, 5)
	history_list.custom_minimum_size = Vector2(440, 220)
	log_tab.add_child(history_list)
	label("Newest first · filter does not change capture settings", log_tab)
	feedback = label("", body)
	feedback.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sync_fields()
	refresh_history()
	get_viewport().size_changed.connect(clamp_panel)
	panel.reset_size.call_deferred()
	clamp_panel.call_deferred()

func current_values() -> Dictionary:
	var value = hunter.config.duplicate(true)
	value.mode = value.get("combat_mode", "capture_targeted")
	value.object_id = value.get("object_ids", [98])
	value.capture_id = value.get("miscrits", [])
	return value

func sync_fields():
	syncing = true
	var value = current_values()
	mode.select(maxi(0, MODES.find(value.mode)))
	var objects = PackedStringArray()
	for id in value.object_id: objects.append(str(id))
	ids.text = ", ".join(objects)
	targets.text = ", ".join(value.capture_id)
	rating.value = value.get("min_rating", 11)
	level_up.button_pressed = value.get("auto_level_up", false)
	syncing = false

func result(error: String):
	feedback.text = "Saved. Applies to the next applicable action." if error.is_empty() else error
	feedback.add_theme_color_override("font_color", Color("8ee6bc") if error.is_empty() else Color("ffb0a9"))

func apply_immediate(key: String, value):
	if syncing: return
	var candidate = current_values()
	candidate[key] = value
	var error = hunter.live_config(candidate)
	result(error)
	syncing = true
	mode.select(maxi(0, MODES.find(hunter.config.get("combat_mode", "capture_targeted"))))
	level_up.button_pressed = hunter.config.get("auto_level_up", false)
	syncing = false

func apply_fields():
	var candidate = current_values()
	var object_ids = []
	for token in ids.text.split(","):
		var text = token.strip_edges()
		if not text.is_valid_int():
			result("Object IDs must be whole numbers separated by commas.")
			return
		object_ids.append(text.to_int())
	var names = []
	if not targets.text.strip_edges().is_empty():
		for token in targets.text.split(","): names.append(token.strip_edges())
	var rating_text = rating.get_line_edit().text.strip_edges()
	if not rating_text.is_valid_float():
		result("Minimum rating must be a number from 0 to 18.")
		return
	candidate.object_id = object_ids
	candidate.capture_id = names
	candidate.min_rating = rating_text.to_float()
	var error = hunter.live_config(candidate)
	result(error)
	if error.is_empty(): sync_fields()

func refresh_history():
	if history_list == null: return
	history_list.clear()
	var root = history_list.create_item()
	var entries = hunter.filtered_captures(history_min.value)
	history_count.text = "%d of %d captures" % [entries.size(), hunter.captures.size()]
	if entries.is_empty(): history_count.text += " · No captures match yet"
	# Bound rendering work; all records remain on disk and available to filtering.
	for i in range(entries.size() - 1, maxi(-1, entries.size() - 501), -1):
		var entry = entries[i]
		var row = history_list.create_item(root)
		row.set_text(0, entry.name)
		row.set_text(1, str(entry.rating) if entry.get("rating") != null else "—")
		row.set_text(2, entry.time)
		for column in range(3): row.set_tooltip_text(column, "%s | Rating %s | %s" % [entry.name, str(entry.get("rating", "unknown")), entry.time])
	if entries.size() > 500: history_count.text += " · showing newest 500"
	if not hunter.history_error.is_empty(): history_count.text = hunter.history_error

func drag_header(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		dragging = event.pressed
		drag_offset = panel.get_global_mouse_position() - panel.position

func _input(event):
	if dragging and event is InputEventMouseMotion:
		panel.position = panel.get_global_mouse_position() - drag_offset
		clamp_panel()
		get_viewport().set_input_as_handled()
	if event is InputEventMouseButton and not event.pressed: dragging = false

func clamp_panel():
	var viewport = get_viewport().get_visible_rect().size
	panel.reset_size()
	panel.position = panel.position.clamp(Vector2.ZERO, (viewport - panel.size).max(Vector2.ZERO))

func _process(_delta):
	toggle.text = "Pause automation  ·  F8" if hunter.enabled else "Start / resume automation  ·  F8"
	if is_instance_valid(hunter.status_label):
		status.text = hunter.status_label.text
		status.tooltip_text = status.text
