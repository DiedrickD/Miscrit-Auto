extends Node

class StudyBattle extends Node:
	var battle_type = "Wild"
	var pvp = false

class TestNotice extends Node:
	var closed = false
	func _on_exit_pressed(): closed = true

class ManualSummary extends Node:
	var continues = 0
	func _on_continue_pressed(): continues += 1

class StudyHpBar extends HpBarV2:
	var updated = false
	func setup(_miscrit: Variant):
		updated = true

class TestHunter extends "res://mama_hunter.gd":
	signal team_update_released
	var hold_team_update = false
	var team_update_calls = []
	var team_update_response = {"success":true, "code":0}
	var after_team_update = Callable()
	func request_team_update(team: Array):
		team_update_calls.append(team.duplicate())
		if hold_team_update: await team_update_released
		if after_team_update.is_valid(): after_team_update.call()
		return team_update_response.duplicate(true)
	signal healing_released
	var hold_healing = false
	var healing_calls = 0
	var heal_response_code = 0
	signal campaign_info_released
	signal campaign_create_released
	var campaign_online = true
	var campaign_world = true
	var campaign_info_value = {"last_completed":0, "tries":0}
	var campaign_response = {"success":true, "data":{"matchId":"campaign-test"}}
	var campaign_info_calls = 0
	var campaign_create_calls = 0
	var campaign_spawns = []
	var hold_campaign_info = false
	var hold_campaign_create = false
	var campaign_state: Dictionary = {}
	func campaign_connected() -> bool: return campaign_online
	func campaign_world_ready() -> bool: return campaign_world
	func campaign_snapshot(_battle) -> Dictionary: return campaign_state.duplicate(true)
	func request_campaign_info():
		campaign_info_calls += 1
		if hold_campaign_info: await campaign_info_released
		return campaign_info_value.duplicate(true)
	func request_campaign_battle():
		campaign_create_calls += 1
		if hold_campaign_create: await campaign_create_released
		return campaign_response.duplicate(true)
	func spawn_campaign_battle(id: String):
		campaign_spawns.append(id)
		Server.current_battle_id = id
	var submissions = []
	var name_location_requests = []
	var name_loads = []
	var name_travel_success = true
	var pause_on_travel = false
	func request_name_location(item):
		name_location_requests.append(item.duplicate(true))
		if pause_on_travel: enabled = false
		return {"success": name_travel_success}
	func load_name_location(item):
		name_loads.append(item.scene)
		WorldManager.location_node.scene_file_path = "res://" + item.scene
	var route_submissions = []
	func dispatch_route_search(object):
		route_submissions.append(str(object.get_path()))
		WorldManager.player.searching_object = object
		# Native WorldManager holds its search lock during the Server hook.
		WorldManager.acquire_move_lock()
		on_search_request(object.get_index())
		WorldManager.release_move_lock()
	var bonus_submissions = []
	var bonus_success = true
	var heal_success = false
	func request_bonus(m):
		bonus_submissions.append(m.id)
		return {"success": bonus_success, "data": {}}
	var training_submissions = []
	var after_training = Callable()
	var training_success = false
	func config_path() -> String:
		return OS.get_executable_path().get_base_dir().get_base_dir().path_join("tests/panel-test-config.json")
	func history_path() -> String:
		return OS.get_executable_path().get_base_dir().get_base_dir().path_join("tests/panel-test-history.jsonl")
	func send_ability(id: int):
		submissions.append(id)
	func request_training(m):
		training_submissions.append(m.id)
		if after_training.is_valid(): await after_training.call()
		return {"success": training_success, "data": {}}
	func request_healing():
		healing_calls += 1
		if hold_healing: await healing_released
		return {"success": heal_success, "code":heal_response_code}

class HealingPlayer extends Player_:
	func _init(): pass

class RoutePlayer extends Node2D:
	var is_searching = false
	var allow_click = true
	var searching_object
	var moves = 0
	func teleport(pos):
		global_position = pos
		moves += 1

class RouteContainer extends Node2D:
	var searchable = true

class BonusMiscrit extends PlayerMiscrit:
	var bonus_applied = false
	func _init(): pass
	func add_bonus(_data):
		bonus_applied = true
		bonus_level = level

class TrainMiscrit extends PlayerMiscrit:
	func _init():
		id = 123
		level = 10
	var ready = true
	var price = 0
	func ready_to_train(): return ready
	func get_level_train_price(): return price
	func get_name(): return "Training test"
	func train_stats(_data, levels):
		bonus_level = level
		level += levels
		return {}
	func mark_seen(): pass
	func mark_captured(): pass

class FakeBar extends RefCounted:
	var block = {"visible": false}
	var flees = 0
	func lock_input(): block.visible = true
	func do_flee():
		lock_input()
		flees += 1

class RotationMiscrit extends TrainMiscrit:
	var test_rating = 18.0
	func get_rating_sum(): return test_rating
	func get_name(): return "Owned Miscrit %d" % id

class IndexMiscrit extends Miscrit:
	func _init(): pass

class StudyCaptureAudit extends "res://capture_diagnostics.gd":
	func directory() -> String:
		return host.config_path().get_base_dir().path_join("explicit-target-audit-%d" % OS.get_process_id())

class FakeTeam extends RefCounted:
	var locked = false
	func lock(): locked = true

class FakeCapture extends RefCounted:
	var capture_button = {"disabled": false}
	var attempts = 0
	func _on_capture_confirmed():
		attempts += 1
		capture_button.disabled = true

class FakeBattle extends RefCounted:
	var action_bar = FakeBar.new()
	var player_team = FakeTeam.new()
	var capture_control = FakeCapture.new()
	func _on_capture_pressed():
		action_bar.lock_input()
		player_team.lock()
	func _on_ability_pressed():
		capture_control.capture_button.disabled = true

class SearchObject extends Node2D:
	var available = true
	var in_range = true
	func can_search(): return available
	func check_user_entered(): return in_range

class CampaignBattle extends Node:
	var battle_type = "Campaign"
	var processing_queue = false
	var action_queue = []
	var winner = ""
	var player = {"user_id":"test-player", "current_miscrit":{"handicap":false}}
	var action_bar = FakeBar.new()
	var player_team = FakeTeam.new()
	var capture_control = FakeCapture.new()
	func _on_ability_pressed(): pass

var checks = 0
var failures = 0
var hunter
var policy
var server

func _ready():
	call_deferred("run_tests")

func check(condition: bool, description: String):
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ", description)

func config() -> Dictionary:
	return {"mode": "multiple", "object_ids": [98, 99], "target_mode": "any", "miscrits": [], "min_rating": 0,
		"capture_threshold": 70, "ability_ids": [], "max_attacks": 12, "min_player_hp_percent": 25,
		"min_target_hp_percent": 25, "damage_margin": 2.0, "skip_skill_animations": false}

func ability(id: int, ap: int) -> Dictionary:
	return {"id": id, "name": "Test " + str(id), "ap": ap, "type": "Attack", "target": "Foe",
		"times": 1, "additional": [], "recharge": 0, "enchanted": false, "enchant": {}}

func state() -> Dictionary:
	return {"capture_chance": 37.0, "player": {"id": 1, "user_id": "test-player", "hp": 100, "chp": 100, "abilities": [ability(20, 20), ability(10, 10)]},
		"foe": {"id": 2, "user_id": "Wild", "hp": 100, "chp": 100, "attempts": 0, "captured": false}}

func history() -> Dictionary:
	return {"attacks": 0, "flee": false, "damage": {}}

func reset_hunt():
	hunter.manual_battle_id = ""
	hunter.apply_config(config())
	hunter.reset_battle()
	hunter.needs_rearm = false
	hunter.enabled = true
	hunter.match_id = "capture-test"
	hunter.active_object_id = 98
	hunter.pending_search = true
	hunter.encounter_checked = false
	hunter.leaving = false
	server.current_battle_id = "capture-test"

func run_tests():
	if OS.get_cmdline_user_args().has("--extract-campaign"):
		for path in ["scenes/campaign/campaign.gd", "scenes/campaign/campaign_info.gd", "models/Player.gd", "scenes/battle/battle.gd", "scenes/battle/battle_player.gd", "scenes/team/team.gd", "models/PlayerMiscrit.gd", "models/Miscrit.gd"]:
			var script = load("res://" + path)
			var destination = OS.get_executable_path().get_base_dir().path_join("campaign-native").path_join(path)
			DirAccess.make_dir_recursive_absolute(destination.get_base_dir())
			FileAccess.open(destination, FileAccess.WRITE).store_string(script.source_code)
			print("EXTRACTED ", path)
		get_tree().quit()
		return
	server = get_tree().root.get_node("Server")
	server.current_battle_id = "level-context"
	server._capture_register_start({"player1": {"user_id": "Wild", "miscrits": [{"id": 0, "level": 23.5}, {"id": 1, "level": 33.25}]}, "player2": {"user_id": "test-player", "miscrits": [{"id": 0, "level": 35}]}})
	check(server._capture_server_level("Wild", 0, 23) == 23.5, "Preserve fractional server level")
	check(server._capture_server_level("Wild", 1, 33) == 33.25, "Separate levels for multiple opponents")
	check(server._capture_server_level("test-player", 0, 1) == 35, "Level keys distinguish opposing sides")
	server.current_battle_id = "next-level-context"
	check(server._capture_server_level("Wild", 0, 20) == 20, "Never reuse a previous encounter's level")
	server._capture_register_start({"player1": {"user_id": "Wild", "miscrits": [{"id": 0, "level": "bad"}]}})
	check(server._capture_server_level("Wild", 0, 20) == 20, "Invalid raw levels retain client fallback")
	check(load("res://scenes/battle/battle.gd").can_instantiate(), "Patched battle compiles")
	check(load("res://scenes/battle/battle_player.gd").can_instantiate(), "Optional animation patch compiles")
	for path in ["scenes/battle/battle_team.gd", "scenes/battle/battle_avatar.gd", "scenes/battle/battle_sprites.gd", "scenes/battle/action_bar.gd", "singletons/battle_animator.gd", "singletons/ui_tween_animator.gd", "singletons/screen_transition.gd", "scenes/common_ui/xp_bar.gd", "scenes/common_ui/xp_bar_v2.gd", "scenes/battle/ui_control.gd", "scenes/battle/battle_summary.gd", "scenes/battle/summary_miscrit.gd", "scenes/battle/battle_container_v2.gd", "scenes/battle/miscrit_sprite.gd"]:
		check(load("res://" + path).can_instantiate(), "Presentation script compiles: " + path)
	hunter = TestHunter.new()
	get_tree().root.add_child(hunter)
	hunter.set_process(false)
	policy = hunter.policy
	check(hunter.apply_config(config()).is_empty(), "Any-species config loads")
	for field in ["capture_threshold", "min_player_hp_percent", "min_target_hp_percent"]:
		for value in [null, true, "70", -1, 0, 101, NAN, INF]:
			var bad = config()
			bad[field] = value
			check(not hunter.validate_config(bad).is_empty(), "Reject invalid " + field)
	for value in [0, -1, 1.5, INF, "12"]:
		var bad = config()
		bad.max_attacks = value
		check(not hunter.validate_config(bad).is_empty(), "Reject invalid attack limit")
	var targeted = config()
	targeted.target_mode = "targeted"
	check(not hunter.validate_config(targeted).is_empty(), "Targeted mode needs names")
	targeted.miscrits = [" Blighted Flue "]
	targeted.min_rating = 11
	check(hunter.apply_config(targeted).is_empty(), "Targeted config loads")
	check(hunter.classify_encounter([{"name": "Blighted Flue", "rating": 11.0}]) == "match", "Inclusive name/rating filter")
	check(hunter.classify_encounter([{"name": "Steamguin", "rating": 18.0}]) == "miss", "Wrong species rejected in targeted mode")
	reset_hunt()
	check(hunter.classify_encounter([{"mId": 19.0}]) == "match", "Any mode accepts species ID")
	check(hunter.classify_encounter([{}]) == "unknown", "Missing species ID pauses")
	var modern = {"object_id": [98, 99], "mode": "capture_targeted", "capture_id": ["blighted flue"], "auto_level_up": "on"}
	check(hunter.apply_config(modern).is_empty(), "Requested config schema loads")
	check(hunter.config.min_rating == 11.0 and hunter.config.auto_level_up, "Defaults and on/off normalize")
	hunter.on_encounter([{"name": "Steamguin", "mId": 19, "rating": 18}])
	check(hunter.history.get("fight", false), "Targeted mismatch fights")
	hunter.on_encounter([{"name": "Blighted Flue", "mId": 19, "rating": 10}])
	check(hunter.history.get("fight", false), "Below-rating target fights")
	hunter.on_encounter([{"name": "Blighted Flue", "mId": 19, "rating": 11}])
	check(not hunter.history.get("fight", false), "Qualified target captures")
	var fight_state = state()
	fight_state.capture_chance = null
	check(policy.decide(fight_state, {"mode": "fight"}, history()).id == 20, "Fight chooses strongest without capture chance")
	var fight_history = history()
	policy.observe({"user_id": "test-player", "id": 20.0, "actions": [{"type": "Attack", "target": "Wild", "damage": 90}]}, 2, fight_state, fight_history)
	fight_state.foe.chp = 10
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).id == 10, "Surviving enemy gets a different follow-up attack")
	fight_state.player.abilities[0].recharge = 4
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).id == 10, "Follow-up works while heavy skill recharges")
	fight_state.player.abilities[1].recharge = -1
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).action == "flee", "Follow-up never uses depleted or recharging attacks")
	fight_state.player.abilities[0].recharge = 0
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).id == 20, "Only available attack can still be repeated")
	fight_state.foe.chp = 0
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).action == "wait", "Defeated enemy receives no follow-up")
	fight_state = state()
	fight_state.foe.id = 3
	check(policy.decide(fight_state, {"mode": "fight"}, fight_history).id == 20, "New opponent starts with strongest attack")
	for path in ["singletons/notifications.gd", "scenes/popup/error.gd"]:
		check(load("res://" + path).can_instantiate(), "Notification patch compiles: " + path)
	for kind in ["rank_up", "currency_reward", "daily_quest", "notice", "friend_request", "duel_request"]:
		var notice = TestNotice.new()
		hunter.enabled = false
		hunter.watch_notification(notice, kind)
		hunter.dismiss_notifications()
		check(not notice.closed, "Paused automation leaves notification open: " + kind)
		hunter.enabled = true
		hunter.dismiss_notifications()
		check(notice.closed == (kind not in ["friend_request", "duel_request"]), "Dismiss informational notification only: " + kind)
		notice.free()
	test_repeated_capture()
	await test_capture_improvements()
	reset_hunt()
	var s = state()
	var trainee = TrainMiscrit.new()
	check(hunter.can_train(trainee), "XP-ready team member can train")
	trainee.level = 35
	check(not hunter.can_train(trainee), "Max level cannot train")
	trainee.level = 10
	trainee.price = 1
	check(not hunter.can_train(trainee), "Paid training excluded")
	trainee.price = 0
	trainee.ready = false
	check(not hunter.can_train(trainee), "Insufficient XP excluded")
	trainee.ready = true
	await hunter.train_miscrit(trainee)
	check(hunter.training_submissions.is_empty(), "Auto level off sends nothing")
	var training_original_player = server.Player
	var training_player = HealingPlayer.new()
	training_player.team.assign([123])
	training_player.miscrits[123] = trainee
	server.Player = training_player
	hunter.config.auto_level_up = true
	await hunter.train_miscrit(trainee)
	check(hunter.training_submissions == [123] and not hunter.enabled and not hunter.training, "Training failure stops without paid retry")
	server.Player = training_original_player
	await test_platinum_training()
	test_rated_capture()
	test_manual_target_battle()
	test_search_cooldown_timing()
	test_flee_unwanted_encounters()
	test_healing_skill()
	reset_hunt()
	var h = history()
	check(policy.decide(s, config(), h).id == 10, "Choose weakest simple attack independent of button order")
	s.capture_chance = 69.99
	check(policy.decide(s, config(), h).action == "ability", "No rounding up to capture threshold")
	s.capture_chance = 70.0
	check(policy.decide(s, config(), h).action == "capture", "Capture at exact inclusive threshold")
	s.player.chp = 1
	check(policy.decide(s, config(), h).action == "capture", "Capture opportunity takes priority over further attacks")
	s.foe.attempts = 1
	check(policy.decide(s, config(), h).action == "flee", "Never pay for second attempt even with high chance")
	s = state()
	h.flee = true
	check(policy.decide(s, config(), h).action == "flee", "Failed capture has flee priority")
	h = history()
	for value in [null, true, "70", -1, 101, NAN]:
		s.capture_chance = value
		check(policy.decide(s, config(), h).action == "stop", "Unknown chance cannot trigger an attack")
	s = state()
	s.player.chp = 25
	check(policy.decide(s, config(), h).action == "flee", "Player HP floor")
	s = state()
	s.foe.chp = 25
	check(policy.decide(s, config(), h).action == "flee", "Target HP floor")
	s = state()
	h.attacks = 12
	check(policy.decide(s, config(), h).action == "flee", "Finite attack budget")
	h = history()
	s.player.abilities[1].recharge = -1
	check(policy.decide(s, config(), h).id == 20, "Depleted skill excluded")
	s.player.abilities[0].recharge = 1
	check(policy.decide(s, config(), h).action == "flee", "No available moves exits rather than sends invalid skill")
	for field in ["additional", "times", "target", "type"]:
		s = state()
		s.player.abilities = [ability(10, 10)]
		s.player.abilities[0][field] = {"additional": [{"type": "Dot"}], "times": 2, "target": "Self", "type": "Dot"}[field]
		check(policy.decide(s, config(), h).action == "flee", "Exclude complex effect: " + field)
	s = state()
	var cfg = config()
	cfg.ability_ids = [20]
	check(policy.decide(s, cfg, h).id == 20, "Configured skill allowlist")
	cfg.ability_ids = [999]
	check(policy.decide(s, cfg, h).action == "flee", "Unavailable configured skill never submitted")
	s.player.abilities = [ability(10, 10)]
	s.player.abilities[0].enchanted = true
	s.player.abilities[0].enchant = {"additional": [{"type": "Poison"}]}
	check(policy.decide(s, config(), h).action == "flee", "Complex enchant excluded")
	s = state()
	var hit = {"user_id": "test-player", "id": 10, "actions": [{"type": "Attack", "target": "Wild", "damage": 25}, {"type": "Attack", "target": "Wild", "damage": 5}]}
	policy.observe(hit, 2, s, h)
	check(h.damage["1:2:10"] == 30, "Actual server damage totals learned for actor/target/skill")
	s.foe.chp = 62
	check(policy.decide(s, config(), h).action == "flee", "Unsafe learned attack cannot cause fallback to unmeasured stronger move")
	s.player.abilities = [ability(10, 10)]
	check(policy.decide(s, config(), h).action == "flee", "No safe learned move flees")
	s.foe.id = 3
	check(policy.decide(s, config(), h).action == "ability", "Damage observations do not leak to different target")
	reset_hunt()
	hunter.on_encounter([{"mId": 19}])
	check(hunter.encounter_checked and hunter.enabled, "Any encounter starts capture flow")
	hunter.inflight = "capture"
	hunter.capture_attempted = true
	hunter.on_battle_event({"user_id": "test-player", "captured": false, "next_turn": "Wild", "capture_chance": 75}, 10, state(), state())
	check(hunter.history.flee and hunter.inflight.is_empty() and not hunter.capture_succeeded, "Failed capture transitions to flee")
	var mock_battle = {"processing_queue": false, "action_queue": [], "action_bar": {"block": {"visible": false}}, "player": {"user_id": "test-player", "current_miscrit": {"handicap": false}}}
	check(not hunter.can_take_turn(mock_battle), "Enemy turn never permits immediate flee")
	hunter.next_turn = "test-player"
	hunter.pending = false
	check(hunter.can_take_turn(mock_battle), "Legal empty queue permits next action")
	for guard in ["inflight", "pending", "queue", "locked", "handicap"]:
		hunter.inflight = "ability" if guard == "inflight" else ""
		hunter.pending = guard == "pending"
		mock_battle.processing_queue = guard == "queue"
		mock_battle.action_bar.block.visible = guard == "locked"
		mock_battle.player.current_miscrit.handicap = guard == "handicap"
		check(not hunter.can_take_turn(mock_battle), "Action guard: " + guard)
	reset_hunt()
	hunter.on_battle_event({"user_id": "test-player", "captured": true, "capture_chance": 75}, 10, state(), state())
	check(hunter.capture_succeeded and not hunter.history.flee, "Successful capture transitions toward keep")
	hunter.enabled = false
	hunter.on_battle_event({"user_id": "test-player", "captured": false}, 10, state(), state())
	check(not hunter.capture_succeeded and not hunter.enabled, "Pause tracks server responses without resuming automation")
	reset_hunt()
	hunter.on_battle_event({"msg": "invalid skill"}, 14, state(), state())
	check(not hunter.enabled, "Server INVALID halts")
	reset_hunt()
	hunter.latest_chance = 80
	hunter.on_battle_event({"user_id": "Wild", "next_turn": "test-player"}, 2, state(), state())
	check(hunter.latest_chance == null, "Missing new chance cannot reuse stale threshold")
	reset_hunt()
	hunter.encounter_checked = true
	hunter.on_flee_result(false)
	check(not hunter.leaving and hunter.next_action > Time.get_ticks_msec(), "Failed flee waits before retry")
	hunter.on_flee_result(true)
	check(hunter.leaving, "Successful flee waits for scene exit")
	reset_hunt()
	var fake = FakeBattle.new()
	hunter.perform_decision(fake, {"action": "ability", "id": 10}, 100)
	hunter.perform_decision(fake, {"action": "ability", "id": 10}, 101)
	check(hunter.submissions == [10] and hunter.history.attacks == 1, "Repeated ticks submit one skill while awaiting response")
	check(fake.player_team.locked and fake.action_bar.block.visible, "Submission locks team and action controls")
	hunter.on_battle_event({"user_id": "Wild", "id": 20, "actions": [], "capture_chance": 65}, 2, state(), state())
	check(hunter.inflight == "ability", "Enemy skill does not acknowledge player's pending skill")
	hunter.on_battle_event({"user_id": "test-player", "id": 10, "actions": [], "capture_chance": 70, "next_turn": "test-player"}, 2, state(), state())
	check(hunter.inflight.is_empty(), "Own skill response releases pending action")
	fake.capture_control.capture_button.disabled = false
	hunter.perform_decision(fake, {"action": "capture"}, 200)
	hunter.perform_decision(fake, {"action": "capture"}, 201)
	check(fake.capture_control.attempts == 1 and hunter.capture_attempted, "Capture submission is one-shot before response arrives")
	hunter.on_battle_event({"user_id": "test-player", "captured": false, "next_turn": "test-player", "capture_chance": 70}, 10, state(), state())
	var exit_decision = policy.decide(state(), config(), hunter.history)
	hunter.perform_decision(fake, exit_decision, 300)
	check(fake.action_bar.flees == 1 and fake.capture_control.attempts == 1, "Failed capture leads to flee without another capture")
	hunter.inflight = ""
	hunter.enabled = false
	hunter.perform_decision(fake, {"action": "ability", "id": 10}, 400)
	check(hunter.submissions == [10], "Paused controller cannot dispatch skills")
	var area = Node2D.new()
	get_tree().root.add_child(area)
	for i in range(98): area.add_child(Node2D.new())
	var object98 = SearchObject.new()
	var object99 = SearchObject.new()
	area.add_child(object98)
	area.add_child(object99)
	reset_hunt()
	check(hunter.bind_objects(object98), "Bind object 98/99 siblings")
	hunter.cursor = 1
	check(hunter.next_available_object(0) == object99, "98 advances to 99")
	object99.available = false
	check(hunter.next_available_object(0) == null, "Sequential loop waits for 99 rather than repeats 98")
	hunter.cursor = 0
	check(hunter.next_available_object(0) == object98, "99 wraps back to 98")
	hunter.cooldowns[98] = 1000
	check(hunter.next_available_object(999) == null and hunter.next_available_object(1000) == object98, "Server cooldown respected at boundary")
	test_live_panel()
	area.free()
	check(hunter.next_available_object(1001) == null and not hunter.enabled, "Removed object stops")
	check(not server._capture_skip_skill_animation(), "Animation skip disabled outside authorized wild battle")
	check(load("res://scenes/common_ui/hp_bar_v2.gd").can_instantiate(), "Patched HP bar compiles")
	var animator = get_tree().root.get_node("BattleAnimator")
	var original_battle = animator.battle
	var study_battle = StudyBattle.new()
	animator.battle = study_battle
	server._study_fast_processing = true
	var fast_flag = OS.get_cmdline_user_args().has("--fast-study")
	check(server._study_fast_combat() == true, "Fast presentation is the default")
	if true:
		check(server._capture_skip_skill_animation(), "Manual fast mode bypasses skill visuals without a hunter")
		var hp_widget = StudyHpBar.new()
		await hp_widget.animate_update(null)
		check(hp_widget.updated, "HP refresh runs immediately without a tween or frame wait")
		hp_widget.free()
		var started = Time.get_ticks_msec()
		await server._study_battle_delay(0.6)
		check(Time.get_ticks_msec() - started < 100, "Combat presentation delay is bypassed")
		var anim_player = AnimationPlayer.new()
		add_child(anim_player)
		var library = AnimationLibrary.new()
		var clip = Animation.new()
		clip.length = 2.0
		library.add_animation("test", clip)
		anim_player.add_animation_library("", library)
		started = Time.get_ticks_msec()
		await server._study_play_animation(anim_player, "test")
		check(Time.get_ticks_msec() - started < 100, "Animation finishes without waiting for its original duration")
		anim_player.free()
	study_battle.pvp = true
	check(server._study_fast_combat(), "PvP presentation is fast")
	study_battle.pvp = false
	server.spectator = true
	check(server._study_fast_combat(), "Spectator presentation is fast")
	server.spectator = false
	study_battle.battle_type = "Boss"
	check(server._study_fast_combat(), "Boss presentation is fast")
	study_battle.battle_type = "Wild"
	server._study_fast_processing = false
	check(server._study_fast_combat(), "Entry/capture/summary are fast too")
	await test_visual_toggle()
	animator.battle = original_battle
	study_battle.free()
	test_activity_histories()
	await test_panel_layout()
	test_area_routes()
	await test_name_search()
	test_catalog_update()
	test_mapping_resources()
	test_mapping_learning()
	await test_campaign_clear()
	await test_campaign_virtue_heal()
	await test_team_rotation()
	await test_desktop_collection_workflow()
	await test_desktop_level35_fallback()
	test_desktop_performance()
	test_capture_diagnostics()
	if OS.get_cmdline_user_args().has("--panel-preview"):
		hunter.enabled = false
		hunter.area_ref = null
		hunter.apply_config({"mode":"capture_targeted", "capture_id":["blighted flue", "blighted flowerpiller"], "object_id":[], "auto_search":true})
		hunter.panel.sync_fields()
		hunter.panel.name_query.clear()
		hunter.panel.refresh_suggestions("")
		hunter.announce("ready", "Choose Miscrits, then press Start automation.")
		hunter.panel.refresh_history()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		print("PANEL LAYOUT: ", hunter.panel.panel.size, " minimum ", hunter.panel.panel.get_combined_minimum_size(), " viewport ", get_viewport().get_visible_rect().size)
		check(hunter.panel.panel.size.y <= get_viewport().get_visible_rect().size.y, "Rendered target panel stays inside viewport after bulk tier selection")
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-controls.png"))
		for page in range(1, hunter.panel.tabs.get_tab_count()):
			hunter.panel.tabs.current_tab = page
			await get_tree().process_frame
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-history-%d.png" % page))
		hunter.panel.tabs.current_tab = 0
		await get_tree().process_frame
		hunter.panel.set_panel_size(Vector2(460, 560))
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-compact.png"))
		hunter.panel.set_panel_size(Vector2(560, 710))
		hunter.panel.set_control_page(1)
		hunter.panel.apply_immediate("mode", "manual_target")
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-battle-setup.png"))
		hunter.panel.apply_immediate("mode", "capture_rated")
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-ratings.png"))
		hunter.panel.set_control_page(0)
		hunter.panel.name_query.text = "roc"
		hunter.panel.refresh_suggestions("roc")
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-search.png"))
		hunter.panel.name_query.clear()
		hunter.panel.refresh_suggestions("")
		hunter.panel.set_control_page(2)
		hunter.panel.sync_fields()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-campaign.png"))
		hunter.panel.set_panel_size(Vector2(460, 560))
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-campaign-compact.png"))
		hunter.panel.set_panel_size(Vector2(560,710))
		hunter.panel.tabs.current_tab = 1
		hunter.panel.team_tabs.current_tab = 0
		hunter.apply_config({"mode":"capture_targeted", "capture_id":["mama"], "object_id":[], "auto_search":true, "auto_replace_max_level":true, "replacement_names":["blighted flue", "rocapez"]})
		hunter.panel.sync_fields()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-replacements.png"))
		hunter.panel.set_panel_size(Vector2(460,560))
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-replacements-compact.png"))
		hunter.panel.set_panel_size(Vector2(560,710))
		hunter.panel.team_tabs.current_tab = 1
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-training.png"))
		hunter.panel.team_tabs.current_tab = 2
		hunter.panel.sync_fields()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-collection.png"))
		hunter.panel.set_panel_size(Vector2(460,560))
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-collection-compact.png"))
		hunter.panel.toggle_collapsed()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(OS.get_executable_path().get_base_dir().path_join("panel-circle.png"))
	hunter.queue_free()
	print("AUTO CAPTURE TESTS: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)

func test_visual_toggle():
	var original_parent = hunter.get_parent()
	var original_name = hunter.name
	hunter.reparent(server)
	hunter.name = "MamaHunter"
	hunter.area_ref = null
	hunter.panel.apply_immediate("skip_skill_animations", false)
	check(hunter.panel.visuals.button_pressed and not server._study_fast_combat(), "Visual toggle restores normal battle presentation")
	check(not server._capture_skip_skill_animation() and server._study_tween_speed() == 1.0, "Normal visuals restore skills and tween speed")
	var started = Engine.get_process_frames()
	await server._study_battle_delay(0.2)
	check(Engine.get_process_frames() > started, "Normal presentation yields for visual timing")
	hunter.panel.apply_immediate("skip_skill_animations", true)
	check(not hunter.panel.visuals.button_pressed and server._study_fast_combat() and server._study_tween_speed() > 1000, "Visual toggle returns to fast presentation")
	hunter.reparent(original_parent)
	hunter.name = original_name

func test_activity_histories():
	var journal = hunter.journal
	for kind in ["battle", "object"]:
		var file = FileAccess.open(journal.path(kind), FileAccess.WRITE)
		file.close()
	journal.load_history()
	check(not hunter.find_objects, "Object finder starts off")
	hunter.enabled = false
	hunter.on_search_request(123)
	check(journal.objects.is_empty() and FileAccess.get_file_as_string(journal.path("object")).is_empty(), "Finder off records no object history even on a search")
	hunter.find_objects = true
	hunter.on_search_request(123)
	check(journal.objects.size() == 1 and journal.objects[0].object_id == 123, "Finder records a manually searched ID while automation is paused")
	hunter.find_objects = false
	hunter.on_search_request(124)
	check(journal.objects.size() == 1, "Disabling finder stops new records and retains history")
	server.current_battle_id = "journal-battle"
	var opponents = [{"id": 4, "mId": 19, "name": "Blighted Flue", "rating": 12.5}, {"id": 5, "mId": 20, "name": "Mama", "rating": 15.0}]
	hunter.battle_objects["journal-battle"] = 123
	hunter.on_battle_started(opponents, "Wild", "test-player")
	hunter.on_battle_started(opponents, "Wild", "test-player")
	check(journal.battles.size() == 2 and journal.battles[0].object_id == 123, "Battle history records each opponent once, even while paused")
	check(journal.filtered_battles(12.5).size() == 2 and journal.filtered_battles(12.6).size() == 1, "Battle rating filter preserves fractional inclusive boundaries")
	var before = state()
	before.match_id = "journal-battle"
	before.foe.id = 4
	before.foe.mId = 19
	var after = state()
	hunter.update_battle_history({"user_id": "test-player", "captured": false}, BattleEnum.Opcode.CAPTURE, before, after)
	check(journal.battles[0].outcome == "In progress", "A failed capture does not mark a battle captured")
	hunter.update_battle_history({"user_id": "test-player", "captured": true}, BattleEnum.Opcode.CAPTURE, before, after)
	check(journal.battles[0].outcome == "Captured" and journal.battles[1].outcome == "In progress", "Only the captured opponent receives captured outcome")
	after.winner = "test-player"
	hunter.update_battle_history({}, BattleEnum.Opcode.END, before, after)
	check(journal.battles[0].outcome == "Captured" and journal.battles[1].outcome == "Won", "Battle end records win without erasing captured outcome")
	server.current_battle_id = "journal-flee"
	hunter.on_battle_started([{"id": 9, "name": "Steamguin", "rating": 10.5}], "Wild", "test-player")
	before.match_id = "journal-flee"
	server.current_battle_id = ""
	hunter.update_battle_history({"success": true}, BattleEnum.Opcode.FLEE, before, after)
	check(journal.battles.back().outcome == "Fled", "Flee history survives the live match ID being cleared")
	server.current_battle_id = "journal-loss"
	hunter.on_battle_started([{"id": 10, "name": "Dark Flue", "rating": 17.5}], "Wild", "test-player")
	before.match_id = "journal-loss"
	after.winner = "Wild"
	hunter.update_battle_history({}, BattleEnum.Opcode.END, before, after)
	check(journal.battles.back().outcome == "Lost", "Battle history records losses")
	server.spectator = true
	server.current_battle_id = "journal-spectate"
	hunter.on_battle_started(opponents, "Arena", "another-player")
	server.spectator = false
	check(journal.battles.size() == 4, "Spectator battles are excluded")
	journal.load_history()
	check(journal.battles.size() == 4 and journal.battles[0].outcome == "Captured" and journal.battles[3].outcome == "Lost", "Battle history reload reduces updates to one row per opponent")
	check(journal.objects.size() == 1 and journal.objects[0].object_id == 123, "Object history persists independently of finder toggle")
	hunter.panel.battle_min.value = 15
	check(hunter.panel.battle_list.get_root().get_child_count() == 2 and hunter.config.min_rating == 14.5, "Battle UI filter is independent of capture settings")
	hunter.panel.battle_min.value = 0
	hunter.panel.sync_fields()
	hunter.panel.refresh_objects()
	server.current_battle_id = "capture-test"

func test_panel_layout():
	hunter.panel.set_panel_size(Vector2(700, 750))
	await get_tree().process_frame
	var large = hunter.panel.panel.size
	hunter.panel.set_panel_size(Vector2(460, 560))
	await get_tree().process_frame
	check(hunter.panel.panel.size.x < large.x and hunter.panel.panel.size.y < large.y, "Panel can shrink and grow without content fixing its size")
	hunter.panel.set_control_page(0)
	check(hunter.panel.control_pages[0].visible and not hunter.panel.control_pages[1].visible, "Targets view keeps battle options out of the search list")
	await get_tree().process_frame
	var target_scroll = hunter.panel.control_pages[0].get_child(0)
	check(hunter.panel.selected_targets.global_position.y + 70 <= target_scroll.global_position.y + target_scroll.size.y, "Compact targets view shows the list header and at least one target without scrolling")
	hunter.panel.tabs.current_tab = 1
	hunter.panel.team_tabs.current_tab = 0
	await get_tree().process_frame
	await get_tree().process_frame
	var replacement_scroll = hunter.panel.team_tabs.get_child(0).get_child(0)
	check(hunter.panel.replacement_list.global_position.y + 70 <= replacement_scroll.global_position.y + replacement_scroll.size.y, "Compact Team replacement view shows a candidate row without scrolling (list top %s; view bottom %s)" % [str(hunter.panel.replacement_list.global_position.y), str(replacement_scroll.global_position.y + replacement_scroll.size.y)])
	hunter.panel.tabs.current_tab = 0
	hunter.panel.set_control_page(1)
	check(not hunter.panel.control_pages[0].visible and hunter.panel.control_pages[1].visible, "Battle setup is accessible independently of the target list")
	hunter.panel.mode.select(3)
	hunter.panel.mode.item_selected.emit(3)
	check(hunter.config.combat_mode == "capture_rated" and hunter.panel.other_rating_field.visible, "Battle selector saves combined mode and exposes both rating thresholds")
	hunter.panel.mode.select(0)
	hunter.panel.mode.item_selected.emit(0)
	check(hunter.config.combat_mode == "fight" and hunter.panel.flee_others.disabled and not hunter.panel.rating_fields.visible, "Fight-only mode disables irrelevant flee and rating options")
	hunter.panel.set_control_page(0)
	hunter.panel.save_layout()
	var compact = hunter.panel.panel.size
	hunter.panel.set_panel_size(Vector2(800, 780))
	hunter.panel.load_layout()
	check(hunter.panel.panel.size.is_equal_approx(compact), "Panel dimensions persist across layout reload")
	hunter.panel.toggle_collapsed()
	await get_tree().process_frame
	check(not hunter.panel.panel.visible and hunter.panel.orb.visible and hunter.panel.orb.size == Vector2(58, 58), "Collapse leaves only a floating circle")
	hunter.panel.toggle_collapsed()
	await get_tree().process_frame
	check(hunter.panel.panel.visible and not hunter.panel.orb.visible and hunter.panel.panel.size.is_equal_approx(compact), "Expand restores the selected panel size")
	hunter.panel.set_panel_size(Vector2(560, 710))
	hunter.panel.tabs.current_tab = 0

func test_live_panel():
	var candidate = {"mode": "capture_targeted", "object_id": [99, 98], "capture_id": ["Blighted Flue"], "min_rating": 11.5, "auto_level_up": true}
	hunter.encounter_data = [{"mId": 19, "name": "Blighted Flue", "rating": 12.5}]
	hunter.encounter_checked = true
	hunter.inflight = "ability"
	hunter.history.damage = {"retained": 30}
	check(hunter.live_config(candidate).is_empty(), "Live settings save and apply while an action is pending")
	check(hunter.match_id == "capture-test" and hunter.pending_search and hunter.inflight == "ability", "Live updates preserve active battle and in-flight action")
	check(hunter.config.object_ids == [99, 98] and hunter.objects.has(99) and hunter.cursor == 0, "Changed objects rebind in the current area")
	check(hunter.cooldowns[98] == 1000 and hunter.history.damage.retained == 30, "Live updates preserve cooldowns and learned damage")
	check(not hunter.history.fight and hunter.config.auto_level_up, "New target settings reclassify the existing encounter")
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(saved.mode == "capture_targeted" and saved.min_rating == 11.5, "Saved settings retain editable schema")
	var invalid = candidate.duplicate(true)
	invalid.object_id = [1000]
	check(not hunter.live_config(invalid).is_empty() and hunter.config.object_ids == [99, 98], "Invalid area ID rejects changes atomically")
	check(JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path())) == saved, "Rejected settings do not overwrite disk")
	candidate.mode = "fight"
	check(hunter.live_config(candidate).is_empty() and hunter.history.fight, "Mode changes affect next decision")
	hunter.enabled = true
	hunter.toggle_running()
	check(not hunter.enabled and hunter.inflight == "ability", "Panel pause preserves pending action")
	hunter.on_battle_event({"user_id": "test-player", "next_turn": "test-player", "pending": false}, 2, state(), state())
	check(not hunter.enabled and hunter.inflight.is_empty(), "Paused ability acknowledgement clears in-flight state")
	hunter.toggle_running()
	check(hunter.enabled and hunter.match_id == "capture-test", "Resume preserves active match")
	hunter.captures.clear()
	hunter.captured_matches.clear()
	var file = FileAccess.open(hunter.history_path(), FileAccess.WRITE)
	file.close()
	hunter.enabled = false
	hunter.on_battle_event({"user_id": "test-player", "captured": false}, 10, state(), state())
	check(hunter.captures.is_empty(), "Failed captures never enter history")
	hunter.on_battle_event({"user_id": "Wild", "captured": true}, 10, state(), state())
	check(hunter.captures.is_empty(), "Opponent captures never enter history")
	hunter.on_battle_event({"user_id": "test-player", "captured": true}, 10, state(), state())
	hunter.on_battle_event({"user_id": "test-player", "captured": true}, 10, state(), state())
	check(hunter.captures.size() == 1 and not hunter.enabled, "Successful capture while paused recorded exactly once")
	check(hunter.captures[0].name == "Blighted Flue" and hunter.captures[0].rating == 12.5 and not hunter.captures[0].time.is_empty(), "History stores name, precise rating and timestamp")
	check(hunter.filtered_captures(12.5).size() == 1 and hunter.filtered_captures(12.6).is_empty(), "History minimum-rating filter is inclusive and numeric")
	hunter.load_captures()
	check(hunter.captures.size() == 1 and hunter.captures[0].rating == 12.5, "History survives reload")
	hunter.panel.history_min.value = 13
	check(hunter.panel.history_list.get_root().get_child_count() == 0 and hunter.config.min_rating == 11.5, "History UI filter is independent of capture settings")
	hunter.panel.history_min.value = 0
	check(hunter.panel.history_list.get_root().get_child_count() == 1, "History UI renders matching capture")
	hunter.panel.sync_fields()
	hunter.panel.rating.get_line_edit().text = "invalid"
	hunter.panel.apply_fields()
	check(hunter.panel.feedback.text.contains("number") and hunter.config.min_rating == 11.5, "UI rejects malformed rating input")
	hunter.panel.sync_fields()
	hunter.panel.apply_immediate("auto_level_up", false)
	check(not hunter.config.auto_level_up, "Auto level-up toggle applies immediately")
	hunter.panel.ids.text = "98, 99"
	hunter.panel.targets.text = "Blighted Flue, Mama"
	hunter.panel.rating.get_line_edit().text = "14.5"
	hunter.panel.apply_fields()
	check(hunter.config.object_ids == [99, 98] and hunter.config.miscrits == ["blighted flue"] and hunter.config.min_rating == 14.5, "Rating Apply does not edit hidden legacy IDs or names")
	hunter.config.skip_skill_animations = false

func test_repeated_capture():
	var cfg = hunter.normalize_config({"mode": "capture_any", "object_id": [98]})
	var s = state()
	var h = history()
	s.player.abilities = [ability(1, 7), ability(176, 7)]
	s.player.abilities[0].element = "Fire"
	s.player.abilities[1].element = "Physical"
	s.foe.hp = 115
	s.foe.chp = 115
	s.capture_chance = 1.0
	# Real response shape from the reported encounter: JSON IDs are floats.
	var response = JSON.parse_string('{"user_id":"test-player","id":1.0,"capture_chance":14.0,"actions":[{"type":"Attack","target":"Wild","damage":30.0,"crit":2.0}]}')
	policy.observe(response, 2, s, h)
	check(policy.damage_key(1.0, 2.0, 1.0) == policy.damage_key(1, 2, 1), "Float server IDs match integer client IDs")
	s.foe.chp = 85
	s.capture_chance = 14.0
	var decision = policy.decide(s, cfg, h)
	check(decision.action == "ability" and decision.get("id") == 1, "30 damage with 85 HP left repeats Burn")
	check(decision.get("observed_damage") == 30 and decision.get("remaining_hp_after_hit") == 55, "Repeat decision calculates remaining HP")
	policy.observe({"user_id": "Wild", "actions": [{"type": "Buff", "target": "Wild", "buffs": {"ea": 11.0}}]}, 2, s, h)
	check(policy.decide(s, cfg, h).action == "ability", "Enemy attack buff does not invalidate outgoing damage")
	policy.observe({"user_id": "Wild", "actions": [{"type": "Buff", "target": "Wild", "buffs": {"ed": -5.0}}]}, 2, s, h)
	s.foe.chp = 110
	check(policy.decide(s, cfg, h).action == "ability", "Relevant buff still allows another hit with ample HP")
	s.foe.chp = 60
	check(policy.decide(s, cfg, h).action == "flee", "Relevant buff increases damage guard near knockout")
	s.foe.chp = 110
	response.actions[0].damage = 35.0
	response.capture_chance = 40.0
	policy.observe(response, 2, s, h)
	s.foe.chp = 75
	s.capture_chance = 40
	decision = policy.decide(s, cfg, h)
	check(decision.action == "ability" and decision.get("estimate_uncertainty") == 1.0, "Fresh damage recalibrates the buff-adjusted estimate")
	var other = s.duplicate(true)
	other.foe.id = 3
	check(policy.decide(other, cfg, h).get("observed_damage") == 0, "Damage estimates do not transfer to a different target")
	# Re-evaluate after each own hit and enemy response until exactly 70%.
	s = state()
	s.foe.hp = 150
	s.foe.chp = 150
	s.capture_chance = 10.0
	h = history()
	for turn in range(4):
		decision = policy.decide(s, cfg, h)
		check(decision.action == "ability", "Continue weakening on turn %d below threshold" % turn)
		var update = {"user_id": "test-player", "id": 10.0, "capture_chance": s.capture_chance + 15.0,
			"actions": [{"type": "Attack", "target": "Wild", "damage": 20.0}]}
		policy.observe(update, 2, s, h)
		h.attacks += 1
		s.foe.chp -= 20
		s.capture_chance = update.capture_chance
		policy.observe({"user_id": "Wild", "actions": [{"type": "Attack", "target": "test-player", "damage": 1.0}]}, 2, s, h)
		if turn == 0:
			check(policy.decide(s, cfg, h).get("estimated_hits_to_threshold") == 2, "Stronger safe skill reduces estimated remaining hits")
	check(policy.decide(s, cfg, h).action == "capture", "Four measured hits stop at 70% and capture")
	h.flee = true
	check(policy.decide(s, cfg, h).action == "flee", "Failed capture still flees instead of attacking again")
	h.flee = false
	s.capture_chance = 69.99
	s.foe.chp = 32
	check(policy.decide(s, cfg, h).action == "flee", "Likely knockout is avoided even below capture threshold")

func test_capture_improvements():
	reset_hunt()
	var cfg = config()
	cfg.target_mode = "targeted"
	cfg.miscrits = ["Blighted Flue"]
	cfg.min_rating = 11
	hunter.apply_config(cfg)
	var target = {"id": 2, "mId": 19, "name": "Blighted Flue", "rating": 12}
	var other = {"id": 3, "mId": 20, "name": "Steamguin", "rating": 18}
	hunter.on_encounter([other, target])
	check(hunter.enabled and hunter.encounter_checked, "Two opponents accepted")
	check(hunter.select_active_foe(other) and hunter.history.fight, "Fight non-target even with target waiting")
	hunter.history.attacks = 9
	check(hunter.select_active_foe(target) and not hunter.history.fight and hunter.history.attacks == 0, "Switch to capture and reset target-specific history")
	hunter.capture_attempted = true
	hunter.select_active_foe(target)
	check(hunter.capture_attempted, "Same target preserves capture attempt")
	check(hunter.select_active_foe(other) and not hunter.capture_attempted, "Next opponent gets independent capture state")
	var s = state()
	var h = history()
	h.damage["1:2:10"] = 10
	var decision = policy.decide(s, config(), h)
	check(decision.action == "ability" and decision.id == 20, "Select stronger safely scaled skill")
	s.foe.chp = 60
	check(policy.decide(s, config(), h).id == 10, "Use weaker hit when stronger guard exceeds HP floor")
	h.incoming = {"1": 30}
	s.player.chp = 40
	check(policy.decide(s, config(), h).action == "capture", "Attempt capture before predicted teammate knockout")
	cfg.platinum_upgrade = "on"
	check(hunter.apply_config(cfg).is_empty() and hunter.config.platinum_upgrade, "Platinum toggle accepts on")
	cfg.platinum_upgrade = 7
	check(not hunter.validate_config(cfg).is_empty(), "Invalid platinum option rejected")
	hunter.enabled = true
	await hunter.heal_team()
	check(hunter.enabled and not hunter.healing and hunter.heal_retry_at > Time.get_ticks_msec(), "Unavailable heal waits without stopping automation")
	var original_player = server.Player
	var test_player = HealingPlayer.new()
	var m = BonusMiscrit.new()
	m.id = 900
	m.level = 11
	m.bonus_level = 10
	m.stats = {"hp": 100}
	m.chp = 0
	test_player.team.assign([900])
	test_player.miscrits[900] = m
	test_player.platinum = 3
	test_player.virtue = 20
	server.Player = test_player
	m.chp = 1
	check(not hunter.team_needs_heal(), "Injured living teammate does not trigger healing, even at one HP")
	m.chp = 0
	check(hunter.team_needs_heal(), "Dead teammate triggers healing")
	hunter.heal_success = true
	await hunter.heal_team()
	check(not hunter.team_needs_heal() and m.chp > 0 and test_player.virtue == 10, "Successful normal heal restores team and updates virtue")
	hunter.config.platinum_miscrit_ids = ["900"]
	await hunter.upgrade_platinum(m)
	check(m.bonus_applied and test_player.platinum == 2 and hunter.bonus_submissions == [900], "Bonus purchase applies stats and spends exactly one platinum")
	m.level = 12
	hunter.bonus_success = false
	await hunter.upgrade_platinum(m)
	check(not hunter.enabled and test_player.platinum == 2 and m.bonus_level == 11, "Failed bonus pauses without spending locally or advancing bonus level")
	server.Player = original_player

func test_area_routes():
	reset_hunt()
	hunter.pending_search = false
	hunter.area_ref = null
	var scene = Node2D.new()
	add_child(scene)
	var dead = RouteContainer.new()
	dead.name = "dead"
	scene.add_child(dead)
	var sand = RouteContainer.new()
	sand.name = "sand"
	scene.add_child(sand)
	var first = SearchObject.new()
	first.name = "rock"
	dead.add_child(first)
	var second = SearchObject.new()
	second.name = "castle"
	sand.add_child(second)
	var a = {"location": "sunfall_shores", "area_id": 1, "area": "Dead Island", "container": "dead", "object_id": 0, "object_name": "rock", "x": 20, "y": 40}
	var b = {"location": "sunfall_shores", "area_id": 2, "area": "Sand Castle", "container": "sand", "object_id": 0, "object_name": "castle", "x": 200, "y": 400}
	check(hunter.route_error([a, b]).is_empty(), "Duplicate numeric object IDs allowed in different sub-areas")
	check(not hunter.route_error([a, a]).is_empty(), "Duplicate exact route stops rejected")
	var invalid = b.duplicate()
	invalid.location = "forest"
	check(not hunter.route_error([a, invalid]).is_empty(), "Cross-map routes rejected")
	invalid = a.duplicate()
	invalid.container = "../outside"
	check(not hunter.route_error([invalid]).is_empty(), "Route cannot escape loaded map")
	invalid = a.duplicate()
	invalid.x = NAN
	check(not hunter.route_error([invalid]).is_empty(), "Invalid route coordinates rejected")
	check(hunter.resolve_route_object(scene, a) == first and hunter.resolve_route_object(scene, b) == second, "Resolve colliding object IDs by container")
	invalid = a.duplicate()
	invalid.object_name = "changed"
	check(hunter.resolve_route_object(scene, invalid) == null, "Changed object identity rejected")
	var cfg = config()
	cfg.cross_area_search = true
	cfg.search_route = [a, b]
	check(hunter.live_config(cfg, false).is_empty(), "Saved route activates without binding legacy IDs")
	hunter.pending_search = true
	var changed = cfg.duplicate(true)
	changed.search_route = [b, a]
	check(not hunter.live_config(changed, false).is_empty(), "Do not edit route during a submitted search")
	hunter.pending_search = false
	var original_player = server.Player
	var original_world_player = WorldManager.player
	var original_scene = WorldManager.location_node
	var original_lock = WorldManager.player_movement_lock
	var model = HealingPlayer.new()
	model.set_location({"name": "dead_island", "area_id": 1, "location": {"name": "sunfall_shores", "id": 5}})
	var m = BonusMiscrit.new()
	m.id = 900
	m.chp = 100
	m.stats = {"hp": 100}
	model.team.assign([900])
	model.miscrits[900] = m
	server.Player = model
	var avatar = RoutePlayer.new()
	scene.add_child(avatar)
	WorldManager.player = avatar
	WorldManager.location_node = scene
	WorldManager.player_movement_lock = 0
	hunter.enabled = true
	hunter.next_action = 0
	hunter.process_route(0.3)
	check(avatar.moves == 1 and hunter.route_submissions.is_empty(), "Move first without searching in same tick")
	hunter.next_action = 0
	server.active_rpcs["update_location"] = true
	hunter.process_route(0.3)
	check(hunter.route_submissions.is_empty(), "Wait for server area acknowledgement even if local area matches")
	server.active_rpcs.erase("update_location")
	hunter.process_route(0.3)
	check(hunter.route_submissions.size() == 1 and hunter.pending_search and hunter.route_cursor == 1, "Confirmed area searches once and advances route")
	hunter.process_route(0.3)
	check(hunter.route_submissions.size() == 1, "No duplicate search while waiting for result")
	hunter.encounter_checked = true
	hunter.leaving = true
	hunter.next_action = 0
	hunter.process_route(0.3)
	check(avatar.moves == 2 and avatar.global_position == Vector2(200, 400), "After battle move to next sub-area")
	hunter.next_action = 0
	hunter.process_route(0.3)
	check(hunter.route_submissions.size() == 1, "Wrong active area blocks searching next object")
	model.set_location({"name": "sand_castle", "area_id": 2, "location": {"name": "sunfall_shores", "id": 5}})
	second.available = false
	hunter.process_route(0.3)
	check(hunter.enabled and hunter.route_submissions.size() == 1, "Wait for per-object cooldown in confirmed area")
	second.available = true
	hunter.process_route(0.3)
	check(hunter.route_submissions.size() == 2 and hunter.route_cursor == 0, "Second area searches and route loops")
	hunter.pending_search = false
	hunter.route_target = hunter.route_key(a)
	hunter.route_deadline = Time.get_ticks_msec() - 1
	hunter.process_route(0.3)
	check(not hunter.enabled, "Unconfirmed transition times out safely")
	server.Player = original_player
	WorldManager.player = original_world_player
	WorldManager.location_node = original_scene
	WorldManager.player_movement_lock = original_lock
	hunter.reset_route()
	hunter.area_ref = null
	hunter.apply_config(config())
	scene.free()

func test_name_search():
	var cat = hunter.catalog
	check(cat.entries.size() >= 425, "Name catalog includes every bundled family")
	check(cat.suggestions("bl").is_empty(), "Autocomplete requires at least three characters")
	check(cat.suggestions(" BLI ").any(func(e): return e.name == "Blighted Flue"), "Autocomplete ignores case and spaces")
	check(cat.suggestions("bligted flue")[0].name == "Blighted Flue", "Typo in user example finds Blighted Flue")
	var plan = cat.plan(["blighted flue", "blighted flowerpiller"], "forest", 0, {}, {}, [])
	check(plan.stops.size() == 2, "Two selected species produce two exact stops")
	check(plan.stops[0].object_id == 99 and plan.stops[1].object_id == 98 and plan.stops.all(func(s): return s.location == "forest" and s.area_id == 4), "Blighted targets use Forest area 4 objects 99 and 98")
	check(cat.plan(["Blighted Flue", "blighted flue"], "forest", 0, {}, {}, []).stops.size() == 1, "Repeated target does not duplicate stop")
	check(cat.plan(["light flue"], "forest", 0, {}, {}, []).statuses["light flue"] == "Location unknown", "Missing location is not claimed unavailable")
	check(cat.plan(["does not exist"], "forest", 0, {}, {}, []).stops.is_empty(), "Unknown target never guesses an object")
	var common = cat.plan(["flue"], "forest", 6, {}, {}, [])
	check(not common.stops.is_empty(), "Common target resolves an area on any weekday")
	check(cat.plan(["freedom"], "forest", 0, {}, {}, []).stops.is_empty(), "Locked location cannot be selected")
	check(not cat.plan(["freedom"], "forest", 0, {"nature_elementum":true}, {}, []).stops.is_empty(), "Unlocked alternative map is usable")
	# Availability comes from catalog weekdays, independently of rarity.
	var sample = cat.by_name["blighted flue"].duplicate(true)
	sample.locations.Forest["4"] = [1, 3]
	check(cat.stop_error(sample, plan.stops[0], 2, {}, {}, []).contains("Unavailable today"), "Scheduled-out target is skipped")
	check(cat.stop_error(sample, plan.stops[0], 3, {}, {}, []).is_empty(), "Scheduled-in target is searchable")
	# Multiple locations: reject a locked first choice, use an accessible second.
	var alternate = sample.duplicate(true)
	alternate.name = "Test alternate"
	alternate.locations = {"Hidden Forest":{"1":[]}, "Forest":{"4":[]}}
	var locked_stop = plan.stops[0].duplicate(true)
	locked_stop.location = "hidden_forest"
	locked_stop.area_id = 1
	alternate.stops = [locked_stop, plan.stops[0]]
	cat.by_name["test alternate"] = alternate
	check(cat.plan(["test alternate"], "hidden_forest", 0, {}, {}, []).stops[0].location == "forest", "Planner chooses accessible alternative over locked current map")
	cat.by_name.erase("test alternate")

	hunter.pending_search = false
	hunter.name_traveling = false
	hunter.area_ref = null
	hunter.encounter_data = []
	hunter.encounter_checked = false
	var cfg = {"mode":"capture_targeted", "capture_id":[], "object_id":[], "auto_search":true, "min_rating":11}
	check(hunter.live_config(cfg, false).is_empty(), "Name mode accepts an empty editable list without manual IDs")
	hunter.panel.sync_fields()
	hunter.panel.name_query.text = "bli"
	hunter.panel.refresh_suggestions("bli")
	var index = -1
	for i in hunter.panel.name_suggestions.item_count:
		if hunter.panel.name_suggestions.get_item_metadata(i) == "Blighted Flue": index = i
	check(index >= 0, "Dropdown contains Blighted Flue")
	hunter.panel.add_name_target(index)
	hunter.panel.refresh_suggestions("blighted flower")
	hunter.panel.add_name_target(0)
	check(hunter.config.auto_search and hunter.config.miscrits == ["blighted flue", "blighted flowerpiller"] and hunter.config.object_ids.is_empty(), "Single-click selection appends multiple targets and removes manual IDs")
	check(not hunter.panel.ids.visible and not hunter.panel.targets.visible, "Manual ID and comma-separated inputs are hidden")
	var persisted = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(persisted.auto_search and persisted.capture_id.size() == 2, "Selected targets persist immediately")
	hunter.pending_search = true
	var changed = persisted.duplicate(true)
	changed.capture_id = ["mama"]
	check(not hunter.live_config(changed, false).is_empty(), "Submitted search prevents target/route replacement")
	hunter.pending_search = false

	var original_player = server.Player
	var original_avatar = WorldManager.player
	var original_scene = WorldManager.location_node
	var original_lock = WorldManager.player_movement_lock
	var model = HealingPlayer.new()
	model.set_location({"name":"forest", "area_id":1, "location":{"name":"forest", "id":2}})
	server.Player = model
	var scene = Node2D.new()
	scene.scene_file_path = "res://scenes/world/locations/scenes/forest/forest.tscn"
	add_child(scene)
	var folder = Node2D.new()
	folder.name = "objects"
	scene.add_child(folder)
	var searchable = Node2D.new()
	searchable.name = "searchable"
	folder.add_child(searchable)
	var area = RouteContainer.new()
	area.name = "area4"
	searchable.add_child(area)
	for i in range(100):
		var object = SearchObject.new()
		object.name = "placeholder_%d" % i
		area.add_child(object)
	for stop in plan.stops:
		var object = area.get_child(int(stop.object_id))
		object.name = stop.object_name
		object.scene_file_path = stop.object_scene
		object.position = Vector2(stop.x, stop.y)
	var avatar = RoutePlayer.new()
	scene.add_child(avatar)
	WorldManager.player = avatar
	WorldManager.location_node = scene
	WorldManager.player_movement_lock = 0
	hunter.name_stops = plan.stops
	hunter.name_day = Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_system())).weekday
	hunter.name_cursor = 0
	hunter.name_cooldowns.clear()
	hunter.route_submissions.clear()
	hunter.name_location_requests.clear()
	hunter.enabled = true
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	check(hunter.name_location_requests.size() == 1 and model.area.id == 4 and hunter.route_submissions.is_empty(), "Confirm area RPC before moving or searching")
	WorldManager.acquire_move_lock()
	check(hunter.route_area_confirmed(plan.stops[0]) and not hunter.route_area_ready(plan.stops[0]), "Search-owned movement lock preserves area confirmation but blocks new scheduling")
	WorldManager.release_move_lock()
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	check(avatar.moves >= 1 and hunter.route_submissions.is_empty(), "Move to resolved object before searching")
	hunter.next_action = 0
	server.active_rpcs["update_location"] = true
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.is_empty(), "Pending location acknowledgement blocks name search")
	server.active_rpcs.erase("update_location")
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 1 and hunter.active_object_id == 99 and hunter.name_cursor == 1, "First selected species searches exact object once")
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 1, "Pending search cannot submit twice")
	hunter.encounter_checked = true
	hunter.leaving = true
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 2 and hunter.active_object_id == 98 and hunter.name_cursor == 0, "Next selected species searches its own object and cycles")
	hunter.pending_search = false
	hunter.enabled = false
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 2, "Pause blocks new search actions")
	hunter.enabled = true
	hunter.name_travel_success = false
	var before_area = model.area.id
	await hunter.travel_for_name(plan.stops[0])
	check(not hunter.enabled and model.area.id == before_area and not hunter.name_traveling and WorldManager.player_movement_lock == 0, "Rejected travel leaves local location unchanged and unlocks inputs")
	hunter.name_travel_success = true
	hunter.enabled = true
	hunter.pause_on_travel = true
	scene.scene_file_path = "res://other_map.tscn"
	await hunter.travel_for_name(plan.stops[0])
	check(not hunter.enabled and hunter.name_loads.size() == 1 and scene.scene_file_path.ends_with("forest/forest.tscn"), "Pause during accepted travel finishes scene sync without resuming automation")
	hunter.pause_on_travel = false
	hunter.name_stops = plan.stops.duplicate(true)
	hunter.name_stops[0].search_mode = "area_scan"
	hunter.name_cursor = 0
	hunter.name_traveling = false
	hunter.enabled = true
	hunter.next_action = 0
	area.searchable = false
	hunter.process_name_search(0.3)
	check(hunter.enabled and hunter.name_cursor == 1 and hunter.route_submissions.size() == 2, "Area scan skips unavailable objects without stopping or sending a search")
	area.searchable = true
	hunter.name_stops = plan.stops.duplicate(true)
	hunter.enabled = true
	hunter.next_action = 0
	area.get_child(99).name = "changed_mapping"
	hunter.name_cursor = 0
	hunter.process_name_search(0.3)
	check(not hunter.enabled and hunter.route_submissions.size() == 2, "Changed scene object is rejected before search")
	area.get_child(99).name = plan.stops[0].object_name
	var search_object = area.get_child(99)
	search_object.in_range = false
	hunter.enabled = true
	hunter.name_move_key = ""
	hunter.pending_search = false
	for attempt in range(2):
		hunter.next_action = 0
		hunter.process_name_search(0.3)
	check(hunter.enabled and hunter.name_move_attempts == 2 and hunter.route_submissions.size() == 2, "Drifted search position gets a bounded reposition without any search RPC")
	search_object.in_range = true
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 3 and hunter.pending_search, "Recovered search position submits exactly once")
	hunter.pending_search = false
	hunter.name_cursor = 0
	hunter.name_move_key = ""
	search_object.in_range = false
	for attempt in range(4):
		hunter.next_action = 0
		hunter.process_name_search(0.3)
	check(hunter.enabled and hunter.name_move_attempts == 3 and hunter.route_submissions.size() == 3 and hunter.name_skipped_stops.has(hunter.route_key(plan.stops[0])), "Unreachable position is quarantined after three moves while other targets remain active")
	search_object.in_range = true
	for attempt in range(2):
		hunter.next_action = 0
		hunter.process_name_search(0.3)
	check(hunter.route_submissions.size() == 4 and hunter.active_object_id == 98, "Other target continues searching after a failed position")
	hunter.pending_search = false
	hunter.next_action = 0
	hunter.process_name_search(0.3)
	check(hunter.name_cursor == 1 and hunter.route_submissions.size() == 4, "Next cycle skips the quarantined object without another placement or search")
	hunter.skip_name_stop(plan.stops[1], Time.get_ticks_msec(), "Test unreachable second object")
	check(not hunter.enabled and hunter.name_skipped_stops.size() == 2, "All blocked stops produce one explicit pause instead of a busy retry loop")
	var blocked_plan = hunter.name_plan()
	check(blocked_plan.stops.is_empty() and blocked_plan.statuses["blighted flue"].begins_with("No reachable"), "Target status no longer claims Ready for quarantined-only routes")
	hunter.reset_name_search()
	check(hunter.name_skipped_stops.is_empty() and hunter.name_plan().stops.size() == 2, "Re-arming clears skipped positions and permits an intentional retry")
	var submitted_before_timeout = hunter.name_location_requests.size()
	hunter.enabled = true
	hunter.name_traveling = true
	hunter.name_travel_deadline = Time.get_ticks_msec() - 1
	hunter._process(0.3)
	hunter.toggle_running()
	check(not hunter.enabled and hunter.name_location_requests.size() == submitted_before_timeout, "Timed-out travel and premature restart cannot send a second request")
	hunter.name_traveling = false
	server.Player = original_player
	WorldManager.player = original_avatar
	WorldManager.location_node = original_scene
	WorldManager.player_movement_lock = original_lock
	hunter.pending_search = false
	hunter.area_ref = null
	hunter.reset_name_search()
	hunter.apply_config(config())
	scene.free()
	# A rejected hook must return before touching the real socket/RPC.
	var parent = hunter.get_parent()
	var previous_name = hunter.name
	hunter.reparent(server)
	hunter.name = "MamaHunter"
	hunter.apply_config({"mode":"capture_targeted", "auto_search":true, "capture_id":["blighted flue"], "object_id":[]})
	hunter.enabled = true
	hunter.name_active = {}
	var rejected = await server.create_wild_battle(99)
	check(rejected is Dictionary and not rejected.success and not hunter.enabled, "Invalid name search is cancelled before the real network RPC")
	hunter.reparent(parent)
	hunter.name = previous_name
	hunter.apply_config(config())

func test_catalog_update():
	var cat = hunter.catalog
	check(cat.entries.size() == 434, "Official feed contains all 434 Miscrit families")
	var unlocked = {"nature_elementum":true, "earth_elementum":true, "wind_elementum":true, "water_elementum":true, "magicite_general":true, "magicite_warden":true, "singularitas":true, "ylil_nosaj":true, "the_temple_trial":true}
	var tickets = {"moon":true, "shack":true, "emerald_isle":true, "temple":true}
	var events = ["vi_intro_nox_talk", "visit_monks_mountain"]
	for name in ["plymouth", "dark chinook", "deurus", "vowlet"]:
		var result = cat.plan([name], "monks_mountain", 0, unlocked, tickets, events)
		check(result.stops.size() == 1 and result.stops[0].object_scene.ends_with(name.replace(" ", "_") + "_object.tscn"), "New dedicated spawn maps to its named object: " + name)
	for name in ["elektick", "prismo"]:
		check(not cat.plan([name], "monks_mountain", 0, unlocked, tickets, events).stops.is_empty(), "New common species has searchable area objects: " + name)
	for name in ["minosoar", "giggles", "dark nero"]:
		var day = int(cat.by_name[name].locations["Monks Mountain"].values()[0][0])
		var result = cat.plan([name], "monks_mountain", day, unlocked, tickets, events)
		check(result.stops.size() > 3 and result.statuses[name].begins_with("Area scan:"), "New rare species honestly uses a full area scan: " + name)
	var dark = cat.plan(["dark flowerpiller"], "forest", 2, unlocked, tickets, events)
	check(not dark.stops.is_empty() and dark.statuses["dark flowerpiller"].begins_with("Ready:"), "Referenced any-object species now has mapped search objects")
	check(dark.stops.all(func(s): return s.location == "forest" and int(s.area_id) == 4), "Area scan stays within the officially listed area")
	check(cat.plan(["dark flowerpiller"], "forest", 0, unlocked, tickets, events).stops.is_empty(), "Area scan respects official spawn weekdays")
	check(cat.plan(["dark chinook"], "forest", 0, unlocked, tickets, []).stops.is_empty(), "New mapping respects the Monk's Mountain visit requirement")
	for entry in cat.entries:
		if not entry.locations.is_empty():
			check(not cat.search_stops(entry).is_empty(), "Every officially located species has a supported search area: " + entry.name)
		else:
			check(cat.search_stops(entry).is_empty(), "Species without a wild location never gets an invented route: " + entry.name)
	var size_before = cat.entries.size()
	cat.merge_metadata({"id":999001, "name":"Future family", "names":["Future family"], "rarity":"Rare", "locations":{"Forest":{"2":[1]}}})
	var future = cat.plan(["future family"], "forest", 1, unlocked, tickets, events)
	check(not future.stops.is_empty() and future.stops.all(func(s): return s.location == "forest" and int(s.area_id) == 2), "Future runtime species can use an inspected area without a patch")
	cat.merge_metadata({"id":999001, "name":"Renamed family", "names":["Renamed family"], "rarity":"Rare", "locations":{"Forest":{"3":[2]}}})
	check(cat.entries.size() == size_before + 1 and not cat.by_name.has("future family"), "Runtime ID prevents duplicates after a species rename")
	check(cat.plan(["renamed family"], "forest", 1, unlocked, tickets, events).stops.is_empty(), "Runtime schedule changes replace stale availability")
	cat.by_name.erase("renamed family")
	cat.entries.erase(cat.by_id[999001])
	cat.by_id.erase(999001)
	check(cat.entries.filter(func(e): return e.get("mapping_status") == "mapped").size() == 395, "Evidence-backed catalog covers 395 families")
	check(cat.by_name["patrik"].stops[0].object_scene.ends_with("patrick_statue_right.tscn"), "Patrik uses the statue rather than the nearer crystal")
	check(cat.by_name["thundercracker"].stops.size() == 4, "Thundercracker uses the four referenced cliff objects")
	check(cat.by_name["phoboros"].stops[0].object_scene.ends_with("coffin03.tscn"), "Phoboros uses the pictured upright coffin")
	check(cat.by_name["wisper"].stops[0].object_scene.ends_with("temple_rubble2.tscn"), "Wisper uses the referenced broken column")
	check(cat.by_name["magixio"].stops[0].object_scene.ends_with("pyramid_chest02.tscn"), "Magixio uses the referenced blue chest")
	check(cat.by_name["rocapez"].stops[0].object_scene.ends_with("pyramid_magic_chest.tscn"), "Rocapez uses the referenced gold scarab chest")
	check(cat.by_name["neolith"].stops.all(func(s): return s.live_verified), "Historical observations retain verified object identity after the client update")

func test_mapping_learning():
	var cat = hunter.catalog
	var unlocked = {"water_elementum": true}
	var events = ["visit_monks_mountain"]
	var initial = cat.plan(["dark nero"], "monks_mountain", 1, unlocked, {}, events)
	var stop = initial.stops[0].duplicate(true)
	var before = cat.learned_records.size()
	check(initial.statuses["dark nero"].begins_with("Area scan:"), "Unconfirmed species starts with an honest area scan")
	check(not cat.observe_wild(762, stop, "Arena"), "Arena battles never establish wild spawn mappings")
	var wrong = stop.duplicate(true)
	wrong.object_name = "different_object"
	check(not cat.observe_wild(762, wrong, "Wild"), "Observed mapping must match the actual audited object identity")
	wrong = stop.duplicate(true)
	wrong.area_id = 1
	check(not cat.observe_wild(762, wrong, "Wild"), "Observed mapping cannot contradict the official area")
	wrong = stop.duplicate(true)
	wrong.scene = "../unrelated.tscn"
	check(not cat.observe_wild(762, wrong, "Wild"), "An unaudited scene cannot become a learned route")
	check(not cat.observe_wild(999998, stop, "Wild"), "Unknown species IDs cannot authorize a learned mapping")
	hunter.learn_wild_mapping("missing_request", [{"mId":762}], "Wild")
	check(cat.learned_records.size() == before, "A battle without its matching search context is not learned")
	hunter.mapping_matches["fractional_species"] = stop
	hunter.learn_wild_mapping("fractional_species", [{"mId":762.5}], "Wild")
	check(cat.learned_records.size() == before, "Malformed species IDs do not alias a real family")
	hunter.mapping_matches["bonus_only"] = stop
	hunter.learn_wild_mapping("bonus_only", [{"mId":999998}, {"mId":762}], "Wild")
	check(cat.learned_records.size() == before, "An additional opponent cannot establish the primary object's spawn")
	hunter.mapping_matches["arena_request"] = stop
	hunter.learn_wild_mapping("arena_request", [{"mId":762}], "Arena")
	check(cat.learned_records.size() == before, "Non-wild battle context is discarded")
	hunter.mapping_matches["confirmed_request"] = stop
	hunter.learn_wild_mapping("confirmed_request", [{"mId":762}], "Wild")
	check(cat.learned_records.size() == before + 1 and not hunter.mapping_matches.has("confirmed_request"), "Confirmed primary wild encounter learns once and consumes its request context")
	check(not cat.observe_wild(762, stop, "Wild") and cat.learned_records.size() == before + 1, "Repeated encounters do not duplicate a learned stop")
	var reloaded = load("res://capture_catalog.gd").new()
	var learned = reloaded.plan(["dark nero"], "monks_mountain", 1, unlocked, {}, events)
	check(learned.stops.size() == 1 and learned.stops[0].live_verified and learned.statuses["dark nero"].begins_with("Ready:"), "Learned exact mapping survives reload and replaces the area scan")
	check(reloaded.plan(["dark nero"], "monks_mountain", 0, unlocked, {}, events).stops.is_empty(), "Learned mapping still respects the official weekday")
	check(reloaded.plan(["dark nero"], "forest", 1, {}, {}, events).stops.is_empty(), "Learned mapping cannot bypass map access requirements")
	var original = reloaded.by_id[762].locations.duplicate(true)
	reloaded.by_id[762].locations = {"Monks Mountain":{"3":[1]}}
	var changed = reloaded.plan(["dark nero"], "monks_mountain", 1, unlocked, {}, events)
	check(changed.stops.all(func(s): return int(s.area_id) == 3) and changed.statuses["dark nero"].begins_with("Area scan:"), "Runtime location changes invalidate stale learned areas")
	reloaded.by_id[762].locations = original

func test_mapping_resources():
	# Instantiate the real map resources off-tree: _ready/network hooks never run.
	# This verifies wire IDs against actual Godot child ordering, not JSON alone.
	var previous = server.Player
	server.Player = HealingPlayer.new()
	var scenes = {}
	var checked = {}
	var routes = []
	for entry in hunter.catalog.entries: routes.append_array(entry.stops)
	routes.append_array(hunter.catalog.data.get("area_objects", []))
	for item in routes:
		var key = hunter.route_key(item) + ":" + item.scene
		if checked.has(key): continue
		checked[key] = true
		if not scenes.has(item.scene):
			var resource = load("res://" + item.scene)
			check(resource is PackedScene, "Mapped map resource exists: " + item.scene)
			if not resource is PackedScene: continue
			scenes[item.scene] = resource.instantiate()
		var object = hunter.resolve_route_object(scenes[item.scene], item)
		check(object != null and object.scene_file_path == item.object_scene, "Real map binding: " + key)
	for scene in scenes.values(): scene.free()
	server.Player = previous
	print("SCENE MAPPING AUDIT: ", checked.size(), " distinct bindings in ", scenes.size(), " scenes")
	test_rocapez_position()
	test_unreachable_search_objects()

func test_unreachable_search_objects():
	var previous_player = server.Player
	var previous_avatar = WorldManager.player
	var model = HealingPlayer.new()
	server.Player = model
	var avatar = RoutePlayer.new()
	add_child(avatar)
	WorldManager.player = avatar
	var scenes = {}
	var identities = ["mansion:1:28", "sunfall_shores:2:79", "sunfall_shores:2:81", "sunfall_shores:2:82", "temple:3:0"]
	var audited = 0
	for raw in hunter.catalog.data.area_objects:
		var identity = "%s:%d:%d" % [raw.location, int(raw.area_id), int(raw.object_id)]
		if not identity in identities: continue
		audited += 1
		var item = raw.duplicate(true)
		item.targets = ["audit scan"]
		item.search_mode = "area_scan"
		if not scenes.has(item.scene): scenes[item.scene] = load("res://" + item.scene).instantiate()
		var scene = scenes[item.scene]
		var object = hunter.resolve_route_object(scene, item)
		model.set_location({"name":item.location,"area_id":int(item.area_id),"location":{"name":item.location,"id":0}})
		hunter.reset_name_search()
		hunter.name_stops = [item]
		hunter.enabled = true
		var before = avatar.moves
		check(not hunter.move_for_name(scene, object, item, Time.get_ticks_msec()), "Real unreachable scan is rejected before movement: " + identity)
		check(not hunter.enabled and avatar.moves == before and hunter.name_skipped_stops.has(hunter.route_key(item)), "Real unreachable scan is quarantined without a teleport or search RPC: " + identity)
	check(audited == 5, "All five out-of-range objects from the full map audit are regression tested")
	for scene in scenes.values(): scene.free()
	hunter.reset_name_search()
	avatar.free()
	server.Player = previous_player
	WorldManager.player = previous_avatar

func test_rocapez_position():
	var original_player = server.Player
	var original_avatar = WorldManager.player
	var model = HealingPlayer.new()
	model.set_location({"name":"temple", "area_id":5, "location":{"name":"temple", "id":0}})
	server.Player = model
	var avatar = RoutePlayer.new()
	add_child(avatar)
	WorldManager.player = avatar
	var stop = hunter.catalog.by_name["rocapez"].stops[0]
	var scene = load("res://" + stop.scene).instantiate()
	var object = hunter.resolve_route_object(scene, stop)
	var proxy = Node2D.new()
	proxy.position = object.global_position + Vector2(0, 35)
	avatar.global_position = hunter.name_search_position(scene, proxy)
	check(not object.check_user_entered(), "Real Rocapez nav mesh reproduces the old +35 position outside Temple's 80-unit range")
	var position = hunter.name_search_position(scene, object)
	avatar.teleport(position)
	check(object.check_user_entered() and position.distance_to(object.global_position) < 75, "Real Rocapez mesh produces a reachable search point within 75 units")
	proxy.position = position
	check(hunter.name_search_position(scene, proxy).distance_to(position) < 0.1, "Rocapez approach point remains on the navigation mesh after projection")
	# All four searchable objects in this room use the same positioning path.
	for other in scene.get_node("objects/searchable").get_children():
		avatar.teleport(hunter.name_search_position(scene, other))
		check(other.check_user_entered(), "Reachable Temple room object: " + str(other.name))
	var isolated = Node2D.new()
	var region = NavigationRegion2D.new()
	var mesh = NavigationPolygon.new()
	mesh.vertices = PackedVector2Array([Vector2(0,0),Vector2(100,0),Vector2(100,100),Vector2(0,100)])
	mesh.add_polygon(PackedInt32Array([0,1,2,3]))
	region.navigation_polygon = mesh
	region.position = Vector2(200,300)
	isolated.add_child(region)
	proxy.position = Vector2(180,350)
	check(hunter.name_search_position(isolated, proxy).distance_to(Vector2(200,350)) < 0.1, "Approach calculation respects navigation region transforms")
	region.enabled = false
	check(hunter.name_search_position(isolated, proxy) == proxy.position + Vector2(0,35), "Disabled navigation regions are excluded")
	region.enabled = true
	region.visible = false
	check(hunter.name_search_position(isolated, proxy).distance_to(Vector2(200,350)) < 0.1, "Invisible navigation regions remain walkable as they do in the game")
	isolated.free()
	proxy.free()
	scene.free()
	avatar.free()
	server.Player = original_player
	WorldManager.player = original_avatar

func test_platinum_training():
	reset_hunt()
	var original = server.Player
	var player = HealingPlayer.new()
	var m = TrainMiscrit.new()
	m.ready = false
	m.price = 4
	player.team.assign([123])
	player.miscrits[123] = m
	player.platinum = 10
	server.Player = player
	hunter.config.platinum_training = true # Legacy config must never enable paid levels.
	hunter.config.auto_level_up = true
	hunter.config.platinum_upgrade = true
	hunter.config.platinum_miscrit_ids = ["123"]
	hunter.training_submissions.clear()
	hunter.bonus_submissions.clear()
	await hunter.train_miscrit(m)
	check(hunter.training_submissions.is_empty() and player.platinum == 10, "Insufficient XP never buys levels even with legacy paid setting")
	check(not hunter.normalize_config(hunter.config).has("platinum_training"), "Legacy paid level setting is removed")
	var replacement = TrainMiscrit.new()
	replacement.id = 999
	player.miscrits[999] = replacement
	m.ready = true
	m.price = 0
	hunter.training_success = true
	hunter.after_training = func():
		await get_tree().process_frame
		hunter.config.platinum_miscrit_ids = []
	await hunter.train_miscrit(m)
	check(m.level == 11 and player.platinum == 10, "Earned XP level is free")
	check(hunter.bonus_submissions.is_empty(), "Deselect during free level await blocks paid bonus")
	hunter.config.platinum_miscrit_ids = ["123"]
	hunter.after_training = func():
		await get_tree().process_frame
		player.team.assign([999])
	await hunter.train_miscrit(m)
	check(hunter.bonus_submissions.is_empty() and player.platinum == 10, "Team change during await blocks paid bonus")
	hunter.after_training = Callable()
	hunter.training_success = false
	var panel = hunter.panel
	panel.refresh_platinum_slots()
	check(panel.platinum_slots.size() == 4 and panel.platinum_slots[1].disabled, "Four slots shown and empty slots disabled")
	check(not panel.platinum_slots[0].button_pressed, "Replacement UI remains unchecked")
	player.team.assign([123, 999])
	panel.refresh_platinum_slots()
	check(panel.platinum_slots[0].button_pressed and panel.platinum_slots[0].text.contains("Level 12"), "UI refreshes current level and selected individual")
	player.team.assign([999, 123])
	panel.refresh_platinum_slots()
	check(not panel.platinum_slots[0].button_pressed and panel.platinum_slots[1].button_pressed, "Selection follows individual across team reorder")
	panel.platinum_slots[0].button_pressed = true
	check(hunter.config.platinum_miscrit_ids.has("999"), "Slot toggle saves individual ID")
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(saved.platinum_miscrit_ids.has("999"), "Selected individual ID persists to disk")
	panel.platinum_slots[0].button_pressed = false
	check(not hunter.config.platinum_miscrit_ids.has("999"), "Slot toggle revokes permission")
	server.Player = original

func test_rated_capture():
	reset_hunt()
	var cfg = config()
	cfg.mode = "capture_rated"
	cfg.object_id = [98, 99]
	cfg.capture_id = ["Aquarion"]
	cfg.min_rating = 13.0
	cfg.other_min_rating = 16.0
	check(hunter.apply_config(cfg).is_empty(), "Combined capture mode is accepted")
	for example in [
		["Aquarion", 13.0, "match"], ["Aquarion", 12.99, "miss"],
		["Other", 16.0, "match"], ["Other", 15.99, "miss"],
		["Other", 13.0, "miss"], [" AQUARION ", 14.0, "match"]]:
		check(hunter.classify_encounter([{"name": example[0], "rating": example[1]}]) == example[2], "Independent threshold: " + str(example))
	check(hunter.classify_encounter([{"name": "Other"}]) == "unknown", "Missing rating cannot authorize capture")
	check(hunter.classify_encounter([{"rating": 17}]) == "unknown", "Missing name cannot select a rating rule")
	check(hunter.classify_encounter([{"name": "Other", "rating": NAN}]) == "unknown", "Nonfinite rating rejected")
	hunter.select_active_foe({"id": 1, "name": "Other", "rating": 15.9})
	check(hunter.history.fight, "Low-rated non-target is fought")
	hunter.select_active_foe({"id": 2, "name": "Other", "rating": 16})
	check(not hunter.history.fight, "High-rated non-target is captured in mixed encounter")
	cfg.min_rating = 17.0
	check(hunter.apply_config(cfg).is_empty(), "Target threshold can exceed other threshold")
	check(hunter.classify_encounter([{"name": "Aquarion", "rating": 16}]) == "miss", "Selected species never bypasses its own threshold via other rule")
	hunter.panel.sync_fields()
	check(hunter.panel.mode.selected == 3 and hunter.panel.other_rating.value == 16, "Combined selector and other rating reflect saved config")
	hunter.panel.rating.get_line_edit().text = "13.5"
	hunter.panel.other_rating.get_line_edit().text = "16.5"
	hunter.panel.apply_fields()
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(saved.min_rating == 13.5 and saved.other_min_rating == 16.5, "Both thresholds persist independently")
	for invalid in [-1, 19, "bad", NAN]:
		cfg.other_min_rating = invalid
		check(not hunter.validate_config(cfg).is_empty(), "Reject invalid other rating: " + str(invalid))
	hunter.panel.apply_immediate("mode", "capture_targeted")
	check(hunter.panel.mode.selected == 2 and not hunter.panel.other_rating_field.visible, "Target-only mode hides the unused other-species rating")
	check(hunter.classify_encounter([{"name": "Other", "rating": 18}]) == "miss", "Target-only mode excludes other species")
	check(hunter.panel.tabs.get_tab_count() == 4, "Only Controls, Team, Captures and Battles remain")
	for index in range(hunter.panel.tabs.get_tab_count()):
		check(hunter.panel.tabs.get_tab_title(index) != "Objects", "Objects menu removed")

func test_manual_target_battle():
	reset_hunt()
	var cfg = {"mode":"manual_target", "capture_id":["Blighted Flue"], "object_id":[98,99], "min_rating":18}
	check(hunter.live_config(cfg).is_empty(), "Manual-target mode validates, saves, and normalizes")
	check(hunter.config.combat_mode == "manual_target" and hunter.config.target_mode == "targeted", "Manual mode retains the selected target list")
	hunter.panel.sync_fields()
	check(hunter.panel.mode.item_count == 5 and hunter.panel.mode.selected == 4 and not hunter.panel.rating_fields.visible, "Manual battle selection reflects the saved choice and hides unused rating fields")
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(saved.mode == "manual_target", "Manual battle option persists across restarts")
	hunter.pending_search = false
	hunter.panel.save_name_targets(["blighted flue", "mama"])
	check(hunter.config.combat_mode == "manual_target" and hunter.config.auto_search and hunter.config.miscrits == ["blighted flue","mama"], "Adding search targets preserves manual battle mode")
	for foe in [{"name":" Blighted Flue ","rating":0}, {"name":"Blighted Flue"}, {"name":"Blighted Flue","rating":NAN}]:
		check(hunter.classify_encounter([foe]) == "match", "Manual handoff matches the selected species without a rating threshold")
	check(hunter.classify_encounter([{"name":"Other","rating":18}]) == "miss", "High-rated non-target does not trigger manual handoff")
	check(hunter.classify_encounter([{}]) == "unknown", "Missing opponent name remains an invalid encounter")
	reset_hunt()
	hunter.apply_config(cfg)
	hunter.on_encounter([{"name":"Other","rating":18}])
	check(hunter.enabled and hunter.history.fight and hunter.manual_battle_id.is_empty(), "Non-target encounters remain under automatic fighting")
	hunter.on_encounter([{"name":"Other"},{"name":"Blighted Flue","rating":0}])
	check(not hunter.enabled and hunter.needs_rearm and hunter.manual_battle_id == "capture-test" and hunter.encounter_checked, "Selected species in any opponent slot pauses before combat")
	var fake = FakeBattle.new()
	hunter.submissions.clear()
	# The handoff guard also protects against an accidental enabled flag change.
	hunter.enabled = true
	for action in [{"action":"ability","id":20},{"action":"capture"},{"action":"flee"}]:
		hunter.perform_decision(fake, action, Time.get_ticks_msec())
	check(hunter.submissions.is_empty() and fake.action_bar.flees == 0 and fake.capture_control.attempts == 0 and not fake.capture_control.capture_button.disabled, "Manual handoff sends no attack, capture, or flee action and leaves battle controls available")
	hunter.enabled = false
	var animator = get_tree().root.get_node("BattleAnimator")
	var original_battle = animator.battle
	var original_scene = WorldManager.location_node
	var original_loading = WorldManager.loading_lock
	var battle = StudyBattle.new()
	add_child(battle)
	animator.battle = battle
	hunter.toggle_running()
	check(not hunter.enabled and hunter.manual_battle_id == "capture-test", "Start/F8 cannot take control while the manual battle is still open")
	var summary = ManualSummary.new()
	add_child(summary)
	hunter.on_summary_ready(summary, "Wild")
	hunter._process(0.3)
	check(summary.continues == 0 and not hunter.enabled, "Manual battle summary is left for the player to close")
	hunter.on_flee_result(true)
	check(not hunter.enabled and not hunter.leaving, "Manual flee response never resumes searching")
	animator.battle = null
	WorldManager.location_node = null
	hunter.toggle_running()
	check(not hunter.enabled, "Scene loading after a manual battle cannot prematurely resume automation")
	var world = Node2D.new()
	add_child(world)
	WorldManager.location_node = world
	WorldManager.loading_lock = false
	check(not hunter.manual_battle_open() and not hunter.enabled, "Returning to the world leaves searching paused until the player resumes")
	hunter.toggle_running()
	check(hunter.enabled and hunter.manual_battle_id.is_empty() and not hunter.pending_search, "Explicit Start/F8 re-arms searching after the manual battle is closed")
	animator.battle = original_battle
	WorldManager.location_node = original_scene
	WorldManager.loading_lock = original_loading
	world.free()
	phase_cleanup_manual(summary, battle)
	reset_hunt()
	hunter.apply_config(cfg)
	hunter.on_encounter([{}])
	check(not hunter.enabled and hunter.manual_battle_id.is_empty(), "Invalid manual-mode encounter is left open without taking any action")
	reset_hunt()
	hunter.apply_config(cfg)
	server.current_battle_id = "unrelated-manual-test"
	hunter.on_encounter([{"name":"Blighted Flue"}])
	check(hunter.manual_battle_id.is_empty() and not hunter.encounter_checked, "Unrelated battles cannot trigger a handoff for this search")
	reset_hunt()
	hunter.apply_config({"mode":"capture_targeted","capture_id":["blighted flue"],"object_id":[98],"min_rating":0})
	hunter.on_encounter([{"name":"Blighted Flue","rating":1}])
	check(hunter.enabled and hunter.manual_battle_id.is_empty(), "Existing automatic capture mode does not acquire manual handoff behavior")
	reset_hunt()
	hunter.encounter_data = [{"name":"Blighted Flue","rating":0}]
	hunter.encounter_checked = true
	check(hunter.live_config(cfg, false).is_empty() and not hunter.enabled and hunter.manual_battle_id == "capture-test", "Switching to manual mode during a matching encounter immediately pauses future actions")
	reset_hunt()

func test_search_cooldown_timing():
	var previous = server.Player
	var previous_cooldowns = hunter.cooldowns.duplicate(true)
	var model = HealingPlayer.new()
	server.Player = model
	var stop = hunter.catalog.by_name["blighted flue"].stops[0].duplicate(true)
	stop.targets = ["blighted flue"]
	for reduced in [false, true]:
		model.left_traits.clear()
		if reduced: model.left_traits.append(100)
		var duration = 21000 if reduced else 31000
		check(hunter.search_cooldown_msec() == duration, "Search wait matches the game's trait-dependent cooldown")
		for outcome in ["match", "drop", "cooldown"]:
			reset_hunt()
			hunter.apply_config({"mode":"capture_targeted","capture_id":["blighted flue"],"object_id":[],"auto_search":true})
			hunter.name_active = stop
			hunter.name_cooldowns.clear()
			hunter.active_object_id = int(stop.object_id)
			var data = {"matchId":"cooldown-timing-test"} if outcome == "match" else {outcome:true}
			var before = Time.get_ticks_msec()
			hunter.on_search_result(int(stop.object_id), {"success":outcome == "match","data":data})
			var remaining = hunter.name_cooldowns[hunter.route_key(stop)] - before
			check(remaining >= duration and remaining < duration + 1000, "Per-object search wait uses native timing for " + outcome)
			if outcome == "cooldown":
				var numeric_wait = hunter.cooldowns[int(stop.object_id)] - before
				check(numeric_wait >= duration and numeric_wait < duration + 1000, "Server rejection backoff also respects the cooldown-reduction trait")
			check(hunter.next_action < before + 2000, "An object cooldown does not add a global 31-second wait")
	server.Player = null
	check(hunter.search_cooldown_msec() == 31000, "Missing player metadata retains the native default cooldown")
	server.Player = previous
	hunter.name_active = {}
	hunter.name_cooldowns.clear()
	hunter.cooldowns = previous_cooldowns
	reset_hunt()

func test_flee_unwanted_encounters():
	reset_hunt()
	check(not hunter.config.flee_non_targets, "Existing settings default to fighting unwanted encounters")
	var cfg = {"mode":"capture_targeted","capture_id":["blighted flue"],"object_id":[98,99],"min_rating":10,"flee_non_targets":true}
	for bad in [null, 0, 1, "true", [], {}]:
		var invalid = cfg.duplicate(true)
		invalid.flee_non_targets = bad
		check(not hunter.validate_config(invalid).is_empty(), "Run option rejects non-boolean values")
	check(hunter.live_config(cfg).is_empty(), "Run option saves and applies")
	hunter.panel.sync_fields()
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(hunter.panel.flee_others.button_pressed and saved.flee_non_targets, "Run switch reflects the saved choice")
	hunter.apply_config(saved)
	check(hunter.config.flee_non_targets, "Run option survives settings reload")
	hunter.on_encounter([{"name":"Other","rating":18}])
	var s = state()
	s.capture_chance = null
	s.player.chp = 1
	var heal = ability(77, 30)
	heal.type = "Heal"
	heal.target = "Self"
	s.player.abilities.append(heal)
	check(hunter.battle_decision(s).action == "flee", "Unwanted encounter flees without attacking, healing, or requiring capture chance")
	hunter.select_active_foe({"id":2,"name":"Other","rating":18})
	check(hunter.history.flee_non_target and hunter.battle_decision(s).action == "flee", "Active opponent initialization preserves the unwanted-encounter decision")
	var fake = FakeBattle.new()
	hunter.submissions.clear()
	hunter.perform_decision(fake, hunter.battle_decision(s), Time.get_ticks_msec())
	hunter.perform_decision(fake, hunter.battle_decision(s), Time.get_ticks_msec())
	check(fake.action_bar.flees == 1 and hunter.submissions.is_empty() and fake.capture_control.attempts == 0, "One pending flee submits no attack or capture and cannot be submitted twice")
	var turn = {"processing_queue":false,"action_queue":[],"action_bar":{"block":{"visible":false}},"player":{"user_id":"test-player","current_miscrit":{"handicap":false}}}
	hunter.inflight = ""
	hunter.pending = false
	hunter.next_turn = "Wild"
	check(not hunter.can_take_turn(turn), "Unwanted encounters still wait for a legal player turn")
	hunter.next_turn = "test-player"
	check(hunter.can_take_turn(turn), "Unwanted flee can proceed on an available player turn")
	hunter.on_flee_result(false)
	check(not hunter.leaving and hunter.next_action > Time.get_ticks_msec(), "Failed flee waits before retrying")
	hunter.on_flee_result(true)
	check(hunter.leaving and hunter.enabled, "Successful flee transitions back toward searching")
	reset_hunt()
	hunter.apply_config(cfg)
	hunter.on_encounter([{"name":"Other","rating":18},{"name":"Blighted Flue","rating":14}])
	hunter.select_active_foe({"id":2,"name":"Other","rating":18})
	check(not hunter.history.flee_non_target and hunter.battle_decision(state()).action != "flee", "A qualifying bonus opponent protects the whole encounter from being discarded")
	reset_hunt()
	var manual = cfg.duplicate(true)
	manual.mode = "manual_target"
	hunter.apply_config(manual)
	hunter.on_encounter([{"name":"Other"}])
	check(hunter.enabled and hunter.battle_decision(state()).action == "flee", "Manual-target mode runs from unselected encounters when enabled")
	hunter.on_encounter([{"name":"Other"},{"name":"Blighted Flue","rating":0}])
	check(not hunter.enabled and hunter.manual_battle_id == "capture-test", "Selected manual battle takes priority over the run option, including bonus slots")
	reset_hunt()
	var combined = cfg.duplicate(true)
	combined.mode = "capture_rated"
	combined.other_min_rating = 16
	hunter.apply_config(combined)
	hunter.on_encounter([{"name":"Other","rating":16}])
	check(not hunter.history.flee_non_target, "Combined mode retains high-rated other species that qualify for capture")
	hunter.on_encounter([{"name":"Other","rating":15}])
	check(hunter.history.flee_non_target, "Combined mode runs from encounters below its capture rules")
	reset_hunt()
	var fight = cfg.duplicate(true)
	fight.mode = "fight"
	hunter.apply_config(fight)
	hunter.on_encounter([{"mId":19,"name":"Other","rating":18}])
	check(not hunter.history.flee_non_target and hunter.battle_decision(state()).action == "ability", "Fight-only mode is not changed by the run preference")
	reset_hunt()
	var any_species = cfg.duplicate(true)
	any_species.mode = "capture_any"
	hunter.apply_config(any_species)
	hunter.on_encounter([{"mId":19,"name":"Other","rating":1}])
	check(not hunter.history.flee_non_target, "Capture-any mode continues to accept every species")
	reset_hunt()
	hunter.apply_config(cfg)
	hunter.on_encounter([{}])
	check(not hunter.enabled and not hunter.history.get("flee_non_target",false), "Unknown encounter data pauses without discarding a possible target")
	reset_hunt()
	var default_behavior = cfg.duplicate(true)
	default_behavior.flee_non_targets = false
	hunter.apply_config(default_behavior)
	hunter.on_encounter([{"name":"Other","rating":18}])
	check(hunter.history.fight and hunter.battle_decision(state()).action == "ability", "Disabled option preserves the previous fight behavior")
	hunter.panel.apply_immediate("flee_non_targets", true)
	check(hunter.history.flee_non_target and hunter.battle_decision(state()).action == "flee", "Enabling the switch reclassifies the current encounter for future actions")
	hunter.panel.apply_immediate("flee_non_targets", false)
	check(not hunter.history.flee_non_target and hunter.battle_decision(state()).action == "ability", "Disabling the switch restores fighting without changing targets")
	reset_hunt()

func phase_cleanup_manual(summary, battle):
	summary.free()
	battle.free()

func test_healing_skill():
	var s = state()
	s.player.chp = 50
	var heal = ability(77, 30)
	heal.type = "Heal"
	heal.target = "Self"
	s.player.abilities.append(heal)
	var cfg = config()
	var h = history()
	s.capture_chance = 100
	check(policy.decide(s, cfg, h).get("healing", false), "Low HP heals before finishing capture")
	h.fight = true
	check(policy.decide(s, cfg, h).id == 77, "Low HP heals before finishing fight")
	h.healed_members = ["1"]
	check(not policy.decide(s, cfg, h).get("healing", false), "Healing limited to once per individual per battle")
	h.erase("healed_members")
	s.player.abilities.back().recharge = 1
	check(not policy.decide(s, cfg, h).get("healing", false), "Healing on cooldown is skipped")
	s.player.abilities.back().recharge = -1
	check(not policy.decide(s, cfg, h).get("healing", false), "Exhausted healing is skipped")
	s.player.abilities.back().recharge = 0
	s.player.healing_blocked = true
	check(not policy.decide(s, cfg, h).get("healing", false), "Antiheal prevents wasted skill")
	s.player.healing_blocked = false
	s.player.chp = 51
	check(not policy.decide(s, cfg, h).get("healing", false), "Healthy member does not delay battle")
	reset_hunt()
	hunter.history.healed_members = ["1"]
	hunter.select_active_foe({"id": 88, "mId": 19})
	check(hunter.history.healed_members == ["1"], "Healing limit survives opponent switch")

func prepare_campaign():
	hunter.healing_calls = 0
	hunter.hold_healing = false
	hunter.heal_success = false
	hunter.heal_response_code = 0
	hunter.enabled = false
	hunter.pending_search = false
	hunter.name_traveling = false
	hunter.manual_battle_id = ""
	hunter.reset_battle()
	hunter.campaign.reset()
	hunter.campaign_info_value = {"last_completed":0, "tries":0}
	hunter.campaign_response = {"success":true, "data":{"matchId":"campaign-one"}}
	hunter.campaign_info_calls = 0
	hunter.campaign_create_calls = 0
	hunter.campaign_spawns.clear()
	hunter.campaign_online = true
	hunter.campaign_world = true
	hunter.hold_campaign_info = false
	hunter.hold_campaign_create = false
	hunter.campaign_state = state()
	hunter.submissions.clear()
	server.current_battle_id = ""
	hunter.apply_config({"campaign_enabled":true, "campaign_stage_limit":2, "auto_search":true, "mode":"fight", "object_id":[], "capture_id":[]})

func test_campaign_clear():
	var old_player = server.Player
	var old_battle = BattleAnimator.battle
	var old_id = server.current_battle_id
	BattleAnimator.battle = null
	var player = HealingPlayer.new()
	player.user_id = "test-player"
	player.level = 100
	player.team.assign([123])
	var teammate = TrainMiscrit.new()
	teammate.chp = 100
	player.miscrits[123] = teammate
	server.Player = player
	prepare_campaign()
	var runner = hunter.campaign
	for invalid in [null, "2", false, 0, -1, 1.5, INF, NAN, Constants.CAMPAIGN_LAST_LEVEL + 1]:
		var candidate = hunter.panel.current_values()
		candidate.campaign_stage_limit = invalid
		check(not hunter.validate_config(candidate).is_empty(), "Campaign rejects invalid stage limit: " + str(invalid))
	var invalid_enabled = hunter.panel.current_values()
	invalid_enabled.campaign_enabled = "yes"
	check(not hunter.validate_config(invalid_enabled).is_empty(), "Campaign switch requires a boolean")
	check(runner.plan({"last_completed":0,"tries":0}, 100).get("stage") == 1, "Campaign starts at server's next stage")
	check(runner.plan({"last_completed":0,"tries":9}, 100).get("remaining") == 1, "Campaign preserves the final daily attempt")
	check(runner.plan({"last_completed":0,"tries":10}, 100).has("error"), "Campaign stops at the native daily attempt limit")
	check(runner.plan({"last_completed":Constants.CAMPAIGN_LAST_LEVEL,"tries":0}, 100).get("complete", false), "Campaign stops when all client stages are cleared")
	check(runner.plan({"last_completed":0,"tries":0}, -1).has("error"), "Campaign obeys the stage's player-level requirement")
	for invalid in [{}, {"last_completed":-1,"tries":0}, {"last_completed":1.5,"tries":0}, {"last_completed":NAN,"tries":0}, {"last_completed":0,"tries":11}, {"last_completed":0,"tries":"0"}]:
		check(runner.plan(invalid, 100).has("error"), "Campaign rejects malformed server progress")
	hunter.panel.sync_fields()
	hunter.panel.campaign_limit.get_line_edit().text = "3"
	hunter.panel.save_campaign_limit()
	check(hunter.config.campaign_stage_limit == 3 and JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path())).campaign_stage_limit == 3, "Campaign stage limit saves from the UI")
	hunter.config.campaign_stage_limit = 2
	hunter.toggle_running()
	runner.tick(0.3)
	check(hunter.enabled and runner.phase == "joining" and hunter.campaign_create_calls == 1 and hunter.campaign_spawns == ["campaign-one"], "Campaign creates and joins one native battle")
	for i in range(5): runner.tick(0.3)
	check(hunter.campaign_create_calls == 1, "Campaign does not create another battle while joining")
	var battle = CampaignBattle.new()
	add_child(battle)
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	check(runner.phase == "battle" and hunter.encounter_checked, "Campaign START is recognized without binding a wild search object")
	hunter.next_turn = player.user_id
	hunter.pending = false
	hunter.next_action = 0
	runner.tick(0.3)
	runner.tick(0.3)
	check(hunter.submissions == [20] and hunter.inflight == "ability", "Campaign sends one strongest attack and waits for its acknowledgement")
	hunter.perform_decision(battle, {"action":"capture"}, 0)
	hunter.perform_decision(battle, {"action":"flee"}, 0)
	check(battle.capture_control.attempts == 0 and battle.action_bar.flees == 0, "Campaign never submits capture or run-away actions")
	hunter.toggle_running()
	runner.tick(0.3)
	check(not hunter.enabled and hunter.submissions.size() == 1, "F8 pause preserves the current campaign battle")
	hunter.toggle_running()
	check(hunter.enabled and runner.phase == "battle", "F8 resumes only the campaign's own open battle")
	var summary = ManualSummary.new()
	add_child(summary)
	hunter.on_summary_ready(summary, player.user_id)
	hunter.on_summary_ready(summary, player.user_id)
	check(runner.wins == 1 and runner.phase == "summary", "Duplicate campaign summary counts only one confirmed victory")
	runner.tick(0.3)
	runner.tick(0.3)
	check(summary.continues == 1 and runner.phase == "return", "Campaign closes a winning summary once and waits for the world")
	BattleAnimator.battle = null
	server.current_battle_id = ""
	hunter.campaign_info_value.last_completed = 1
	hunter.campaign_info_value.tries = 1
	hunter.campaign_response.data.matchId = "campaign-two"
	runner.tick(0.3)
	check(hunter.campaign_info_calls == 2 and hunter.campaign_create_calls == 2 and runner.last_completed == 1, "Campaign refreshes real progress and advances after a win")
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	var summary2 = ManualSummary.new()
	add_child(summary2)
	hunter.on_summary_ready(summary2, player.user_id)
	runner.tick(0.3)
	BattleAnimator.battle = null
	server.current_battle_id = ""
	runner.tick(0.3)
	check(not hunter.enabled and runner.wins == 2 and hunter.campaign_create_calls == 2 and runner.status.contains("limit"), "Campaign stage limit stops before another attempt is consumed")

	prepare_campaign()
	hunter.campaign_info_value.tries = 10
	hunter.toggle_running()
	runner.tick(0.3)
	check(not hunter.enabled and hunter.campaign_create_calls == 0, "Exhausted attempts never call create battle")
	prepare_campaign()
	teammate.chp = 0
	hunter.toggle_running()
	runner.tick(0.3)
	check(not hunter.enabled and hunter.campaign_create_calls == 0, "Defeated team stops without purchasing healing")
	teammate.chp = 100

	prepare_campaign()
	hunter.hold_campaign_info = true
	hunter.toggle_running()
	runner.tick(0.3)
	runner.tick(0.3)
	check(runner.busy and hunter.campaign_info_calls == 1, "Pending campaign info has one in-flight request")
	hunter.toggle_running()
	hunter.toggle_running()
	check(not hunter.enabled and runner.busy, "Resume waits for a pending info request")
	hunter.campaign_info_released.emit()
	await get_tree().process_frame
	check(not runner.busy and hunter.campaign_create_calls == 0, "Info response arriving after Pause cannot start a battle")

	prepare_campaign()
	hunter.hold_campaign_create = true
	hunter.toggle_running()
	runner.tick(0.3)
	hunter.toggle_running()
	hunter.toggle_running()
	check(runner.busy and hunter.campaign_create_calls == 1 and not hunter.enabled, "Pending battle creation cannot be duplicated by Pause/Resume")
	hunter.campaign_create_released.emit()
	await get_tree().process_frame
	check(hunter.campaign_spawns == ["campaign-one"] and not hunter.enabled, "Late successful creation joins the battle while preserving Pause")
	var leave_campaign = hunter.panel.current_values()
	leave_campaign.campaign_enabled = false
	check(not hunter.live_config(leave_campaign, false).is_empty(), "Campaign cannot be disabled while its created battle is still joining")
	hunter.toggle_running()
	check(not hunter.enabled and hunter.campaign_create_calls == 1, "Resume during battle loading cannot create a second battle")
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	runner.tick(0.3)
	check(hunter.submissions.is_empty(), "Late campaign battle does not attack while paused")
	hunter.toggle_running()
	check(hunter.enabled, "Late joined campaign battle can be explicitly resumed")
	hunter.on_summary_ready(summary, "Wild")
	runner.tick(0.3)
	check(not hunter.enabled and runner.wins == 0 and runner.phase == "stopped", "Defeat stops auto clear without counting a win or retrying")
	var old_continues = summary.continues
	runner.tick(0.3)
	check(summary.continues == old_continues, "Losing campaign summary stays open for the player")
	BattleAnimator.battle = null

	prepare_campaign()
	hunter.hold_campaign_create = true
	hunter.toggle_running()
	runner.tick(0.3)
	runner.request_deadline = 0
	runner.tick(0.3)
	check(not hunter.enabled and runner.uncertain and runner.busy, "Timed-out creation stops without guessing its result")
	hunter.campaign_create_released.emit()
	await get_tree().process_frame
	hunter.toggle_running()
	check(not hunter.enabled and hunter.campaign_create_calls == 1, "Timed-out creation never retries even after its late response")

	prepare_campaign()
	hunter.toggle_running()
	runner.tick(0.3)
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	hunter.on_summary_ready(summary, player.user_id)
	runner.tick(0.3)
	BattleAnimator.battle = null
	server.current_battle_id = ""
	runner.tick(0.3)
	check(not hunter.enabled and hunter.campaign_create_calls == 1 and runner.status.contains("not advanced"), "Stale server progress stops instead of replaying the completed stage")

	prepare_campaign()
	hunter.toggle_running()
	runner.tick(0.3)
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	hunter.on_battle_event({}, BattleEnum.Opcode.DISCONNECT, state(), state())
	check(not hunter.enabled and runner.uncertain, "Campaign server disconnect blocks automatic retries")
	BattleAnimator.battle = null

	prepare_campaign()
	battle.battle_type = "Wild"
	BattleAnimator.battle = battle
	hunter.toggle_running()
	check(not hunter.enabled and hunter.campaign_create_calls == 0, "Campaign refuses to take control of a pre-existing wild battle")
	BattleAnimator.battle = null
	var unusable = state()
	unusable.player.abilities = []
	check(runner.combat_decision(unusable).action == "stop", "Campaign with no attack stops rather than attempting an illegal flee")
	hunter.enabled = false
	hunter.pending_search = false
	var search = hunter.panel.current_values()
	search.campaign_enabled = false
	check(hunter.live_config(search, false).is_empty(), "Campaign can be disabled after returning to the world")
	check(hunter.config.combat_mode == "fight", "Campaign does not overwrite the saved wild battle mode")
	var campaign_again = hunter.panel.current_values()
	campaign_again.campaign_enabled = true
	hunter.pending_search = true
	hunter.encounter_checked = false
	hunter.match_id = "finished-wild"
	check(not hunter.live_config(campaign_again, false).is_empty(), "Switching activities cannot discard an unanswered wild search")
	hunter.encounter_checked = true
	check(hunter.live_config(campaign_again, false).is_empty() and not hunter.pending_search and hunter.match_id.is_empty() and not hunter.encounter_checked, "Switching to campaign clears a manually completed paused wild encounter in an idle world")
	battle.free()
	summary.free()
	summary2.free()
	server.Player = old_player
	BattleAnimator.battle = old_battle
	server.current_battle_id = old_id
	reset_hunt()

func set_campaign_team_health(player, fainted: int, virtue: int):
	player.virtue = virtue
	for index in range(player.team.size()):
		player.miscrits[player.team[index]].chp = 0 if index < fainted else 100

func test_campaign_virtue_heal():
	var old_player = server.Player
	var old_battle = BattleAnimator.battle
	var old_id = server.current_battle_id
	BattleAnimator.battle = null
	var player = HealingPlayer.new()
	player.user_id = "test-player"
	player.level = 100
	for index in range(4):
		var m = TrainMiscrit.new()
		m.id = 500 + index
		player.team.append(m.id)
		player.miscrits[m.id] = m
	var benched = TrainMiscrit.new()
	benched.id = 600
	benched.chp = 0
	player.miscrits[600] = benched
	server.Player = player
	var runner = hunter.campaign
	for fainted in [0, 1]:
		prepare_campaign()
		set_campaign_team_health(player, fainted, 20)
		hunter.toggle_running()
		runner.tick(0.3)
		await get_tree().process_frame
		check(hunter.healing_calls == 0 and player.virtue == 20 and hunter.campaign_create_calls == 1, "Campaign preserves virtue below two fainted active teammates, ignoring benched Miscrits: " + str(fainted))
	for fainted in [2, 3, 4]:
		prepare_campaign()
		set_campaign_team_health(player, fainted, 20)
		hunter.heal_success = true
		hunter.toggle_running()
		runner.tick(0.3)
		await get_tree().process_frame
		check(hunter.healing_calls == 1 and player.virtue == 10 and runner.fainted_count(player) == 0 and hunter.campaign_create_calls == 1, "Campaign heals with exactly 10 virtue before a stage at or above the two-fainted threshold: " + str(fainted))
		runner.tick(0.3)
		check(hunter.healing_calls == 1 and player.virtue == 10, "Repeated campaign ticks do not charge healing twice")

	prepare_campaign()
	set_campaign_team_health(player, 2, 9)
	hunter.toggle_running()
	runner.tick(0.3)
	check(not hunter.enabled and hunter.healing_calls == 0 and hunter.campaign_create_calls == 0 and player.virtue == 9, "Insufficient virtue pauses before healing or another campaign attempt")
	prepare_campaign()
	set_campaign_team_health(player, 2, 20)
	hunter.toggle_running()
	runner.tick(0.3)
	runner.tick(0.3)
	check(not hunter.enabled and hunter.healing_calls == 1 and hunter.campaign_create_calls == 0 and player.virtue == 20 and runner.fainted_count(player) == 2, "Rejected healing preserves virtue/HP and stops without an automatic retry")
	prepare_campaign()
	set_campaign_team_health(player, 2, 20)
	hunter.heal_response_code = 503
	hunter.toggle_running()
	runner.tick(0.3)
	hunter.toggle_running()
	check(not hunter.enabled and runner.uncertain and hunter.healing_calls == 1 and hunter.campaign_create_calls == 0, "Transport failure leaves virtue healing uncertain and blocks a duplicate charge")

	prepare_campaign()
	set_campaign_team_health(player, 2, 10)
	hunter.heal_success = true
	hunter.hold_healing = true
	hunter.toggle_running()
	runner.wins = 1
	runner.tick(0.3)
	runner.tick(0.3)
	check(runner.busy and runner.phase == "heal" and hunter.healing_calls == 1 and hunter.campaign_create_calls == 0 and player.virtue == 10, "Pending virtue healing blocks the next stage and does not deduct locally before success")
	hunter.toggle_running()
	hunter.toggle_running()
	check(not hunter.enabled and hunter.healing_calls == 1, "Pause/Resume does not duplicate a pending virtue charge")
	hunter.healing_released.emit()
	await get_tree().process_frame
	check(not hunter.enabled and not runner.busy and player.virtue == 0 and runner.fainted_count(player) == 0 and hunter.campaign_create_calls == 0, "A successful late heal updates HP and virtue once while keeping campaign paused")
	hunter.hold_healing = false
	hunter.toggle_running()
	runner.tick(0.3)
	check(hunter.enabled and runner.wins == 1 and hunter.healing_calls == 1 and hunter.campaign_create_calls == 1, "Resume after healing preserves the session victory count and does not heal again")

	prepare_campaign()
	set_campaign_team_health(player, 2, 20)
	hunter.heal_success = true
	hunter.hold_healing = true
	hunter.toggle_running()
	runner.tick(0.3)
	runner.request_deadline = 0
	runner.tick(0.3)
	check(not hunter.enabled and runner.uncertain and runner.busy, "Virtue healing timeout blocks automatic currency retries")
	hunter.healing_released.emit()
	await get_tree().process_frame
	hunter.toggle_running()
	check(not hunter.enabled and hunter.healing_calls == 1 and player.virtue == 10 and hunter.campaign_create_calls == 0, "Late timed-out heal success is applied once without restarting campaign")

	for blocked in ["attempts", "victories"]:
		prepare_campaign()
		set_campaign_team_health(player, 2, 20)
		hunter.heal_success = true
		if blocked == "attempts": hunter.campaign_info_value.tries = 10
		hunter.toggle_running()
		if blocked == "victories": runner.wins = 2
		runner.tick(0.3)
		check(not hunter.enabled and hunter.healing_calls == 0 and player.virtue == 20, "Campaign does not spend virtue when no next stage will be played: " + blocked)

	prepare_campaign()
	set_campaign_team_health(player, 0, 20)
	hunter.heal_success = true
	hunter.toggle_running()
	runner.tick(0.3)
	var battle = CampaignBattle.new()
	add_child(battle)
	BattleAnimator.battle = battle
	hunter.on_battle_started([], "Campaign", player.user_id)
	set_campaign_team_health(player, 2, 20)
	runner.tick(0.3)
	check(hunter.healing_calls == 0 and player.virtue == 20, "Campaign never sends out-of-battle virtue healing during an active battle")
	var summary = ManualSummary.new()
	add_child(summary)
	hunter.on_summary_ready(summary, player.user_id)
	runner.tick(0.3)
	BattleAnimator.battle = null
	server.current_battle_id = ""
	hunter.campaign_info_value.last_completed = 1
	hunter.campaign_info_value.tries = 1
	hunter.campaign_response.data.matchId = "campaign-after-heal"
	runner.tick(0.3)
	await get_tree().process_frame
	check(runner.wins == 1 and hunter.healing_calls == 1 and player.virtue == 10 and hunter.campaign_create_calls == 2 and runner.fainted_count(player) == 0, "Two teammates fainting in a victory triggers virtue healing before continuing to the next campaign stage")
	battle.free()
	summary.free()
	server.Player = old_player
	BattleAnimator.battle = old_battle
	server.current_battle_id = old_id
	hunter.enabled = false
	runner.reset()
	reset_hunt()

func rotation_player():
	var player = HealingPlayer.new()
	player.user_id = "test-player"
	player.level = 100
	player.virtue = 20
	var first = int(hunter.catalog.by_name["blighted flue"].id)
	var second = int(hunter.catalog.by_name["rocapez"].id)
	for row in [[1, first, 35, 18], [2, first, 35, 18], [3, first, 34, 18], [4, second, 35, 18], [10, first, 12, 16], [11, second, 1, 18], [12, first, 34, 18], [13, first, 35, 18], [14, 99999, 1, 18], [15, first, 1, NAN]]:
		var m = RotationMiscrit.new()
		m.id = row[0]
		m.mId = row[1]
		m.level = row[2]
		m.test_rating = row[3]
		m.chp = 100
		player.miscrits[m.id] = m
	player.team.assign([1,2,3,4])
	return player

func prepare_rotation(player):
	prepare_campaign()
	hunter.campaign.reset()
	hunter.campaign.busy = false
	hunter.rotation.busy = false
	hunter.rotation.uncertain = false
	hunter.rotation.next_scan = 0
	hunter.rotation.last_key = ""
	hunter.team_update_calls.clear()
	hunter.hold_team_update = false
	hunter.team_update_response = {"success":true, "code":0}
	hunter.after_team_update = Callable()
	server.Player = player
	server.current_battle_id = ""
	hunter.pending_search = false
	hunter.needs_rearm = false
	hunter.training = false
	hunter.healing = false
	hunter.apply_config({"mode":"capture_targeted", "capture_id":["mama"], "object_id":[98,99], "auto_search":true, "auto_replace_max_level":true, "replacement_names":["blighted flue", "rocapez"], "platinum_miscrit_ids":["2"]})
	hunter.enabled = true

func test_desktop_collection_workflow():
	var old_player = server.Player
	var old_id = server.current_battle_id
	var old_battle = BattleAnimator.battle
	var entries = []
	for tier in hunter.rotation.TIERS:
		entries.append(hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == tier)[0])
	var names = entries.map(func(entry): return entry.name.to_lower())
	var player = HealingPlayer.new()
	player.user_id = "test-player"
	for id in range(1, 5):
		var member = RotationMiscrit.new()
		member.id = id
		member.mId = 99990 + id
		member.level = 35
		player.miscrits[id] = member
	player.team.assign([1,2,3,4])
	for index in entries.size():
		var member = RotationMiscrit.new()
		member.id = 10 + index
		member.mId = int(entries[index].id)
		member.level = 1
		member.test_rating = 17
		player.miscrits[member.id] = member
	prepare_rotation(player)
	BattleAnimator.battle = null
	hunter.config.train_selected = true
	hunter.config.replacement_names = names.duplicate()
	hunter.config.auto_level_up = false
	var report = hunter.rotation.training_report(player, names)
	check(report.eligible.map(func(row): return row.name) == names, "Desktop training respects Exotic/Rare/Common/Epic/Legendary order")
	var planned = hunter.rotation.selected_plan(player, names)
	check(planned.after == [1,10,11,12], "Desktop chooses three eligible distinct families, keeping lead")
	check(planned.before == [1,2,3,4] and player.team == planned.before, "Planning cannot change native team before server acceptance")
	check(await hunter.rotation.ensure_ready(true), "Desktop selected training uses guarded native update_team request")
	check(player.team == [1,10,11,12] and hunter.team_update_calls.size() == 1, "Selected training confirms one native team update")
	check(hunter.rotation.selected_plan(player, names).changes.is_empty(), "Existing selected trainees keep their slots")
	var better = RotationMiscrit.new()
	better.id = 50
	better.mId = player.miscrits[10].mId
	better.level = 2
	better.test_rating = 18
	player.miscrits[50] = better
	check(hunter.rotation.selected_plan(player, names).after == [1,50,11,12], "Higher-rated duplicate replaces lower copy without training both")
	player.miscrits[50].test_rating = 16
	check(hunter.rotation.selected_plan(player, names).after == player.team, "Below-17 duplicate never replaces qualified trainee")
	player.miscrits[10].level = 35
	check(hunter.rotation.training_report(player, names).rows[0].state == "Complete", "Any owned level-35 family blocks duplicate training")
	check(hunter.rotation.selected_plan(player, names).after == [1,13,11,12], "Level-30 trainee rotates to next tier when current tier is complete")
	player.miscrits[10].level = 34
	var family = int(entries[0].id)
	var old_meta = server.MiscritDict.get(family)
	var meta = IndexMiscrit.new()
	meta.captured_evos[3] = true
	server.MiscritDict[family] = meta
	check(not hunter.rotation.completed(player, family), "Fourth evolution alone does not block continuing training to level 35")
	if old_meta == null: server.MiscritDict.erase(family)
	else: server.MiscritDict[family] = old_meta
	player.miscrits[10].test_rating = 16
	var missing = hunter.rotation.training_report(player, names)
	check(names[0] in missing.needs_capture and missing.eligible.size() == 4, "Below-17 inventory copy queues upgrade and skips to next eligible species")
	hunter.config.miscrits = []
	check(names[0] not in hunter.hunt_names(), "Owned lower-tier trainees take priority over hunting a missing upgrade")
	player.miscrits[10].test_rating = 17
	check(names[0] not in hunter.hunt_names(), "Owned 17+ upgrade automatically leaves hidden hunt queue")
	check(hunter.training_farm() and hunter.search_names() == names, "Owned trainees continue earning XP after the visible wishlist and upgrade queue are empty")
	hunter.config.flee_non_targets = true
	hunter.set_encounter_behavior("miss")
	check(hunter.history.fight and not hunter.history.flee_non_target, "Training-only routes fight for XP instead of fleeing every encounter")
	check(hunter.training_allowed(player.miscrits[10]), "Selected training uses earned XP even with general free-level toggle off")
	player.miscrits[10].level = 35
	check(not hunter.training_allowed(player.miscrits[10]), "Selected training stops at exactly level 35")
	player.miscrits[10].level = 34
	player.miscrits[50].test_rating = 18
	check(not hunter.training_allowed(player.miscrits[10]), "Non-best duplicate in team cannot receive automatic training")
	player.miscrits.erase(50)
	player.miscrits[10].price = 1
	check(not hunter.training_allowed(player.miscrits[10]), "Selected workflow never buys an XP level")
	player.miscrits[10].price = 0
	hunter.training_success = true
	hunter.config.platinum_miscrit_ids = ["10"]
	hunter.bonus_submissions.clear()
	hunter.training_submissions.clear()
	await hunter.train_miscrit(player.miscrits[10])
	check(player.miscrits[10].level == 35 and hunter.training_submissions == [10], "Free training acknowledges one level-34 to level-35 request")
	check(hunter.bonus_submissions.is_empty(), "Selected workflow never buys bonus stats")
	await hunter.train_miscrit(player.miscrits[10])
	check(hunter.training_submissions.size() == 1, "No further training request after level 35")
	player.miscrits[10].level = 1
	player.team.assign([10,2,3,4])
	check(not hunter.rotation.training_report(player, names).eligible.any(func(row): return row.family == family), "Lead family is excluded from other training slots")
	player.team.assign([1,10,11,12])
	hunter.config.miscrits = [names[0]]
	hunter.config.target_mode = "targeted"
	hunter.config.combat_mode = "capture_targeted"
	hunter.config.min_rating = 17
	var foe = {"id":99, "mId":family, "name":entries[0].name, "rating":16}
	for allow in [false,true]:
		hunter.config.capture_low_rating_targets = allow
		check(hunter.classify_encounter([foe]) == ("match" if allow else "miss"), "Desktop low-rating capture toggle is honored: " + str(allow))
	foe.rating = NAN
	check(hunter.classify_encounter([foe]) == "unknown", "Allow-low toggle never accepts invalid rating")
	foe.rating = 16
	foe.name = "Evolved target display name"
	check(hunter.classify_encounter([foe]) == "match", "Capture rules recognize target family across evolution names")
	hunter.config.auto_remove_captured_targets = true
	hunter.reset_battle()
	hunter.match_id = "desktop-keep-test"
	server.current_battle_id = hunter.match_id
	var snapshot = {"player":{"user_id":"test-player"}, "foe":foe.duplicate()}
	hunter.on_battle_event({"user_id":"test-player", "captured":true}, BattleEnum.Opcode.CAPTURE, snapshot, snapshot)
	check(names[0] in hunter.config.miscrits, "Successful capture alone does not remove target before keep acknowledgement")
	hunter.inflight = "keep"
	hunter.keep_sent = true
	hunter.on_battle_event({"user_id":"Wild"}, BattleEnum.Opcode.CAPTURE_CONTINUE, snapshot, snapshot)
	check(names[0] in hunter.config.miscrits, "Opponent acknowledgement cannot remove wishlist target")
	hunter.on_battle_event({"user_id":"test-player"}, BattleEnum.Opcode.CAPTURE_CONTINUE, snapshot, snapshot)
	check(hunter.config.miscrits.is_empty() and names[0] in hunter.config.replacement_names, "Confirmed keep removes visible target but preserves separate training list")
	check(JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path())).miscrits.is_empty(), "Target removal is persisted atomically")
	check(hunter.match_id == "desktop-keep-test", "Target removal preserves current battle ownership")
	check(hunter.confirm_kept_target().is_empty(), "Repeated keep acknowledgement is idempotent")
	server.current_battle_id = ""
	hunter.pending_search = false
	hunter.name_traveling = false
	hunter.enabled = false
	hunter.panel.sync_fields()
	check(hunter.panel.tier_views.size() == 5 and hunter.panel.train_selected_toggle.button_pressed, "Desktop exposes all five tier sections and selected training switch")
	hunter.panel.tier_views.Rare.heading.pressed.emit()
	check(hunter.panel.tier_views.Rare.body.visible and not hunter.panel.tier_views.Common.body.visible, "Tier heading expands its own tier without opening other tiers")
	hunter.panel.tier_views.Rare.heading.pressed.emit()
	hunter.panel.save_name_targets([names[0], names[1]])
	var row = hunter.panel.selected_targets.get_root().get_child(1)
	row.select(0)
	hunter.panel.move_target(-999)
	check(hunter.config.miscrits == [names[1],names[0]], "Desktop Main priority moves selected target to first position")
	hunter.panel.save_name_targets([])
	check(hunter.config.miscrits.is_empty(), "Desktop Clear all removes every visible target")
	hunter.panel.clear_tier("Exotic")
	check(names[0] not in hunter.config.replacement_names and names[1] in hunter.config.replacement_names, "Clear tier preserves selections in other tiers")
	hunter.panel.add_tier("Exotic", false)
	check(names[0] in hunter.config.replacement_names, "Owned 17+ tier action adds qualified owned family")
	player.miscrits[10].test_rating = 16
	hunter.panel.add_tier("Exotic", true)
	check(names[0] in hunter.config.replacement_names and names[0] in hunter.config.miscrits, "Mapped tier action adds both replacement list and visible capture target")
	hunter.config.miscrits = []
	hunter.panel.import_tier_targets()
	check(names[0] in hunter.config.miscrits, "Wishlist imports mapped selected families that still need a 17+ upgrade")
	var before = hunter.config.duplicate(true)
	hunter.pending_search = true
	hunter.panel.clear_tier("Exotic")
	check(hunter.config == before, "Pending search blocks replacement-list changes atomically")
	hunter.pending_search = false
	for key in ["train_selected", "capture_low_rating_targets", "auto_remove_captured_targets"]:
		var bad = hunter.config.duplicate(true)
		bad[key] = "yes"
		check(not hunter.validate_config(bad).is_empty(), "Desktop rejects malformed workflow boolean " + key)
	server.Player = null
	hunter.panel.refresh_replacements()
	check(hunter.panel.tier_views.Exotic.owned.disabled and hunter.panel.tier_views.Exotic.mapped.disabled, "Tier inventory actions require a loaded player")
	prepare_rotation(player)
	player.level = 100
	player.virtue = 20
	for member in player.miscrits.values(): member.chp = 100
	player.team.assign([1,10,11,12])
	player.miscrits[10].level = 34
	player.miscrits[10].test_rating = 17
	player.miscrits[11].level = 35
	player.miscrits[12].level = 35
	hunter.config.train_selected = true
	hunter.config.replacement_names = names.duplicate()
	hunter.config.campaign_enabled = true
	hunter.training_success = true
	hunter.training_submissions.clear()
	hunter.campaign_create_calls = 0
	hunter.campaign_info_value = {"last_completed":0, "tries":0}
	await hunter.campaign.load_next()
	check(player.miscrits[10].level == 35 and hunter.training_submissions == [10], "Campaign preflight trains earned XP only through level 35")
	check(player.team == [1,13,14,12] and hunter.campaign_create_calls == 1, "Campaign awaits selected-team rotation before requesting next stage")
	check(not hunter.training_allowed(player.miscrits[12]), "Completed teammate kept when no replacement remains cannot be trained further")
	server.Player = old_player
	server.current_battle_id = old_id
	BattleAnimator.battle = old_battle
	hunter.enabled = false
	reset_hunt()

func test_desktop_level35_fallback():
	var old_player = server.Player
	var old_id = server.current_battle_id
	var exotic = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == "Exotic")
	var rare = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == "Rare")
	var common = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == "Common")[0]
	var epic = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == "Epic")[0]
	var legend = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == "Legendary")[0]
	var player = HealingPlayer.new()
	player.user_id = "test-player"
	for values in [[1,int(legend.id),24,17],[2,int(exotic[0].id),30,18],[3,int(rare[0].id),35,17],[4,99999,35,18],[10,int(rare[0].id),1,18],[11,int(common.id),20,17],[12,int(epic.id),34,18],[13,int(legend.id),1,18],[14,int(rare[1].id),1,16],[15,int(common.id),1,16],[16,int(exotic[1].id),1,16]]:
		var member = RotationMiscrit.new()
		member.id = values[0]
		member.mId = values[1]
		member.level = values[2]
		member.test_rating = values[3]
		member.chp = 100
		player.miscrits[member.id] = member
	player.team.assign([1,2,3,4])
	prepare_rotation(player)
	hunter.config.train_selected = true
	hunter.config.auto_level_up = false
	hunter.config.replacement_names = [exotic[0].name.to_lower(), exotic[1].name.to_lower()]
	hunter.config.miscrits = []
	var report = hunter.rotation.training_report(player, hunter.config.replacement_names)
	check(report.eligible.map(func(row): return row.id) == [2,11,12], "Owned S copies in later tiers fill gaps without requiring their names in the replacement list")
	check(report.eligible[1].source == "owned_fallback", "Automatic tier candidate is identified as an owned fallback")
	check(not report.eligible.any(func(row): return row.id == 10), "A level-35 copy blocks another higher-rated copy of the same family")
	check(not report.eligible.any(func(row): return row.id in [13,14,15,16]), "Lead family, below-17 copies and duplicate family copies are excluded")
	check(hunter.hunt_names().is_empty(), "Owned fallback trainees prevent waiting on missing selected capture upgrades")
	check(await hunter.rotation.ensure_ready(true) and player.team == [1,2,11,12], "Team rotates through owned tier candidates while preserving lead and current qualified trainee")
	var family = int(exotic[0].id)
	var old_meta = server.MiscritDict.get(family)
	var meta = IndexMiscrit.new()
	meta.captured_evos[3] = true
	server.MiscritDict[family] = meta
	check(hunter.training_allowed(player.miscrits[2]), "Ready-to-train level-30 fourth evolution remains eligible through level 35")
	hunter.training_submissions.clear()
	hunter.training_success = true
	await hunter.train_miscrit(player.miscrits[2])
	check(player.miscrits[2].level == 31 and hunter.training_submissions == [2], "Level-30 Ready to train sends exactly one free XP request and advances to 31")
	player.miscrits[2].level = 34
	await hunter.train_miscrit(player.miscrits[2])
	check(player.miscrits[2].level == 35 and not hunter.training_allowed(player.miscrits[2]), "Final free XP level reaches 35 and no further request is allowed")
	var next = RotationMiscrit.new()
	next.id = 17
	next.mId = int(rare[1].id)
	next.level = 1
	next.test_rating = 18
	next.chp = 100
	player.miscrits[17] = next
	check(hunter.rotation.selected_plan(player, hunter.config.replacement_names).after == [1,17,11,12], "After Exotic reaches 35, next owned Rare copy is selected before Common and Epic")
	player.team.assign([1,13,11,12])
	check(not hunter.training_allowed(player.miscrits[13]), "A higher-rated reserve copy of the lead family cannot become a duplicate trainee")
	for id in [11,12,17]: player.miscrits[id].level = 35
	check(hunter.rotation.training_report(player, hunter.config.replacement_names).eligible.is_empty(), "No duplicate training is started after all owned qualifying families reach 35")
	check(exotic[1].name.to_lower() in hunter.hunt_names(), "Selected missing upgrade is searched only after all owned tier fallback candidates are exhausted")
	hunter.panel.sync_fields()
	check(hunter.panel.train_selected_toggle.text.contains("35"), "Desktop collection control clearly labels the level-35 training cap")
	if old_meta == null: server.MiscritDict.erase(family)
	else: server.MiscritDict[family] = old_meta
	server.Player = old_player
	server.current_battle_id = old_id
	hunter.enabled = false
	reset_hunt()

func test_desktop_performance():
	var old_player = server.Player
	var player = HealingPlayer.new()
	var names = hunter.catalog.entries.slice(0,100).map(func(entry): return entry.name.to_lower())
	for index in range(4000):
		var member = RotationMiscrit.new()
		member.id = 1000 + index
		member.mId = int(hunter.catalog.entries[index % 100].id)
		member.level = 1 + (index % 29)
		member.test_rating = 16 + (index % 3)
		player.miscrits[member.id] = member
	player.team.assign([1000,1001,1002,1003])
	var began = Time.get_ticks_usec()
	var report = hunter.rotation.training_report(player, names)
	var duration = Time.get_ticks_usec() - began
	check(hunter.rotation.report_member_visits == 4000 and report.rows.size() == 100, "Training report visits 4000 owned copies once for 100 selected species")
	check(report.eligible.size() == 99, "Single-pass roster report preserves one best eligible copy per family and excludes the lead family")
	print("DESKTOP PERFORMANCE: 4000 owned / 100 selected / %d roster visits / %d microseconds" % [hunter.rotation.report_member_visits, duration])
	var original_tab = hunter.panel.tabs.current_tab
	var original_visible = hunter.panel.panel.visible
	hunter.panel.tabs.current_tab = 2
	hunter.rotation.report_member_visits = -1
	hunter.panel._process(1.1)
	check(hunter.rotation.report_member_visits == -1, "Captures tab does not rebuild hidden replacement collection")
	hunter.panel.panel.hide()
	hunter.panel.tabs.current_tab = 1
	hunter.panel._process(1.1)
	check(hunter.rotation.report_member_visits == -1, "Minimized panel does not rebuild roster or route lists")
	hunter.panel.tabs.current_tab = original_tab
	hunter.panel.panel.visible = original_visible
	check(server.LEVEL == NakamaLogger.LOG_LEVEL.ERROR, "Normal desktop Nakama client disables debug network dumps")
	check(server._study_log_details("battle_applied", {"config":{"replacement_names":names}}, false).is_empty(), "Normal desktop log skips detailed network snapshots")
	var details = server._study_log_details("capture_hunt_level_up", {"message":"Training with earned XP", "object_id":5, "config":{"replacement_names":names}}, false)
	check(details == {"message":"Training with earned XP", "object_id":5}, "Normal desktop log retains compact status without full configuration")
	check(server._study_log_details("battle_applied", {"opcode":2}, true) == {"opcode":2}, "Explicit diagnostic mode keeps detailed trace support")
	server.Player = old_player

func test_capture_diagnostics():
	var previous = hunter.capture_audit
	var old_player = server.Player
	server.Player = null
	hunter.capture_audit = StudyCaptureAudit.new()
	hunter.capture_audit.host = hunter
	hunter.apply_config({"mode":"capture_targeted", "capture_id":["blighted flue"], "object_id":[98], "min_rating":17, "min_target_hp_percent":25})
	hunter.match_id = "private-match-must-not-be-saved"
	hunter.history = history()
	var s = state()
	s.player.user_id = "private-account-must-not-be-saved"
	s.player.name = "Lead"
	s.foe.name = "Blighted Flue"
	s.foe.mId = int(hunter.catalog.by_name["blighted flue"].id)
	s.foe.rating = 17
	s.foe.chp = 20
	s.capture_chance = 10
	check(hunter.capture_audit.record("encounter", s), "Target encounter creates dedicated audit before any flee")
	var choice = hunter.battle_decision(s)
	check(choice.action == "flee" and choice.reason.contains("HP"), "Target HP guard reason is recorded without changing policy")
	hunter.capture_audit.record("action_sent", {}, choice)
	hunter.capture_audit.record("server_response", s, {}, {"opcode":4, "success":true})
	var files = Array(DirAccess.get_files_at(hunter.capture_audit.directory())).filter(func(name): return name.ends_with(".json"))
	check(files.size() == 1, "One target battle uses one diagnostic case")
	var path = hunter.capture_audit.directory().path_join(files[0])
	var raw = FileAccess.get_file_as_string(path)
	var saved = JSON.parse_string(raw)
	check(saved.targets[0].visible_target and saved.rules.min_rating == 17, "Audit records matching target source and rating rule")
	check(saved.events[-1].response.success and saved.events[-2].phase == "action_sent", "Sent flee and confirmed server response are separate audit events")
	check(not raw.contains("private-account-must-not-be-saved") and not raw.contains("private-match-must-not-be-saved"), "Audit excludes account and match identifiers")
	var markdown = FileAccess.get_file_as_string(path.trim_suffix(".json") + ".md")
	check(markdown.contains(choice.reason) and markdown.contains("Latest snapshot") and markdown.contains("response"), "Target Markdown includes reason, response and readable latest state")
	for index in range(40): hunter.capture_audit.record("decision", s, choice)
	raw = FileAccess.get_file_as_string(path)
	saved = JSON.parse_string(raw)
	check(raw.to_utf8_buffer().size() <= 65536 and saved.events.size() <= 32 and saved.older_events_omitted > 0, "Target audit bounds retained snapshots instead of producing unlimited debug logs")
	hunter.match_id = "unselected-case"
	s.foe.name = "Unselected fixture"
	s.foe.mId = -1
	check(not hunter.capture_audit.record("encounter", s), "Unselected encounters do not create diagnostic files")
	check(hunter.capture_audit.matches([s.foe, {"name":"Blighted Flue", "mId":int(hunter.catalog.by_name["blighted flue"].id)}]).size() == 1, "Bonus-slot target is detected for evidence even when active foe is unwanted")
	hunter.capture_audit = previous
	server.Player = old_player
	reset_hunt()

func test_team_rotation():
	var old_player = server.Player
	var old_battle = BattleAnimator.battle
	var old_id = server.current_battle_id
	BattleAnimator.battle = null
	var player = rotation_player()
	prepare_rotation(player)
	var rotation = hunter.rotation
	var names = hunter.config.replacement_names
	var change = rotation.plan(player, names)
	check(change.after == [1,11,3,12], "Rotation preserves leader/below-35 members and ranks eligible owned candidates by highest rating with stable ties")
	check(change.changes.size() == 2 and change.changes[0].slot == 2 and change.changes[1].slot == 4 and change.unfilled == 0, "Only occupied max-level slots 2 through 4 are replaced")
	check(player.team == [1,2,3,4], "Planning a replacement does not mutate the team")
	check(rotation.candidates(player, ["blighted flue"]).map(func(item): return item.id) == [12,10], "Candidate pool excludes active members, unselected families, max-level copies and invalid ratings")
	player.miscrits[3].level = 35
	check(rotation.plan(player, names).after == [1,11,12,10], "Three completed training slots use three distinct highest-rated owned copies")
	player.miscrits.erase(12)
	player.miscrits.erase(10)
	change = rotation.plan(player, names)
	check(change.after == [1,11,3,4] and change.unfilled == 2, "Partial replacement keeps unmatched slots rather than removing teammates or reusing a candidate")
	player.team.assign([1,2])
	check(rotation.plan(player, names).after == [1,11], "Rotation does not add missing third or fourth team slots")
	player.team.assign([1,1])
	check(rotation.plan(player, names).has("error"), "Duplicate team members prevent a malformed team update")
	player = rotation_player()
	prepare_rotation(player)
	for invalid in [null, true, "flue", [""], [1], ["flue", " FLUE "]]:
		var bad = hunter.panel.current_values()
		bad.replacement_names = invalid
		check(not hunter.validate_config(bad).is_empty(), "Replacement names reject malformed or duplicate selections")
	var bad_toggle = hunter.panel.current_values()
	bad_toggle.auto_replace_max_level = "yes"
	check(not hunter.validate_config(bad_toggle).is_empty(), "Replacement toggle requires a boolean")
	hunter.panel.sync_fields()
	hunter.panel.save_replacement_names([])
	hunter.panel.replacement_query.text = "bli"
	hunter.panel.refresh_replacement_suggestions("bli")
	var index = -1
	for i in range(hunter.panel.replacement_suggestions.item_count):
		if hunter.panel.replacement_suggestions.get_item_metadata(i) == "blighted flue": index = i
	check(index >= 0, "Team replacement search finds the selected species")
	if index >= 0: hunter.panel.replacement_suggestions.item_selected.emit(index)
	var saved = JSON.parse_string(FileAccess.get_file_as_string(hunter.config_path()))
	check(hunter.config.replacement_names == ["blighted flue"] and saved.replacement_names == ["blighted flue"], "Team name selection saves from the separate Team picker")
	check(hunter.config.miscrits == ["mama"] and hunter.config.combat_mode == "capture_targeted", "Replacement selection preserves wild capture targets and battle mode")
	hunter.panel.replacement_list.get_root().get_first_child().select(0)
	hunter.panel.remove_replacement_name()
	check(hunter.config.replacement_names.is_empty() and hunter.config.miscrits == ["mama"], "Removing a replacement name leaves the capture list untouched")

	player = rotation_player()
	prepare_rotation(player)
	check(await rotation.ensure_ready(true), "Acknowledged native team update completes successfully")
	check(hunter.team_update_calls == [[1,11,3,12]] and player.team == [1,11,3,12], "Multiple slots are saved together in one native update_team request")
	check(hunter.config.platinum_miscrit_ids == ["2"] and not hunter.platinum_allowed(player.miscrits[11]), "Replacement does not transfer platinum permission from the old teammate")
	check(await rotation.ensure_ready(true) and hunter.team_update_calls.size() == 1, "An accepted replacement is not sent again on subsequent checks")

	player = rotation_player()
	prepare_rotation(player)
	hunter.config.replacement_names = ["unknown family"]
	check(await rotation.ensure_ready(true) and hunter.team_update_calls.is_empty() and player.team == [1,2,3,4], "No eligible selected names keeps the current team and sends no update")
	player = rotation_player()
	prepare_rotation(player)
	hunter.config.auto_replace_max_level = false
	check(await rotation.ensure_ready(true) and hunter.team_update_calls.is_empty(), "Disabled automatic replacement sends no team request")
	prepare_rotation(player)
	var battle = StudyBattle.new()
	add_child(battle)
	BattleAnimator.battle = battle
	check(not await rotation.ensure_ready(true) and hunter.team_update_calls.is_empty(), "An active battle prevents team changes")
	BattleAnimator.battle = null
	hunter.campaign_world = false
	check(not await rotation.ensure_ready(true) and hunter.team_update_calls.is_empty(), "Travel/loading or a locked world prevents team changes")
	hunter.campaign_world = true

	player = rotation_player()
	prepare_rotation(player)
	hunter.hold_team_update = true
	rotation.ensure_ready(true)
	check(rotation.busy and player.team == [1,2,3,4] and hunter.team_update_calls.size() == 1, "Pending update preserves the old local team until server acknowledgement")
	check(not await rotation.ensure_ready(true) and hunter.team_update_calls.size() == 1, "Repeated ticks cannot duplicate a pending team request")
	hunter.toggle_running()
	hunter.toggle_running()
	check(not hunter.enabled and rotation.busy, "F8 pauses and waits for the pending team update")
	var busy_settings = hunter.panel.current_values()
	busy_settings.replacement_names = ["rocapez"]
	check(not hunter.live_config(busy_settings, false).is_empty(), "Pending team updates protect replacement settings from conflicting edits")
	hunter.team_update_released.emit()
	await get_tree().process_frame
	check(not hunter.enabled and not rotation.busy and player.team == [1,11,3,12], "Late successful update applies once while preserving Pause")
	hunter.toggle_running()
	check(hunter.enabled and await rotation.ensure_ready(true) and hunter.team_update_calls.size() == 1, "Explicit resume does not repeat an already applied team update")

	player = rotation_player()
	prepare_rotation(player)
	hunter.team_update_response.success = false
	check(not await rotation.ensure_ready(true) and not hunter.enabled and player.team == [1,2,3,4] and not rotation.uncertain, "Server rejection keeps the old team and pauses without retrying")
	player = rotation_player()
	prepare_rotation(player)
	hunter.team_update_response = {"success":false,"code":503}
	check(not await rotation.ensure_ready(true) and rotation.uncertain and player.team == [1,2,3,4], "Transport failure blocks retries because team state is uncertain")
	hunter.toggle_running()
	check(not hunter.enabled and hunter.team_update_calls.size() == 1, "F8 cannot repeat an uncertain team update")

	player = rotation_player()
	prepare_rotation(player)
	hunter.hold_team_update = true
	rotation.ensure_ready(true)
	rotation.deadline = 0
	rotation.watch_timeout()
	check(rotation.busy and rotation.uncertain and not hunter.enabled, "Team update timeout pauses with the request still guarded")
	hunter.team_update_released.emit()
	await get_tree().process_frame
	hunter.toggle_running()
	check(not hunter.enabled and player.team == [1,11,3,12] and hunter.team_update_calls.size() == 1, "Late timed-out success updates the local team once but cannot restart automation")

	player = rotation_player()
	prepare_rotation(player)
	hunter.after_team_update = func(): player.team.assign([1,10,3,4])
	check(not await rotation.ensure_ready(true) and rotation.uncertain and player.team == [1,10,3,4], "A conflicting team change is preserved and stops progression")
	player = rotation_player()
	prepare_rotation(player)
	hunter.after_team_update = func(): hunter.campaign_world = false
	check(not await rotation.ensure_ready(true) and not hunter.enabled and player.team == [1,11,3,12], "Successful update followed by a world transition pauses before starting another battle")

	player = rotation_player()
	prepare_rotation(player)
	hunter.hold_team_update = true
	hunter._process(0.3)
	check(rotation.busy and hunter.team_update_calls.size() == 1, "Wild search preflight routes max-level teammates through the guarded replacement request")
	hunter.toggle_running()
	hunter.team_update_released.emit()
	await get_tree().process_frame
	check(not hunter.enabled and player.team == [1,11,3,12], "Paused wild-search replacement cannot dispatch a search after the late reply")

	player = rotation_player()
	prepare_rotation(player)
	var campaign_config = hunter.panel.current_values()
	campaign_config.campaign_enabled = true
	campaign_config.campaign_stage_limit = 2
	hunter.apply_config(campaign_config)
	hunter.enabled = false
	hunter.hold_team_update = true
	hunter.toggle_running()
	hunter.campaign.wins = 1
	hunter.campaign.tick(0.3)
	check(rotation.busy and hunter.campaign.busy and hunter.campaign_create_calls == 0 and hunter.healing_calls == 0, "Campaign waits for team replacement before healing or starting the next stage")
	hunter.toggle_running()
	hunter.team_update_released.emit()
	await get_tree().process_frame
	check(not hunter.enabled and not hunter.campaign.busy and hunter.campaign.phase == "info", "Pausing a campaign team update returns to a resumable between-stage state")
	hunter.toggle_running()
	hunter.campaign.tick(0.3)
	check(hunter.campaign.wins == 1 and hunter.campaign_create_calls == 1 and hunter.team_update_calls.size() == 1, "Campaign resumes with its victory count and starts only after confirmed replacement")
	battle.free()
	hunter.enabled = false
	hunter.rotation.uncertain = false
	hunter.rotation.next_scan = 0
	server.Player = old_player
	BattleAnimator.battle = old_battle
	server.current_battle_id = old_id
	reset_hunt()
