extends RefCounted

# Campaign requests use the native next-stage endpoint. No stage IDs or results
# are supplied by this controller; every victory must be confirmed by the server.
var host
var phase = "idle"
var busy = false
var uncertain = false
var match_id = ""
var info: Dictionary = {}
var wins = 0
var last_completed = -1
var need_progress = false
var summary_seen = false
var turns = 0
var request_deadline = 0
var status = "Enable Auto Clear, then press Start / F8."

func owns(id: String) -> bool:
	return not match_id.is_empty() and id == match_id

func reset():
	phase = "idle"
	uncertain = false
	match_id = ""
	info = {}
	wins = 0
	last_completed = -1
	need_progress = false
	summary_seen = false
	turns = 0
	status = "Enable Auto Clear, then press Start / F8."

func message(text: String):
	status = text
	host.announce("campaign", text, {"campaign_phase":phase, "campaign_wins":wins})

func fail(text: String, unknown_request: bool = false):
	uncertain = uncertain or unknown_request
	phase = "stopped"
	host.enabled = false
	message(text)

func toggle():
	if host.enabled:
		host.enabled = false
		message("Campaign paused. Submitted actions may still finish.")
		return
	if busy:
		message("Waiting for the submitted campaign request; no duplicate request was sent.")
		return
	if uncertain:
		message("Campaign request outcome is uncertain. Reconcile the battle and reopen the game before starting again.")
		return
	if phase == "joining":
		message("Waiting for the created campaign battle to load before resuming.")
		return
	if Server.spectator or host.manual_battle_open():
		message("Finish the open manual battle before starting campaign.")
		return
	host.manual_battle_id = ""
	var battle = BattleAnimator.battle
	if is_instance_valid(battle):
		if owns(str(Server.current_battle_id)) and phase in ["battle", "summary", "return"] and battle.battle_type == "Campaign":
			host.enabled = true
			host.deadline = Time.get_ticks_msec() + 60000
			message("Campaign resumed.")
		else:
			message("Finish and close the open battle before starting campaign.")
		return
	if Server.Player == null or not host.campaign_connected():
		message("Log in and connect before starting campaign.")
		return
	if not host.campaign_world_ready() or not str(Server.current_battle_id).is_empty():
		message("Wait until you return to the world before starting campaign.")
		return
	if host.pending_search or host.name_traveling:
		message("Finish the pending search or travel before starting campaign.")
		return
	# Pausing between stages retains the session limit and progress check.
	if phase not in ["info", "return"]: reset()
	phase = "info"
	host.enabled = true
	host.needs_rearm = false
	message("Loading your next campaign stage.")

func plan(data, player_level: int) -> Dictionary:
	if not data is Dictionary: return {"error":"Campaign progress could not be loaded."}
	for key in ["last_completed", "tries"]:
		var value = data.get(key)
		if not (value is int or value is float) or not is_finite(float(value)) or value < 0 or value != floor(value):
			return {"error":"Invalid campaign progress: " + key + "."}
	if data.tries > 10 or data.last_completed > Constants.CAMPAIGN_LAST_LEVEL:
		return {"error":"Campaign progress is outside the supported range."}
	var next = int(data.last_completed) + 1
	if next > Constants.CAMPAIGN_LAST_LEVEL: return {"complete":true}
	if data.tries >= 10: return {"error":"No campaign attempts remain today."}
	var campaign_name = Utils.get_current_campaign(next)
	if not Constants.available_campaigns.has(campaign_name): return {"error":"This campaign is not available in this client."}
	var required = int(Constants.available_campaigns[campaign_name].min_level)
	if player_level < required: return {"error":"Next campaign requires player level %d." % required}
	return {"stage":next, "campaign":campaign_name, "remaining":10 - int(data.tries)}

func fainted_count(player) -> int:
	if player == null or player.team.is_empty(): return -1
	var count = 0
	var seen = {}
	for id in player.team:
		if seen.has(id) or not player.miscrits.has(id) or player.miscrits[id] == null: return -1
		seen[id] = true
		if player.miscrits[id].chp <= 0: count += 1
	return count

func heal_before_stage() -> bool:
	var player = Server.Player
	if player == null or player.virtue < 10:
		fail("Two or more teammates have fainted. Need 10 virtue to heal before continuing campaign.")
		return false
	busy = true
	phase = "heal"
	request_deadline = Time.get_ticks_msec() + 60000
	message("Two or more teammates have fainted. Healing with 10 virtue before the next stage.")
	WorldManager.acquire_move_lock()
	UiManager.block_all_inputs("campaign_virtue_heal")
	var response = await host.request_healing()
	UiManager.release_inputs_block("campaign_virtue_heal")
	WorldManager.release_move_lock()
	busy = false
	if Server.Player != player:
		fail("Player changed during virtue healing; check healing status before restarting.", true)
		return false
	if not response is Dictionary or response.get("success") != true:
		var unknown = not response is Dictionary or response.get("code", 0) != 0
		fail("Virtue healing was rejected or unavailable. Campaign paused; no next stage was started.", unknown)
		return false
	# Match Server.heal: apply the native HP, virtue and timestamp updates only
	# after success, including a success that arrives after Pause or timeout.
	player.heal_team()
	if not uncertain: phase = "info"
	if not host.enabled or uncertain: return false
	if not host.campaign_connected() or not host.campaign_world_ready() or is_instance_valid(BattleAnimator.battle) or not str(Server.current_battle_id).is_empty():
		fail("Team healed, but the world or connection changed. Campaign paused.")
		return false
	if fainted_count(player) != 0:
		fail("Team health did not refresh after healing. Campaign paused.", true)
		return false
	phase = "info"
	return true

func load_next():
	if busy or not host.enabled: return
	busy = true
	request_deadline = Time.get_ticks_msec() + 60000
	var result = await host.request_campaign_info()
	busy = false
	if not host.enabled: return
	if not host.campaign_connected():
		fail("Connection lost while loading campaign progress.")
		return
	var next = plan(result, Server.Player.level if Server.Player != null else -1)
	if next.has("error"):
		fail(next.error)
		return
	info = result.duplicate(true)
	if need_progress and int(info.last_completed) <= last_completed:
		fail("Victory was received, but campaign progress has not advanced. Check the campaign screen before retrying.")
		return
	need_progress = false
	if next.get("complete", false):
		fail("All available campaign stages are cleared.")
		return
	if wins >= host.config.get("campaign_stage_limit", 10):
		fail("Campaign stage limit reached: %d win(s)." % wins)
		return
	if not host.campaign_world_ready() or is_instance_valid(BattleAnimator.battle) or not str(Server.current_battle_id).is_empty():
		fail("The world changed while loading campaign progress; no battle was started.")
		return
	if host.config.get("train_selected", false):
		busy = true
		phase = "training"
		for id in Server.Player.team.duplicate():
			var member = Server.Player.miscrits.get(id)
			while host.enabled and host.training_allowed(member):
				request_deadline = Time.get_ticks_msec() + 60000
				await host.train_miscrit(member)
		busy = false
		phase = "info"
		if not host.enabled or not host.campaign_world_ready() or not host.campaign_connected(): return
	if host.config.get("auto_replace_max_level", false) or host.config.get("train_selected", false):
		busy = true
		phase = "team"
		var ready = await host.rotation.ensure_ready(true)
		busy = false
		if not host.rotation.uncertain: phase = "info"
		if not ready or not host.enabled: return
	var fainted = fainted_count(Server.Player)
	if fainted < 0:
		fail("Campaign team is not fully loaded. Check your team before continuing.")
		return
	if fainted >= 2:
		if not await heal_before_stage(): return
	elif Server.Player.all_miscrits_dead():
		fail("Heal your team before starting the next campaign stage.")
		return
	last_completed = int(info.last_completed)
	busy = true
	phase = "request"
	request_deadline = Time.get_ticks_msec() + 60000
	message("Starting campaign stage %d · %d attempt(s) remaining." % [next.stage, next.remaining])
	var response = await host.request_campaign_battle()
	busy = false
	if not response is Dictionary or not response.get("success", false):
		fail("Campaign battle request failed. Check the campaign screen before retrying.", not response is Dictionary)
		return
	var data = response.get("data")
	if not data is Dictionary or not data.get("matchId") is String or data.matchId.is_empty():
		fail("Campaign response has no valid battle ID; check the campaign screen.", true)
		return
	match_id = data.matchId
	host.reset_battle()
	host.match_id = match_id
	host.pending_search = false
	host.encounter_checked = false
	host.leaving = false
	host.deadline = Time.get_ticks_msec() + 60000
	summary_seen = false
	turns = 0
	# A successful request must be joined even if Pause was pressed meanwhile.
	# It stays manual until the user explicitly resumes.
	if not uncertain: phase = "joining"
	host.spawn_campaign_battle(match_id)
	message("Campaign battle created. Waiting for battle setup." if host.enabled else "Campaign battle created while paused; no automated combat will be sent.")

func on_battle_started(kind: String, id: String):
	if not owns(id): return
	if kind != "Campaign" or Server.spectator:
		fail("Unexpected battle type; battle left open.", true)
		return
	if uncertain: return
	phase = "battle"
	host.encounter_checked = true
	host.history.fight = true
	host.deadline = Time.get_ticks_msec() + 60000
	message("Campaign stage %d · %d win(s) this run." % [last_completed + 1, wins])

func on_summary(victor: String):
	if summary_seen: return
	summary_seen = true
	if Server.Player == null or victor != Server.Player.user_id:
		fail("Campaign battle lost. Summary left open; heal or adjust your team before retrying.")
		return
	wins += 1
	need_progress = true
	phase = "summary"
	message("Campaign victory · %d win(s)." % wins)

func combat_decision(state: Dictionary) -> Dictionary:
	var heal = host.policy.healing_decision(state.get("player", {}), state.get("foe", {}), host.history)
	var decision = heal if not heal.is_empty() else host.policy.fight(state.get("player", {}), state.get("foe", {}), host.history)
	if decision.action not in ["ability", "wait"]:
		return {"action":"stop", "reason":"No usable campaign attack. Battle left open for manual play."}
	return decision

func tick(delta: float):
	if not host.enabled: return
	var now = Time.get_ticks_msec()
	if busy:
		if now > request_deadline: fail("Campaign request timed out. Waiting for its result; no automatic retry.", phase in ["request", "heal"])
		return
	if Server.Player == null or not host.campaign_connected():
		fail("Campaign connection lost; no automatic retry.")
		return
	if Server.spectator:
		fail("Spectator battles cannot be automated.")
		return
	var battle = BattleAnimator.battle
	if is_instance_valid(battle):
		if not owns(str(Server.current_battle_id)) or battle.battle_type != "Campaign":
			fail("An unrelated battle is open; campaign paused.")
			return
		if now > host.deadline:
			fail("Campaign battle response timed out; battle left open.", true)
			return
		if phase == "summary" and host.summary_ref != null:
			var summary = host.summary_ref.get_ref()
			if is_instance_valid(summary):
				phase = "return"
				host.leaving = true
				summary._on_continue_pressed()
			return
		if phase != "battle": return
		host.elapsed += delta
		if host.elapsed < 0.25 or now < host.next_action: return
		host.elapsed = 0.0
		if not host.encounter_checked or not battle.winner.is_empty() or not host.can_take_turn(battle): return
		var state = host.campaign_snapshot(battle)
		if state.get("player", {}).is_empty() or state.get("foe", {}).is_empty():
			fail("Campaign battle state is missing; battle left open.")
			return
		if host.active_foe_id != int(state.foe.id):
			host.active_foe_id = int(state.foe.id)
			host.history = {"attacks":0, "flee":false, "damage":{}, "fight":true, "healed_members":host.history.get("healed_members", [])}
		if turns >= 200:
			fail("Campaign turn limit reached; battle left open for manual play.")
			return
		var decision = combat_decision(state)
		if decision.action == "wait": return
		if decision.action == "stop":
			fail(decision.reason)
			return
		turns += 1
		host.announce("campaign_action", decision.reason, {"decision":decision})
		host.perform_decision(battle, decision, now)
		return
	if phase in ["joining", "battle", "summary"]:
		if now > host.deadline: fail("Campaign battle did not finish loading; check the battle before restarting.", true)
		return
	if phase == "return" and now > host.deadline:
		fail("Return to the world timed out; campaign paused.")
		return
	if phase == "return" and host.campaign_world_ready() and str(Server.current_battle_id).is_empty():
		if wins >= host.config.get("campaign_stage_limit", 10):
			fail("Campaign stage limit reached: %d win(s)." % wins)
			return
		phase = "info"
	if phase == "info" and host.campaign_world_ready(): load_next()
