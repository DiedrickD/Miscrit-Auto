extends RefCounted

# These are decisions, never server outcome predictions. AP is only a ranking.
func decide(state: Dictionary, config: Dictionary, history: Dictionary) -> Dictionary:
	var foe = state.get("foe", {})
	var player = state.get("player", {})
	if foe.is_empty() or player.is_empty():
		return {"action": "stop", "reason": "Missing battle state."}
	var healing = healing_decision(player, foe, history)
	if not healing.is_empty(): return healing
	if history.get("fight", false) or config.get("combat_mode", config.get("mode")) == "fight":
		return fight(player, foe, history)
	if history.get("flee", false) or foe.get("attempts", 0) > 0:
		return {"action": "flee", "reason": "Capture failed or an attempt was already used; no paid retry."}
	var chance = state.get("capture_chance")
	if not (chance is int or chance is float) or not is_finite(float(chance)) or chance < 0 or chance > 100:
		return {"action": "stop", "reason": "Missing or invalid server capture chance."}
	if foe.chp <= 0 or player.chp <= 0 or foe.get("captured", false):
		return {"action": "wait", "reason": "Waiting for server battle transition."}
	if chance >= config.capture_threshold:
		return {"action": "capture", "reason": "Server capture chance meets threshold."}
	var incoming = history.get("incoming", {}).get(str(int(player.id)), 0)
	if incoming > 0 and player.chp <= ceil(incoming * 1.5):
		return {"action": "capture", "reason": "Capture now before another estimated enemy hit defeats the active teammate."}
	if player.hp <= 0 or foe.hp <= 0:
		return {"action": "stop", "reason": "Invalid maximum HP."}
	if float(player.chp) * 100.0 / player.hp <= config.min_player_hp_percent:
		return {"action": "flee", "reason": "Player HP reached the configured floor."}
	if history.get("attacks", 0) >= config.max_attacks:
		return {"action": "flee", "reason": "Attack limit reached before capture threshold."}
	if float(foe.chp) * 100.0 / foe.hp <= config.min_target_hp_percent:
		return {"action": "flee", "reason": "Target HP reached the configured floor before capture threshold."}
	if history.get("target_damage_risk", false):
		return {"action": "flee", "reason": "Target has ongoing damage that cannot be safely predicted."}
	var candidates = []
	var observed_for_pair = false
	var pair_prefix = "%d:%d:" % [int(player.id), int(foe.id)]
	for key in history.get("damage", {}):
		if key.begins_with(pair_prefix):
			observed_for_pair = true
	for a in player.get("abilities", []):
		if a.recharge != 0 or a.type != "Attack" or a.target != "Foe" or a.times != 1 or not a.additional.is_empty():
			continue
		if not config.ability_ids.is_empty() and a.id not in config.ability_ids:
			continue
		var ap = a.ap
		if a.get("enchanted", false):
			# Unknown enchant behavior is not treated as a plain attack.
			var enc = a.get("enchant", {})
			var plain = true
			for key in enc:
				if key not in ["ap", "accuracy", "desc"]:
					plain = false
			if not plain:
				continue
			ap += enc.get("ap", 0)
		if not (ap is int or ap is float) or ap <= 0:
			continue
		var key = damage_key(player.id, foe.id, a.id)
		var observed = history.get("damage", {}).get(key, 0)
		var uncertainty = history.get("damage_uncertainty", {}).get(key, 1.0)
		if observed == 0:
			for source in player.get("abilities", []):
				if source.get("element", "Physical") != a.get("element", "Physical") or source.get("true_damage", false) != a.get("true_damage", false): continue
				if source.type != "Attack" or source.target != "Foe" or source.times != 1 or not source.additional.is_empty(): continue
				var source_ap = source.ap + (source.get("enchant", {}).get("ap", 0) if source.get("enchanted", false) else 0)
				var source_key = damage_key(player.id, foe.id, source.id)
				var measured = history.get("damage", {}).get(source_key, 0)
				if source_ap > 0 and measured > 0:
					observed = max(observed, ceil(measured * max(1.0, float(ap) / source_ap)))
					uncertainty = max(uncertainty, history.get("damage_uncertainty", {}).get(source_key, 1.0) * 1.25)
		if observed_for_pair and observed == 0:
			continue
		# Relevant buffs widen the estimate until another hit measures the new conditions.
		var guard = ceil(observed * config.damage_margin * uncertainty) + 2 if observed > 0 else 0
		if observed > 0 and foe.chp - guard <= max(1, ceil(foe.hp * config.min_target_hp_percent / 100.0)):
			continue
		candidates.append({"id": a.id, "name": a.name, "ap": ap, "observed_damage": observed,
			"damage_guard": guard, "estimate_uncertainty": uncertainty})
	if candidates.is_empty():
		return {"action": "flee", "reason": "No available simple attack within the configured damage guard."}
	candidates.sort_custom(func(a, b):
		if a.damage_guard != b.damage_guard: return a.damage_guard > b.damage_guard
		return a.ap < b.ap or (a.ap == b.ap and a.id < b.id))
	var chosen = candidates[0]
	var rate = history.get("capture_gain_per_hp", {}).get(pair_prefix, 0.0)
	var estimated_hits = null
	if rate > 0 and chosen.observed_damage > 0:
		estimated_hits = int(ceil((config.capture_threshold - chance) / (rate * chosen.observed_damage)))
	return {"action": "ability", "id": chosen.id, "name": chosen.name,
		"observed_damage": chosen.observed_damage,
		"damage_guard": chosen.damage_guard, "remaining_hp_after_hit": foe.chp - chosen.observed_damage,
		"estimated_hits_to_threshold": estimated_hits, "estimate_uncertainty": chosen.estimate_uncertainty,
		"reason": "Remaining HP exceeds estimated hit damage; keep weakening and recheck server capture chance." if chosen.observed_damage > 0 else "Measure the weakest simple attack before planning further hits."}

func damage_key(player_id, foe_id, ability_id) -> String:
	# JSON response numbers are floats; client ability IDs are ints. Use one key format.
	return "%d:%d:%d" % [int(player_id), int(foe_id), int(ability_id)]

func observe(data: Dictionary, opcode: int, before: Dictionary, history: Dictionary):
	if before.get("player", {}).is_empty() or before.get("foe", {}).is_empty():
		return
	if not history.has("damage_uncertainty"): history.damage_uncertainty = {}
	if not history.has("capture_gain_per_hp"): history.capture_gain_per_hp = {}
	if not history.has("incoming"): history.incoming = {}
	var incoming = 0
	for action in data.get("actions", []):
		if action.get("target") == before.player.user_id:
			incoming += max(0, int(action.get("damage", 0)))
	if incoming > 0:
		var player_key = str(int(before.player.id))
		history.incoming[player_key] = max(incoming, history.incoming.get(player_key, 0))
	var total = 0
	if opcode == 2 and data.get("user_id") == before.player.user_id:
		history.last_attack = {"player": int(before.player.id), "foe": int(before.foe.id), "id": int(data.get("id", -1))}
		for action in data.get("actions", []):
			if action.get("target") == before.foe.user_id and action.get("type") == "Attack":
				total += max(0, int(action.get("damage", 0)))
	if total > 0:
		var key = damage_key(before.player.id, before.foe.id, data.get("id"))
		history.damage[key] = max(history.damage.get(key, 0), total)
		history.damage_uncertainty[key] = 1.0
		var old_chance = before.get("capture_chance")
		var new_chance = data.get("capture_chance")
		if (old_chance is int or old_chance is float) and (new_chance is int or new_chance is float) and new_chance > old_chance:
			var pair = "%d:%d:" % [int(before.player.id), int(before.foe.id)]
			history.capture_gain_per_hp[pair] = float(new_chance - old_chance) / total
	# Process modifiers after recording damage so a buff in the same response cannot
	# accidentally mark the earlier hit as a measurement of the new conditions.
	for action in data.get("actions", []):
		var target = action.get("target", "")
		if target == before.foe.user_id and action.get("type") in ["Poison", "Dot", "TimeBomb", "Bleed", "Disease"]:
			history.target_damage_risk = true
		for a in before.player.get("abilities", []):
			var key = damage_key(before.player.id, before.foe.id, a.id)
			if history.damage.get(key, 0) > 0 and affects_damage(action, a, before):
				history.damage_uncertainty[key] = min(16.0, history.damage_uncertainty.get(key, 1.0) * 2.0)

func affects_damage(action: Dictionary, ability: Dictionary, state: Dictionary) -> bool:
	if ability.get("true_damage", false): return false
	var kind = action.get("type", "")
	var target = action.get("target", "")
	if target not in [state.player.user_id, state.foe.user_id]: return false
	var physical = ability.get("element", "Physical") == "Physical"
	if kind in ["Negate", "Purge", "Cleanser", "Ethereal", "EtherealBlock", "Block", "BlockDamage"]:
		return kind != "Negate" or not physical
	if kind not in ["Buff", "Bot", "Debuff"]: return false
	var stat = ("pa" if physical else "ea") if target == state.player.user_id else ("pd" if physical else "ed")
	var changed = action.get("buffs", action.get("stats", {}))
	if not changed.is_empty(): return changed.has(stat)
	var keys = action.get("keys", [])
	return keys.is_empty() or stat in keys

func fight(player: Dictionary, foe: Dictionary, history: Dictionary = {}) -> Dictionary:
	if player.chp <= 0 or foe.chp <= 0:
		return {"action": "wait", "reason": "Waiting for battle transition."}
	var best = {}
	var best_power = 0.0
	var alternative = {}
	var alternative_power = 0.0
	var last = history.get("last_attack", {})
	var previous_id = last.get("id", -1) if last.get("player") == int(player.id) and last.get("foe") == int(foe.id) else -1
	for a in player.get("abilities", []):
		if a.recharge != 0 or a.type != "Attack" or a.target != "Foe": continue
		var ap = a.ap + (a.get("enchant", {}).get("ap", 0) if a.get("enchanted", false) else 0)
		var power = ap * a.times
		if a.id != previous_id and power > alternative_power:
			alternative = a
			alternative_power = power
		if power > best_power:
			best = a
			best_power = power
	if best.is_empty(): return {"action": "flee", "reason": "No usable damaging attack."}
	if previous_id != -1 and not alternative.is_empty():
		return {"action": "ability", "id": alternative.id, "name": alternative.name, "reason": "Fight: enemy survived; follow up with the strongest available different attack."}
	return {"action": "ability", "id": best.id, "name": best.name, "reason": "Fight: highest available attack power."}

func healing_decision(player: Dictionary, foe: Dictionary, history: Dictionary) -> Dictionary:
	if player.get("chp", 0) <= 0 or foe.get("chp", 0) <= 0 or player.get("hp", 0) <= 0: return {}
	if foe.get("captured", false) or history.get("flee", false) or foe.get("attempts", 0) > 0: return {}
	if player.get("healing_blocked", false) or player.chp > player.hp * 0.5: return {}
	if str(int(player.id)) in history.get("healed_members", []): return {}
	var best = {}
	var best_amount = 0
	for a in player.get("abilities", []):
		if a.type != "Heal" or a.target != "Self" or a.recharge != 0: continue
		if a.times != 1 or not a.additional.is_empty(): continue
		var amount = a.ap + (a.get("enchant", {}).get("ap", 0) if a.get("enchanted", false) else 0)
		if amount > best_amount:
			best = a
			best_amount = amount
	if best.is_empty(): return {}
	return {"action": "ability", "id": best.id, "name": best.name, "healing": true,
		"reason": "HP is at or below 50%; use an available self-heal once before finishing battle."}
