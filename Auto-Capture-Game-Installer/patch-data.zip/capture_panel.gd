extends "res://capture_panel_base.gd"

var tabs: TabContainer
var visuals: CheckButton
var platinum: CheckButton
var control_pages: Array = []
var control_buttons: Array = []
var mode_help: Label
var rating_fields: HBoxContainer
var other_rating_field: VBoxContainer
var apply_ratings: Button
var remove_target: Button
var other_rating: SpinBox
var flee_others: CheckButton
var orb: Button
var platinum_slots: Array = []
var route_toggle: CheckButton
var route_summary: Label
var finder: CheckButton
var badge: Label
var collapse: Button
var battle_list: Tree
var battle_count: Label
var battle_min: SpinBox
var object_list: Tree
var object_count: Label
var object_latest: Label
var resizing = false
var resize_origin = Vector2.ZERO
var resize_size = Vector2.ZERO
var expanded_size = Vector2(560, 710)
var name_query: LineEdit
var name_suggestions: ItemList
var selected_targets: Tree
var target_status: Label
var target_refresh = 0.0
var campaign_toggle: CheckButton
var campaign_limit: SpinBox
var campaign_progress: Label
var team_tabs: TabContainer
var replacement_toggle: CheckButton
var replacement_query: LineEdit
var replacement_suggestions: ItemList
var replacement_list: Tree
var replacement_status: Label
var replacement_remove: Button
var train_selected_toggle: CheckButton
var low_rating_toggle: CheckButton
var remove_kept_toggle: CheckButton
var tier_views: Dictionary = {}
var capture_chance_field: SpinBox
var max_attacks_field: SpinBox
const INK = Color("e5edf6")
const MUTED = Color("a8b8ca")
const ACCENT = Color("65dbc5")

func box(color: String, border: String = "26384d", radius: int = 8, padding: int = 10) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = Color(color)
	style.border_color = Color(border)
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	return style

func switch_icon(active: bool) -> Texture2D:
	var image = Image.new()
	image.load_svg_from_string('<svg xmlns="http://www.w3.org/2000/svg" width="48" height="26"><rect x="1" y="1" width="46" height="24" rx="12" fill="%s"/><circle cx="%s" cy="13" r="9" fill="%s"/></svg>' % ["#65dbc5" if active else "#526277", "35" if active else "13", "#112a2b" if active else "#ecf2f9"])
	return ImageTexture.create_from_image(image)

func make_theme() -> Theme:
	var theme = Theme.new()
	var font = SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	theme.default_font = font
	theme.default_font_size = 15
	for type in ["Label", "Button", "OptionButton", "LineEdit", "CheckButton", "CheckBox", "Tree", "ItemList", "TabContainer", "TabBar"]:
		theme.set_color("font_color", type, INK)
		theme.set_color("font_hover_color", type, Color.WHITE)
		theme.set_color("font_pressed_color", type, INK)
		theme.set_color("font_focus_color", type, Color.WHITE)
		theme.set_font("font", type, font)
	for type in ["Button", "OptionButton", "LineEdit"]:
		theme.set_stylebox("normal", type, box("1b2b3e"))
		theme.set_stylebox("hover", type, box("263b51", "5e8496"))
		theme.set_stylebox("pressed", type, box("234b4d", "65dbc5"))
		var focus = box("172c3b", "65dbc5", 8, 0)
		focus.draw_center = false
		focus.set_border_width_all(2)
		theme.set_stylebox("focus", type, focus)
	theme.set_color("caret_color", "LineEdit", ACCENT)
	theme.set_color("font_placeholder_color", "LineEdit", MUTED)
	for suffix in ["", "_disabled"]:
		theme.set_icon("checked" + suffix, "CheckButton", switch_icon(true))
		theme.set_icon("unchecked" + suffix, "CheckButton", switch_icon(false))
	theme.set_stylebox("normal", "CheckButton", box("142232", "142232", 8, 8))
	theme.set_stylebox("hover", "CheckButton", box("1d3044", "36586b", 8, 8))
	theme.set_stylebox("panel", "TabContainer", box("111e2d", "26384d", 8, 10))
	for type in ["TabContainer", "TabBar"]:
		theme.set_stylebox("tab_selected", type, box("254442", "65dbc5", 6, 10))
		theme.set_stylebox("tab_unselected", type, box("152333", "152333", 6, 10))
		theme.set_stylebox("tab_hovered", type, box("24394d", "456477", 6, 10))
		theme.set_color("font_selected_color", type, ACCENT)
		theme.set_color("font_unselected_color", type, MUTED)
	theme.set_stylebox("panel", "Tree", box("111e2d", "26384d", 6, 6))
	theme.set_stylebox("selected", "Tree", box("234542", "65dbc5", 4, 4))
	theme.set_stylebox("selected_focus", "Tree", box("234542", "65dbc5", 4, 4))
	theme.set_stylebox("panel", "ItemList", box("142637", "36586b", 6, 6))
	theme.set_stylebox("selected", "ItemList", box("234542", "65dbc5", 4, 4))
	theme.set_stylebox("selected_focus", "ItemList", box("234542", "65dbc5", 4, 4))
	theme.set_stylebox("title_button_normal", "Tree", box("1b2b3e", "1b2b3e", 4, 6))
	theme.set_stylebox("title_button_hover", "Tree", box("263b51", "36586b", 4, 6))
	theme.set_constant("v_separation", "Tree", 10)
	return theme

func note(text: String, parent) -> Label:
	var item = label(text, parent)
	item.add_theme_color_override("font_color", MUTED)
	item.add_theme_font_size_override("font_size", 14)
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return item

func switch(text: String, parent, action: Callable) -> CheckButton:
	var item = CheckButton.new()
	item.text = text
	item.custom_minimum_size.y = 44
	item.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	parent.add_child(item)
	item.toggled.connect(action)
	return item

func tab(title: String) -> VBoxContainer:
	var page = VBoxContainer.new()
	page.name = title
	page.add_theme_constant_override("separation", 10)
	tabs.add_child(page)
	return page

func table(parent, titles: Array) -> Tree:
	var item = Tree.new()
	item.columns = titles.size()
	item.column_titles_visible = true
	item.hide_root = true
	item.size_flags_vertical = Control.SIZE_EXPAND_FILL
	item.custom_minimum_size.y = 80
	item.add_theme_font_size_override("font_size", 14)
	item.add_theme_font_size_override("title_button_font_size", 13)
	for i in range(titles.size()):
		item.set_column_title(i, titles[i])
		item.set_column_expand_ratio(i, 4 if i == 0 or i == titles.size() - 1 else 2)
	parent.add_child(item)
	return item

func _ready():
	layer = 110
	panel = PanelContainer.new()
	panel.position = Vector2(20, 36)
	panel.custom_minimum_size.x = 440
	panel.theme = make_theme()
	var frame = box("101c2b", "426171", 14, 14)
	frame.shadow_color = Color(0, 0, 0, 0.3)
	frame.shadow_size = 8
	panel.add_theme_stylebox_override("panel", frame)
	add_child(panel)
	var stack = VBoxContainer.new()
	stack.add_theme_constant_override("separation", 8)
	panel.add_child(stack)
	var header = HBoxContainer.new()
	stack.add_child(header)
	var title = label("Auto Capture", header)
	title.add_theme_font_size_override("font_size", 20)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.mouse_filter = Control.MOUSE_FILTER_STOP
	title.mouse_default_cursor_shape = Control.CURSOR_MOVE
	title.tooltip_text = "Drag to move the panel"
	title.gui_input.connect(drag_header)
	badge = label("PAUSED", header)
	badge.add_theme_font_size_override("font_size", 12)
	badge.add_theme_color_override("font_color", Color("efc781"))
	collapse = button("—", header, toggle_collapsed)
	collapse.custom_minimum_size.x = 36
	collapse.tooltip_text = "Minimize to a floating circle"
	toggle = button("Start automation", stack, func(): hunter.toggle_running())
	toggle.add_theme_stylebox_override("normal", box("22483f", "438b7b"))
	toggle.custom_minimum_size.y = 42
	body = VBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 8)
	stack.add_child(body)
	var status_card = PanelContainer.new()
	status_card.add_theme_stylebox_override("panel", box("142637", "2d4559", 8, 10))
	body.add_child(status_card)
	status = note("", status_card)
	status.custom_minimum_size.y = 28
	status.add_theme_font_size_override("font_size", 13)
	status.max_lines_visible = 2
	status.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	tabs = TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.custom_minimum_size.y = 180
	body.add_child(tabs)
	build_controls()
	build_captures()
	build_battles()
	feedback = note("Ready. Choose your targets to begin.", body)
	feedback.custom_minimum_size.y = 20
	feedback.max_lines_visible = 2
	feedback.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	var footer = HBoxContainer.new()
	body.add_child(footer)
	button("Compact", footer, func(): set_panel_size(Vector2(460, 560)); save_layout())
	button("Default", footer, func(): set_panel_size(Vector2(560, 710)); save_layout())
	button("Large", footer, func(): set_panel_size(Vector2(820, 750)); save_layout())
	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(spacer)
	var grip = button("Resize", footer, func(): pass)
	grip.tooltip_text = "Drag to resize. Size buttons are also available."
	grip.mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
	grip.gui_input.connect(resize_handle)
	sync_fields()
	refresh_history()
	refresh_battles()
	refresh_objects()
	orb = Button.new()
	orb.text = "AC"
	orb.tooltip_text = "Open Auto Capture"
	orb.custom_minimum_size = Vector2(58, 58)
	orb.size = Vector2(58, 58)
	orb.theme = panel.theme
	orb.add_theme_stylebox_override("normal", box("163c3b", "65dbc5", 29, 0))
	orb.add_theme_stylebox_override("hover", box("245b53", "99f5dd", 29, 0))
	orb.add_theme_stylebox_override("pressed", box("102d2c", "65dbc5", 29, 0))
	orb.pressed.connect(toggle_collapsed)
	add_child(orb)
	orb.hide()
	load_layout()
	get_viewport().size_changed.connect(clamp_panel)
	clamp_panel.call_deferred()

func build_controls():
	var page = tab("Controls")
	var navigation = HBoxContainer.new()
	navigation.add_theme_constant_override("separation", 8)
	page.add_child(navigation)
	for index in range(3):
		var item = button(["Targets", "Battle setup", "Campaign"][index], navigation, func(): set_control_page(index))
		item.toggle_mode = true
		item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		control_buttons.append(item)
		var content = VBoxContainer.new()
		content.size_flags_vertical = Control.SIZE_EXPAND_FILL
		content.add_theme_constant_override("separation", 8)
		page.add_child(content)
		control_pages.append(content)
	var target_scroll = ScrollContainer.new()
	target_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	target_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	control_pages[0].add_child(target_scroll)
	var target_page = VBoxContainer.new()
	target_page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	target_page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	target_page.add_theme_constant_override("separation", 8)
	target_scroll.add_child(target_page)
	var target_heading = HBoxContainer.new()
	target_page.add_child(target_heading)
	var heading = label("Your search targets", target_heading)
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_theme_font_size_override("font_size", 17)
	remove_target = button("Remove", target_heading, remove_name_target)
	remove_target.tooltip_text = "Remove the selected Miscrit from your search"
	var target_actions = HBoxContainer.new()
	target_page.add_child(target_actions)
	button("Mapped tier targets", target_actions, import_tier_targets)
	button("Clear all targets", target_actions, func(): save_name_targets([]))
	var order_actions = HBoxContainer.new()
	target_page.add_child(order_actions)
	button("Move up", order_actions, func(): move_target(-1))
	button("Move down", order_actions, func(): move_target(1))
	button("Main / first", order_actions, func(): move_target(-999))
	name_query = LineEdit.new()
	name_query.placeholder_text = "Find a Miscrit… type 3 or more letters"
	name_query.clear_button_enabled = true
	name_query.custom_minimum_size.y = 40
	target_page.add_child(name_query)
	name_query.text_changed.connect(refresh_suggestions)
	name_suggestions = ItemList.new()
	name_suggestions.custom_minimum_size.y = 100
	name_suggestions.item_selected.connect(add_name_target)
	target_page.add_child(name_suggestions)
	name_suggestions.hide()
	selected_targets = table(target_page, ["Miscrit", "Location / availability"])
	selected_targets.custom_minimum_size.y = 115
	selected_targets.item_selected.connect(func(): remove_target.disabled = selected_targets.get_selected() == null)
	target_status = note("", target_page)
	target_page.move_child(target_actions, target_page.get_child_count() - 1)
	target_page.move_child(order_actions, target_page.get_child_count() - 1)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	control_pages[1].add_child(scroll)
	var form = VBoxContainer.new()
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	form.add_theme_constant_override("separation", 10)
	scroll.add_child(form)
	label("When an encounter begins", form).add_theme_font_size_override("font_size", 17)
	mode = OptionButton.new()
	for text in ["Fight only", "Capture any species", "Capture selected species", "Targets + high-rated others", "Manual battle for selected species"]:
		mode.add_item(text)
	mode.fit_to_longest_item = false
	mode.custom_minimum_size.y = 42
	form.add_child(mode)
	mode.item_selected.connect(func(index): apply_immediate("mode", MODES[index]))
	mode_help = note("", form)
	rating_fields = HBoxContainer.new()
	rating_fields.add_theme_constant_override("separation", 12)
	form.add_child(rating_fields)
	var selected_field = VBoxContainer.new()
	selected_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rating_fields.add_child(selected_field)
	label("Capture rating", selected_field)
	rating = number(selected_field, 11)
	rating.get_line_edit().text_submitted.connect(func(_text): apply_fields())
	other_rating_field = VBoxContainer.new()
	other_rating_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rating_fields.add_child(other_rating_field)
	label("Other species", other_rating_field)
	other_rating = number(other_rating_field, 16)
	other_rating.get_line_edit().text_submitted.connect(func(_text): apply_fields())
	apply_ratings = button("Save ratings", form, apply_fields)
	flee_others = switch("Run from unwanted encounters", form, func(value): apply_immediate("flee_non_targets", value))
	form.move_child(flee_others, 3)
	flee_others.tooltip_text = "Flee at the first legal turn if the whole encounter fails your target and rating rules."
	low_rating_toggle = switch("Allow selected captures below minimum rating", form, func(value): apply_immediate("capture_low_rating_targets", value))
	remove_kept_toggle = switch("Remove target after confirmed kept capture", form, func(value): apply_immediate("auto_remove_captured_targets", value))
	note("Lower-rated copies can be kept. Training still requires 17+. Removing a hunt target keeps its separate training upgrade queued.", form)
	label("Capture chance (%)", form)
	capture_chance_field = number(form, 70)
	capture_chance_field.max_value = 100
	capture_chance_field.min_value = 1
	label("Maximum weakening attacks", form)
	max_attacks_field = number(form, 12)
	max_attacks_field.min_value = 1
	max_attacks_field.max_value = 100
	button("Save capture settings", form, func():
		var candidate = current_values()
		candidate.capture_threshold = capture_chance_field.value
		candidate.max_attacks = max_attacks_field.value
		result(hunter.live_config(candidate)))
	note("Mode and switches save immediately. Use Save ratings after editing a minimum (0–18).", form)
	ids = LineEdit.new()
	targets = LineEdit.new()
	form.add_child(ids)
	form.add_child(targets)
	ids.hide()
	targets.hide()
	set_control_page(0)
	build_campaign()
	var training_page = tab("Team")
	team_tabs = TabContainer.new()
	team_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	training_page.add_child(team_tabs)
	var replacement_page = VBoxContainer.new()
	replacement_page.name = "Replacements"
	team_tabs.add_child(replacement_page)
	build_replacements(replacement_page)
	var training_options = VBoxContainer.new()
	training_options.name = "Training"
	team_tabs.add_child(training_options)
	var team_scroll = ScrollContainer.new()
	team_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	team_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	training_options.add_child(team_scroll)
	var switches = VBoxContainer.new()
	switches.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	switches.add_theme_constant_override("separation", 10)
	team_scroll.add_child(switches)
	level_up = switch("Auto level-up (free XP)", switches, func(value): apply_immediate("auto_level_up", value))
	level_up.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	level_up.tooltip_text = "Uses earned XP for levels. Optional platinum bonus is controlled separately."
	label("PLATINUM BONUS STATS", switches)
	note("Allow bonus stats for checked teammates only. 1 platinum after each free XP level-up.", switches)
	var grid = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	switches.add_child(grid)
	for index in range(4):
		var slot = switch("Empty slot", grid, func(value): toggle_platinum_slot(index, value))
		slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		slot.custom_minimum_size.y = 76
		slot.add_theme_stylebox_override("normal", box("1b2b3e", "365064", 10, 10))
		slot.add_theme_stylebox_override("disabled", box("142232", "26384d", 10, 10))
		platinum_slots.append(slot)
	refresh_platinum_slots()
	platinum = switch("Bonus stats (1 platinum / level)", switches, func(value): apply_immediate("platinum_upgrade", value))
	platinum.tooltip_text = "Buy bonus stats after automatic levels, only for checked team members, for exactly 1 platinum."
	platinum.hide()
	visuals = switch("Battle visuals", switches, func(value): apply_immediate("skip_skill_animations", not value))
	visuals.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	visuals.tooltip_text = "On: normal animations. Off: fast presentation. Applies to the next visual."
	build_collection_training()


func set_control_page(index: int):
	for i in range(control_pages.size()):
		control_pages[i].visible = i == index
		control_buttons[i].set_pressed_no_signal(i == index)

func build_collection_training():
	var page = VBoxContainer.new()
	page.name = "Collection"
	team_tabs.add_child(page)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	page.add_child(scroll)
	var form = VBoxContainer.new()
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	form.add_theme_constant_override("separation", 8)
	scroll.add_child(form)
	train_selected_toggle = switch("Train owned 17+ copies to level 35", form, toggle_selected_training)
	train_selected_toggle.add_theme_font_size_override("font_size", 14)
	var help = note("Slot 1 kept. Free XP only; one best copy per family.", form)
	help.tooltip_text = "Exotic > Rare > Common > Epic > Legendary. Uses the best owned 17+ copy, including unlisted copies in the next tiers. Any owned level-35 copy completes its family. Fourth evolution alone is not level-35 completion. Slot 1 and its family are excluded."
	for tier in hunter.rotation.TIERS:
		var section = VBoxContainer.new()
		form.add_child(section)
		var heading = button(tier, section, func(): tier_views[tier].body.visible = not tier_views[tier].body.visible)
		heading.add_theme_font_size_override("font_size", 13)
		var content = VBoxContainer.new()
		section.add_child(content)
		content.visible = tier == "Exotic"
		var actions = HBoxContainer.new()
		content.add_child(actions)
		var owned = button("Owned 17+", actions, func(): add_tier(tier, false))
		var mapped = button("Mapped targets", actions, func(): add_tier(tier, true))
		button("Clear tier", actions, func(): clear_tier(tier))
		var detail = note("", content)
		tier_views[tier] = {"heading":heading, "body":content, "owned":owned, "mapped":mapped, "detail":detail}
	note("Owned 17+ candidates in later tiers are automatic fallbacks. Selected names set the starting tier. Missing upgrades are hunted only when no owned trainee remains. All choices save immediately.", form)

func build_replacements(page):
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	page.add_child(scroll)
	var form = VBoxContainer.new()
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	form.size_flags_vertical = Control.SIZE_EXPAND_FILL
	form.add_theme_constant_override("separation", 4)
	scroll.add_child(form)
	replacement_toggle = switch("Replace level-35 teammates in slots 2–4", form, func(value): apply_immediate("auto_replace_max_level", value))
	replacement_toggle.add_theme_font_size_override("font_size", 14)
	replacement_toggle.custom_minimum_size.y = 32
	for state in ["normal", "hover", "pressed", "hover_pressed", "disabled"]:
		replacement_toggle.add_theme_stylebox_override(state, box("142232", "26384d", 6, 3))
	replacement_query = LineEdit.new()
	replacement_query.placeholder_text = "Find replacement Miscrit… 3 or more letters"
	replacement_query.clear_button_enabled = true
	replacement_query.custom_minimum_size.y = 32
	replacement_query.add_theme_stylebox_override("normal", box("1b2b3e", "26384d", 6, 6))
	form.add_child(replacement_query)
	replacement_query.text_changed.connect(refresh_replacement_suggestions)
	replacement_suggestions = ItemList.new()
	replacement_suggestions.custom_minimum_size.y = 90
	form.add_child(replacement_suggestions)
	replacement_suggestions.item_selected.connect(add_replacement_name)
	replacement_suggestions.hide()
	replacement_list = table(form, ["Replacement name", "Owned candidates"])
	replacement_list.custom_minimum_size.y = 100
	replacement_list.item_selected.connect(func(): replacement_remove.disabled = replacement_list.get_selected() == null)
	replacement_remove = button("Remove selected name", form, remove_replacement_name)
	replacement_status = note("", form)
	replacement_status.max_lines_visible = 3
	replacement_status.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	note("Slot 1 stays in place. Picks the highest-rated owned matches below level 35 from this separate list, between searches and campaign stages. Family names include evolutions. If no candidate remains, the current teammate stays. Existing teammates are excluded.", form)

func refresh_replacement_suggestions(query: String):
	hunter.catalog.refresh_runtime()
	replacement_suggestions.clear()
	for entry in hunter.catalog.suggestions(query):
		if entry.name.to_lower() in hunter.config.get("replacement_names", []): continue
		var index = replacement_suggestions.add_item(entry.name)
		replacement_suggestions.set_item_metadata(index, entry.name.to_lower())
	replacement_suggestions.visible = query.strip_edges().length() >= 3
	if replacement_suggestions.visible and replacement_suggestions.item_count == 0:
		replacement_suggestions.add_item("No additional matching Miscrit")
		replacement_suggestions.set_item_disabled(0, true)

func save_replacement_names(names: Array):
	var candidate = current_values()
	candidate.replacement_names = names
	var error = hunter.live_config(candidate)
	result(error)
	if error.is_empty():
		replacement_query.clear()
		refresh_replacement_suggestions("")
	refresh_replacements()

func toggle_selected_training(value: bool):
	if syncing: return
	var candidate = current_values()
	candidate.train_selected = value
	if value:
		candidate.min_rating = 17
		candidate.auto_search = true
		candidate.cross_area_search = false
		candidate.object_id = []
		candidate.mode = "capture_targeted"
	result(hunter.live_config(candidate))
	sync_fields()

func add_tier(tier: String, mapped: bool):
	if Server.Player == null:
		result("Sign in to load your collection before adding tier targets.")
		return
	hunter.catalog.refresh_runtime()
	var names = hunter.config.get("replacement_names", []).duplicate()
	var targets = hunter.config.get("miscrits", []).duplicate()
	var tier_entries = hunter.catalog.entries.filter(func(entry): return entry.get("rarity", "") == tier)
	var report = hunter.rotation.training_report(Server.Player, tier_entries.map(func(entry): return entry.name.to_lower()))
	var rows = {}
	for row in report.rows: rows[row.name] = row
	for entry in tier_entries:
		var name = entry.name.to_lower()
		var row = rows[name]
		if row.state == "Complete": continue
		if mapped:
			if hunter.catalog.search_stops(entry).is_empty() or row.rating >= 17: continue
			if name not in targets: targets.append(name)
		elif row.rating < 17: continue
		if name not in names: names.append(name)
	var candidate = current_values()
	candidate.replacement_names = names
	candidate.capture_id = targets
	if mapped:
		candidate.mode = "capture_targeted"
		candidate.auto_search = true
		candidate.cross_area_search = false
		candidate.object_id = []
	result(hunter.live_config(candidate))
	sync_fields()

func clear_tier(tier: String):
	var names = hunter.config.get("replacement_names", []).filter(func(name): return hunter.catalog.by_name.get(name, {}).get("rarity", "") != tier)
	save_replacement_names(names)

func import_tier_targets():
	if Server.Player == null:
		result("Sign in to check which selected species still need a 17+ copy.")
		return
	var names = hunter.config.get("miscrits", []).duplicate()
	for name in hunter.rotation.training_report(Server.Player, hunter.config.get("replacement_names", [])).needs_capture:
		if not hunter.catalog.search_stops(hunter.catalog.by_name[name]).is_empty() and name not in names: names.append(name)
	save_name_targets(names)

func move_target(offset: int):
	var selected = selected_targets.get_selected()
	if selected == null: return
	var name = str(selected.get_metadata(0))
	var names = hunter.config.get("miscrits", []).duplicate()
	var index = names.find(name)
	if index < 0: return
	names.remove_at(index)
	names.insert(clampi(index + offset, 0, names.size()), name)
	save_name_targets(names)

func add_replacement_name(index: int):
	var name = replacement_suggestions.get_item_metadata(index)
	if not name is String: return
	var names = hunter.config.get("replacement_names", []).duplicate()
	if name not in names: names.append(name)
	save_replacement_names(names)

func remove_replacement_name():
	var selected = replacement_list.get_selected()
	if selected == null: return
	var names = hunter.config.get("replacement_names", []).duplicate()
	names.erase(selected.get_metadata(0))
	save_replacement_names(names)

func refresh_replacements():
	if replacement_toggle == null: return
	train_selected_toggle.set_pressed_no_signal(hunter.config.get("train_selected", false))
	var report = hunter.rotation.training_report(Server.Player, hunter.config.get("replacement_names", []))
	var training_rows = {}
	for row in report.rows: training_rows[row.name] = row
	var owned_summary = {}
	if not hunter.config.get("train_selected", false) and Server.Player != null:
		for item in hunter.rotation.candidates(Server.Player, hunter.config.get("replacement_names", [])):
			var family = Server.Player.miscrits[item.id].mId
			if not owned_summary.has(family): owned_summary[family] = {"count":0, "rating":item.rating}
			owned_summary[family].count += 1
	for tier in tier_views:
		var view = tier_views[tier]
		var rows = report.rows.filter(func(row): return hunter.catalog.by_name[row.name].get("rarity", "") == tier)
		var ready = rows.filter(func(row): return row.state == "Ready").size()
		var complete = rows.filter(func(row): return row.state == "Complete").size()
		view.heading.text = "%s - %d listed / %d ready / %d complete" % [tier, rows.size(), ready, complete]
		view.owned.disabled = Server.Player == null
		view.mapped.disabled = Server.Player == null
		var lines = PackedStringArray()
		for row in rows: lines.append(hunter.catalog.by_name[row.name].name + " - " + row.state + (" (owned fallback)" if row.source == "owned_fallback" else ""))
		view.detail.text = "No species selected in this tier." if lines.is_empty() else "\n".join(lines)
	replacement_toggle.set_pressed_no_signal(hunter.config.get("auto_replace_max_level", false))
	var selected_name = "" if replacement_list.get_selected() == null else str(replacement_list.get_selected().get_metadata(0))
	replacement_list.clear()
	var root = replacement_list.create_item()
	for name in hunter.config.get("replacement_names", []):
		var row = replacement_list.create_item(root)
		row.set_text(0, hunter.catalog.by_name.get(name, {}).get("name", name))
		row.set_metadata(0, name)
		var summary = owned_summary.get(int(hunter.catalog.by_name.get(name, {}).get("id", -1)), {})
		var text = "Log in to check inventory" if Server.Player == null else ("None below level 35" if summary.is_empty() else str(summary.count) + " available · best " + str(summary.rating))
		if hunter.config.get("train_selected", false):
			var item = training_rows.get(name, {})
			if not item.is_empty(): text = item.state + (" · rating %s / lv %d" % [str(item.rating), item.level] if item.id > 0 else "")
		row.set_text(1, text)
		row.set_tooltip_text(1, text)
		if name == selected_name: row.select(0)
	replacement_remove.disabled = replacement_list.get_selected() == null
	replacement_status.text = str(hunter.config.get("replacement_names", []).size()) + " selected name(s)\n" + hunter.rotation.status
	replacement_status.tooltip_text = replacement_status.text

func build_campaign():
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	control_pages[2].add_child(scroll)
	var form = VBoxContainer.new()
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	form.add_theme_constant_override("separation", 10)
	scroll.add_child(form)
	label("Auto Clear Campaign", form).add_theme_font_size_override("font_size", 18)
	campaign_progress = note("", form)
	campaign_progress.max_lines_visible = 3
	campaign_progress.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	campaign_toggle = switch("Use campaign instead of target search", form, func(value):
		apply_immediate("campaign_enabled", value)
		campaign_toggle.set_pressed_no_signal(hunter.config.get("campaign_enabled", false)))
	campaign_toggle.add_theme_font_size_override("font_size", 14)
	var limits = HBoxContainer.new()
	limits.add_theme_constant_override("separation", 8)
	form.add_child(limits)
	label("Victory limit", limits).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	campaign_limit = SpinBox.new()
	campaign_limit.min_value = 1
	campaign_limit.max_value = Constants.CAMPAIGN_LAST_LEVEL
	campaign_limit.step = 1
	campaign_limit.value = 10
	campaign_limit.custom_minimum_size.y = 38
	campaign_limit.custom_minimum_size.x = 90
	limits.add_child(campaign_limit)
	button("Save", limits, save_campaign_limit)
	campaign_limit.get_line_edit().text_submitted.connect(func(_text): save_campaign_limit())
	note("Heals with 10 virtue before the next stage when 2 or more teammates have fainted. Pauses if virtue is insufficient or healing fails. Stops on defeat, daily attempts, locked stages, or errors. No paid attempt refills.", form)

func save_campaign_limit():
	var text = campaign_limit.get_line_edit().text.strip_edges()
	if not text.is_valid_int():
		result("Stage limit must be a whole number.")
		return
	apply_immediate("campaign_stage_limit", text.to_int())
	campaign_limit.value = hunter.config.get("campaign_stage_limit", 10)
	campaign_limit.get_line_edit().text = str(int(campaign_limit.value))

func refresh_campaign():
	if campaign_toggle == null: return
	campaign_toggle.set_pressed_no_signal(hunter.config.get("campaign_enabled", false))
	var runner = hunter.campaign
	var stage = str(int(runner.info.last_completed) + 1) if runner.info.has("last_completed") else "—"
	campaign_progress.text = "Stage: " + stage + " · " + str(runner.wins) + " / " + str(hunter.config.get("campaign_stage_limit", 10)) + " victories\n" + runner.status
	campaign_progress.tooltip_text = campaign_progress.text

func refresh_mode_details():
	var current = hunter.config.get("combat_mode", "capture_targeted")
	var selected = maxi(0, MODES.find(current))
	mode.tooltip_text = mode.get_item_text(selected)
	mode_help.text = [
		"Automatically fight every encounter.",
		"Attempt to capture any species that meets your minimum rating.",
		"Capture your selected species at or above the minimum rating.",
		"Selected species use Capture rating; other species use the second minimum.",
		"Pause as soon as a selected species appears, at any rating. Finish the battle and close its summary yourself, then press Start or F8."
	][selected]
	var uses_rating = current in ["capture_any", "capture_targeted", "capture_rated"]
	rating_fields.visible = uses_rating
	apply_ratings.visible = uses_rating
	other_rating_field.visible = current == "capture_rated"
	flee_others.disabled = current in ["fight", "capture_any"]
	if flee_others.disabled:
		flee_others.tooltip_text = "Choose a selected-species mode to run from unwanted encounters."
	else:
		flee_others.tooltip_text = "Flee at the first legal turn if the whole encounter fails your target and rating rules. The battle may appear briefly."
func refresh_platinum_slots():
	for index in range(platinum_slots.size()):
		var slot = platinum_slots[index]
		var m = null
		if Server.Player != null and index < Server.Player.team.size():
			m = Server.Player.miscrits.get(Server.Player.team[index])
		slot.disabled = m == null
		slot.set_meta("miscrit_id", "" if m == null else str(m.id))
		slot.text = str(index + 1) + ". Empty slot" if m == null else str(index + 1) + ". " + m.get_name() + "\nLevel " + str(m.level)
		slot.set_pressed_no_signal(m != null and str(m.id) in hunter.config.get("platinum_miscrit_ids", []))

func toggle_platinum_slot(index: int, value: bool):
	if syncing: return
	var id = platinum_slots[index].get_meta("miscrit_id", "")
	# A click on an old display must never authorize its replacement.
	if Server.Player == null or id.is_empty() or index >= Server.Player.team.size() or str(Server.Player.team[index]) != id:
		refresh_platinum_slots()
		return
	var selected = hunter.config.get("platinum_miscrit_ids", []).duplicate()
	if value and id not in selected: selected.append(id)
	if not value: selected.erase(id)
	apply_immediate("platinum_miscrit_ids", selected)
	refresh_platinum_slots()

func refresh_suggestions(query: String):
	if name_suggestions == null: return
	hunter.catalog.refresh_runtime()
	name_suggestions.clear()
	for entry in hunter.catalog.suggestions(query):
		if entry.name.to_lower() in hunter.config.get("miscrits", []): continue
		var index = name_suggestions.add_item(entry.name + " · " + entry.rarity)
		name_suggestions.set_item_metadata(index, entry.name)
	name_suggestions.visible = query.strip_edges().length() >= 3
	if name_suggestions.visible and name_suggestions.item_count == 0:
		name_suggestions.add_item("No additional matching Miscrit")
		name_suggestions.set_item_disabled(0, true)

func save_name_targets(names: Array):
	var candidate = current_values()
	candidate.capture_id = names
	var current_mode = hunter.config.get("combat_mode")
	candidate.mode = current_mode if current_mode in ["capture_rated", "manual_target"] else "capture_targeted"
	candidate.auto_search = true
	candidate.cross_area_search = false
	candidate.object_id = []
	var error = hunter.live_config(candidate)
	result(error)
	if error.is_empty():
		sync_fields()
		name_query.clear()
		refresh_suggestions("")

func add_name_target(index: int):
	var name = name_suggestions.get_item_metadata(index)
	if not name is String: return
	var names = hunter.config.get("miscrits", []).duplicate()
	if not name.to_lower() in names: names.append(name.to_lower())
	save_name_targets(names)

func remove_name_target():
	var selected = selected_targets.get_selected()
	if selected == null: return
	var names = hunter.config.get("miscrits", []).duplicate()
	names.erase(selected.get_metadata(0))
	save_name_targets(names)

func refresh_name_targets():
	if selected_targets == null: return
	var selected_name = ""
	if selected_targets.get_selected() != null: selected_name = str(selected_targets.get_selected().get_metadata(0))
	selected_targets.clear()
	var root = selected_targets.create_item()
	var planned = hunter.name_plan()
	for name in hunter.config.get("miscrits", []):
		var entry = hunter.catalog.by_name.get(name, {})
		var row = selected_targets.create_item(root)
		row.set_text(0, entry.get("name", name))
		row.set_metadata(0, name)
		var message = planned.statuses.get(name, "Waiting for catalog")
		if Server.Player == null and message.begins_with("Locked"): message = "Log in to check access"
		row.set_text(1, message)
		row.set_tooltip_text(1, message)
		row.set_custom_color(1, Color("efc781") if message.begins_with("Locked") or message.contains("No ") else MUTED)
		if name == selected_name: row.select(0)
	remove_target.disabled = selected_targets.get_selected() == null
	target_status.text = str(hunter.config.get("miscrits", []).size()) + " target(s) · " + str(planned.stops.size()) + " search stop(s) ready"
	var upgrades = hunter.hunt_names().filter(func(name): return name not in hunter.config.get("miscrits", []))
	if not upgrades.is_empty(): target_status.text += "\nTraining upgrades (17+): " + ", ".join(upgrades)
	if hunter.config.get("miscrits", []).is_empty():
		if upgrades.is_empty(): target_status.text = "No targets yet. Find your first Miscrit above."
	if hunter.training_farm(): target_status.text = "All selected upgrades owned. Fighting mapped encounters for trainee XP."
	if not hunter.capture_audit.error.is_empty(): target_status.text += "\n" + hunter.capture_audit.error
	target_status.tooltip_text = "Area scan checks the listed area's searchable objects. The exact spawn object is not confirmed."

func apply_fields():
	var text = rating.get_line_edit().text.strip_edges()
	if not text.is_valid_float():
		result("Minimum rating must be a number from 0 to 18.")
		return
	var candidate = current_values()
	candidate.min_rating = text.to_float()
	var other_text = other_rating.get_line_edit().text.strip_edges()
	if not other_text.is_valid_float():
		result("Other species minimum rating must be a number from 0 to 18.")
		return
	candidate.other_min_rating = other_text.to_float()
	result(hunter.live_config(candidate))

func build_captures():
	var page = tab("Captures")
	note("CAPTURE HISTORY", page)
	label("Minimum rating", page)
	history_min = number(page, 0)
	history_min.value_changed.connect(func(_value): refresh_history())
	history_count = note("", page)
	history_list = table(page, ["Miscrit", "Rating", "Captured (local)"])
	history_list.set_column_expand(1, false)
	history_list.set_column_custom_minimum_width(1, 48)
	note("Successful captures only. Newest first. Hover a row for details.", page)

func build_battles():
	var page = tab("Battles")
	note("BATTLE HISTORY", page)
	label("Minimum opponent rating", page)
	battle_min = number(page, 0)
	battle_min.value_changed.connect(func(_value): refresh_battles())
	battle_count = note("", page)
	battle_list = table(page, ["Opponent", "Rating", "Result", "Started (local)"])
	battle_list.set_column_expand(1, false)
	battle_list.set_column_custom_minimum_width(1, 48)
	note("One row per opponent. Filters here do not change automation.", page)

func sync_fields():
	super.sync_fields()
	refresh_replacements()
	if campaign_limit != null:
		campaign_limit.value = hunter.config.get("campaign_stage_limit", 10)
		campaign_limit.get_line_edit().text = str(int(campaign_limit.value))
	refresh_campaign()
	if flee_others != null: flee_others.set_pressed_no_signal(hunter.config.get("flee_non_targets", false))
	if low_rating_toggle != null: low_rating_toggle.set_pressed_no_signal(hunter.config.get("capture_low_rating_targets", false))
	if remove_kept_toggle != null: remove_kept_toggle.set_pressed_no_signal(hunter.config.get("auto_remove_captured_targets", false))
	if capture_chance_field != null: capture_chance_field.value = hunter.config.get("capture_threshold", 70)
	if max_attacks_field != null: max_attacks_field.value = hunter.config.get("max_attacks", 40)
	if other_rating != null: other_rating.value = hunter.config.get("other_min_rating", 16.0)
	refresh_mode_details()
	refresh_platinum_slots()
	refresh_name_targets()
	sync_route()
	if platinum != null:
		syncing = true
		platinum.button_pressed = hunter.config.get("platinum_upgrade", false)
		syncing = false
	if visuals != null:
		syncing = true
		visuals.button_pressed = not hunter.config.get("skip_skill_animations", true)
		syncing = false

func apply_immediate(key: String, value):
	if syncing: return
	super.apply_immediate(key, value)
	if low_rating_toggle != null: low_rating_toggle.set_pressed_no_signal(hunter.config.get("capture_low_rating_targets", false))
	if remove_kept_toggle != null: remove_kept_toggle.set_pressed_no_signal(hunter.config.get("auto_remove_captured_targets", false))
	refresh_replacements()
	refresh_campaign()
	refresh_mode_details()
	refresh_platinum_slots()
	sync_route()
	if platinum != null:
		syncing = true
		platinum.button_pressed = hunter.config.get("platinum_upgrade", false)
		syncing = false
	if visuals != null:
		syncing = true
		visuals.button_pressed = not hunter.config.get("skip_skill_animations", true)
		syncing = false

func fill_rows(tree: Tree, rows: Array, fields: Array):
	tree.clear()
	var root = tree.create_item()
	for i in range(rows.size() - 1, maxi(-1, rows.size() - 501), -1):
		var entry = rows[i]
		var row = tree.create_item(root)
		row.set_metadata(0, entry)
		var detail = JSON.stringify(entry, "  ")
		for column in range(fields.size()):
			var value = entry.get(fields[column])
			row.set_text(column, str(value) if value != null else "Unknown")
			row.set_tooltip_text(column, detail)

func count_text(shown: int, total: int, kind: String) -> String:
	var text = "%d of %d %s" % [shown, total, kind]
	if shown == 0: text += " - No matching records yet"
	if shown > 500: text += " - Newest 500 shown"
	return text

func refresh_battles():
	if battle_list == null: return
	var rows = hunter.journal.filtered_battles(battle_min.value)
	fill_rows(battle_list, rows, ["name", "rating", "outcome", "time"])
	battle_count.text = count_text(rows.size(), hunter.journal.battles.size(), "opponents")
	if not hunter.journal.error.is_empty(): battle_count.text = hunter.journal.error

func refresh_objects():
	if object_list == null: return
	var selected_key = ""
	if object_list.get_selected() != null: selected_key = object_list.get_selected().get_metadata(0).key
	fill_rows(object_list, hunter.journal.objects, ["object_id", "area", "time"])
	object_count.text = str(hunter.journal.objects.size()) + " recorded searches"
	object_latest.text = "Finder ON - search an object to reveal its ID." if hunter.find_objects else "Finder OFF - no new searches are recorded."
	if not hunter.journal.objects.is_empty():
		var latest = hunter.journal.objects.back()
		object_latest.text += "\nLast found: %s in %s" % [str(latest.object_id), latest.area]
	var row = object_list.get_root().get_first_child()
	var first = row
	while row != null:
		if row.get_metadata(0).key == selected_key:
			row.select(0)
			first = null
		row = row.get_next()
	if first != null: first.select(0)
	if not hunter.journal.error.is_empty(): object_count.text = hunter.journal.error

func selected_object():
	var row = object_list.get_selected()
	if row == null:
		result("Select an object from history first.")
		return null
	return row.get_metadata(0)

func sync_route():
	if route_toggle == null: return
	syncing = true
	route_toggle.button_pressed = hunter.config.get("cross_area_search", false)
	syncing = false
	var lines = PackedStringArray()
	for item in hunter.config.get("search_route", []):
		lines.append("%s / #%d" % [item.area, int(item.object_id)])
	route_summary.text = "Route: " + ("No stops recorded" if lines.is_empty() else " -> ".join(lines))
	route_summary.tooltip_text = route_summary.text

func add_route_object():
	var entry = selected_object()
	if entry == null: return
	if not entry.has("route"):
		result("This old record has no route position. Turn on Find object IDs and search it again.")
		return
	var candidate = current_values()
	var stops = candidate.get("search_route", []).duplicate(true)
	var key = hunter.route_key(entry.route)
	for item in stops:
		if hunter.route_key(item) == key:
			result("This stop is already in the route.")
			return
	stops.append(entry.route.duplicate(true))
	candidate.search_route = stops
	result(hunter.live_config(candidate))
	sync_route()

func clear_route():
	var candidate = current_values()
	candidate.search_route = []
	candidate.cross_area_search = false
	result(hunter.live_config(candidate))
	sync_route()

func copy_object():
	var entry = selected_object()
	if entry == null: return
	DisplayServer.clipboard_set(str(int(entry.object_id)))
	feedback.text = "Copied object ID " + str(int(entry.object_id)) + "."

func add_object():
	var entry = selected_object()
	if entry == null: return
	var id = str(int(entry.object_id))
	var draft = PackedStringArray()
	for token in ids.text.split(",", false): draft.append(token.strip_edges())
	if id not in draft: draft.append(id)
	ids.text = ", ".join(draft)
	tabs.current_tab = 0
	feedback.text = "Added ID %s from %s. Press Apply to save." % [id, entry.area]

func layout_path() -> String:
	return hunter.config_path().get_base_dir().path_join("test-panel-layout.cfg" if OS.get_cmdline_user_args().has("--mama-test") else "panel-layout.cfg")

func save_layout():
	var settings = ConfigFile.new()
	settings.set_value("panel", "size", expanded_size)
	settings.set_value("panel", "position", panel.position)
	if settings.save(layout_path()) != OK: feedback.text = "Panel layout could not be saved."

func load_layout():
	var settings = ConfigFile.new()
	if settings.load(layout_path()) == OK:
		var size = settings.get_value("panel", "size", expanded_size)
		var position = settings.get_value("panel", "position", panel.position)
		if size is Vector2 and size.is_finite(): expanded_size = size
		if position is Vector2 and position.is_finite(): panel.position = position
	set_panel_size(expanded_size)

func set_panel_size(value: Vector2):
	var viewport = get_viewport().get_visible_rect().size
	var minimum = panel.get_combined_minimum_size().max(Vector2(440, 400))
	expanded_size = value.clamp(minimum, viewport.max(minimum))
	if body.visible: panel.size = expanded_size
	clamp_panel()

func toggle_collapsed():
	if panel.visible:
		expanded_size = panel.size
		orb.position = panel.position
		panel.hide()
		orb.show()
	else:
		orb.hide()
		panel.show()
		panel.size = expanded_size
	clamp_panel.call_deferred()

func resize_handle(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		resizing = event.pressed
		resize_origin = panel.get_global_mouse_position()
		resize_size = panel.size

func _input(event):
	if event is InputEventMouseMotion:
		if dragging:
			panel.position = panel.get_global_mouse_position() - drag_offset
			clamp_panel()
			get_viewport().set_input_as_handled()
		elif resizing:
			set_panel_size(resize_size + panel.get_global_mouse_position() - resize_origin)
			get_viewport().set_input_as_handled()
	if event is InputEventMouseButton and not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if dragging or resizing: save_layout()
		dragging = false
		resizing = false

func clamp_panel():
	var viewport = get_viewport().get_visible_rect().size
	if orb != null: orb.position = orb.position.clamp(Vector2.ZERO, (viewport - orb.size).max(Vector2.ZERO))
	if body.visible: panel.size = expanded_size.min(viewport).max(panel.get_combined_minimum_size())
	panel.position = panel.position.clamp(Vector2.ZERO, (viewport - panel.size).max(Vector2.ZERO))

func _process(delta):
	super._process(delta)
	if panel.visible and (panel.size.x > get_viewport().get_visible_rect().size.x or panel.size.y > get_viewport().get_visible_rect().size.y): clamp_panel()
	badge.text = "RUNNING" if hunter.enabled else "PAUSED"
	badge.add_theme_color_override("font_color", ACCENT if hunter.enabled else Color("efc781"))
	target_refresh += delta
	if target_refresh >= 1.0:
		target_refresh = 0.0
		# Hidden tabs and a minimized panel do not rebuild catalogs or roster trees.
		if not panel.visible: return
		if tabs.current_tab == 0:
			if control_pages[0].visible: refresh_name_targets()
			elif control_pages[2].visible: refresh_campaign()
		elif tabs.current_tab == 1:
			if team_tabs.current_tab == 1: refresh_platinum_slots()
			else: refresh_replacements()
