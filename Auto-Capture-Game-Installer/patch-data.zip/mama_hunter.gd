extends "res://dynamic_search_base.gd"

var policy = preload("res://capture_policy.gd").new()
var history = {"attacks": 0, "flee": false, "damage": {}}
var inflight = ""
var capture_attempted = false
var capture_succeeded = false
var keep_sent = false
var latest_chance = null
var next_turn = ""
var pending = true
var summary_ref: WeakRef
var training = false
var healing = false
var heal_retry_at = 0
var active_foe_id = -1
var notice_refs: Array = []
var panel
var encounter_data: Array = []
var captures: Array = []
var captured_matches = {}
var history_error = ""
var needs_rearm = false
var journal = preload("res://activity_history.gd").new()
var find_objects = false
var battle_objects = {}
var route_cursor = 0
var route_target = ""
var route_deadline = 0
var route_scene_ref: WeakRef
var catalog = preload("res://capture_catalog.gd").new()
var name_stops: Array = []
var name_statuses: Dictionary = {}
var name_cursor = 0
var name_active: Dictionary = {}
var name_cooldowns: Dictionary = {}
var name_traveling = false
var name_move_key = ""
var name_move_attempts = 0
var name_skipped_stops: Dictionary = {}
var name_wait_key = ""
var name_day = -1
var name_travel_deadline = 0
var mapping_pending: Dictionary = {}
var mapping_matches: Dictionary = {}
var manual_battle_id = ""
var campaign = preload("res://campaign_runner.gd").new()
var rotation = preload("res://team_rotation.gd").new()
var capture_audit = preload("res://capture_diagnostics.gd").new()
var kept_target_name = ""
var hunt_plan_key = ""

func hunt_names() -> Array:
	var names = config.get("miscrits", []).duplicate()
	if config.get("train_selected", false) and Server.Player != null:
		var report = rotation.training_report(Server.Player, config.get("replacement_names", []))
		# Train the owned tier candidates first instead of waiting for a missing upgrade.
		if report.eligible.is_empty():
			for name in report.needs_capture:
				if name not in names: names.append(name)
	return names

func selected_species(foe: Dictionary) -> bool:
	var names = hunt_names()
	if str(foe.get("name", "")).strip_edges().to_lower() in names: return true
	var family = int(foe.get("mId", -1))
	return names.any(func(name): return int(catalog.by_name.get(name, {}).get("id", -2)) == family)

func training_farm() -> bool:
	return config.get("train_selected", false) and Server.Player != null and hunt_names().is_empty() and not rotation.training_report(Server.Player, config.get("replacement_names", [])).eligible.is_empty()

func search_names() -> Array:
	var names = hunt_names()
	# Once all upgrades are owned, continue earning XP on trainees' mapped routes.
	# These route names are not capture targets, so already-owned families are fought.
	if names.is_empty() and config.get("train_selected", false) and Server.Player != null:
		for row in rotation.training_report(Server.Player, config.get("replacement_names", [])).eligible:
			names.append(row.name)
	return names

func confirm_kept_target() -> String:
	var name = kept_target_name
	kept_target_name = ""
	if name.is_empty() or not config.get("auto_remove_captured_targets", false) or name not in config.get("miscrits", []): return ""
	var candidate = config.duplicate(true)
	candidate.miscrits.erase(name)
	# Canonical format avoids an old capture_id alias restoring a removed name.
	candidate.mode = "multiple"
	candidate.capture_id = candidate.miscrits.duplicate()
	var temp = config_path() + ".tmp"
	var file = FileAccess.open(temp, FileAccess.WRITE)
	if file == null: return "Capture kept, but target removal could not be saved."
	file.store_string(JSON.stringify(candidate, "  ") + "\n")
	file.flush()
	var error = file.get_error()
	file.close()
	if error != OK or DirAccess.rename_absolute(temp, config_path()) != OK: return "Capture kept, but target removal could not be saved."
	config = candidate
	# Replan after returning to the world; leave current battle bookkeeping intact.
	name_stops.clear()
	hunt_plan_key = ""
	announce("target_removed", "Kept capture removed from hunt list. Selected training upgrades stay queued until 17+.")
	if is_instance_valid(panel): panel.sync_fields()
	return ""

func reset_name_search():
	name_stops.clear()
	name_statuses.clear()
	name_cursor = 0
	name_active = {}
	name_move_key = ""
	name_move_attempts = 0
	name_skipped_stops.clear()
	name_wait_key = ""
	name_day = -1

func name_plan() -> Dictionary:
	catalog.refresh_runtime()
	var weekday = Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_system())).weekday
	var planned: Dictionary
	if Server.Player == null:
		planned = catalog.plan(search_names(), "", weekday, {}, {}, [])
	else:
		planned = catalog.plan(search_names(), Server.Player.location.name, weekday, Server.Player.boss_achievements, Server.Player.tickets, LocalData.one_time_events)
	var skipped_targets = {}
	for item in planned.stops:
		if name_skipped_stops.has(route_key(item)):
			for target in item.targets: skipped_targets[target] = true
	planned.stops = planned.stops.filter(func(item): return not name_skipped_stops.has(route_key(item)))
	for target in skipped_targets:
		if not planned.stops.any(func(item): return target in item.targets):
			planned.statuses[target] = "No reachable search object; Start/F8 to retry"
	return planned

func route_key(stop_data: Dictionary) -> String:
	return "%s:%d:%s:%d" % [stop_data.location, int(stop_data.area_id), stop_data.container, int(stop_data.object_id)]

func route_error(stops) -> String:
	if not stops is Array: return "Search route must be a list."
	var seen = {}
	var location = ""
	for item in stops:
		if not item is Dictionary: return "Invalid route stop."
		for key in ["location", "container", "object_name", "area"]:
			if not item.get(key) is String or item[key].is_empty(): return "Route stop is missing " + key + "."
		if item.container.begins_with("/") or ".." in item.container.split("/"): return "Route container must stay within the loaded map."
		if not location.is_empty() and location != item.location: return "Route stops must share one loaded map."
		location = item.location
		for key in ["area_id", "object_id"]:
			var value = item.get(key)
			if not (value is int or value is float) or not is_finite(float(value)) or value < 0 or value != floor(value): return "Invalid route " + key + "."
		for key in ["x", "y"]:
			var value = item.get(key)
			if not (value is int or value is float) or not is_finite(float(value)): return "Invalid recorded position."
		var key = route_key(item)
		if seen.has(key): return "The same route stop is listed twice."
		seen[key] = true
	return ""

func reset_route():
	route_cursor = 0
	route_target = ""
	route_scene_ref = null
	route_deadline = 0

func _ready():
	capture_audit.host = self
	campaign.host = self
	rotation.host = self
	super._ready()
	# Name-driven automation starts only after the user presses Start/F8.
	if config.get("auto_search", false) or config.get("campaign_enabled", false) or config.get("auto_replace_max_level", false):
		enabled = false
		announce("ready", "Campaign ready. Press Start / F8 to clear available stages." if config.get("campaign_enabled", false) else "Select Miscrits, then press Start automation.")
	load_captures()
	journal.directory = config_path().get_base_dir()
	journal.prefix = "test-" if OS.get_cmdline_user_args().has("--mama-test") else ""
	journal.load_history()
	panel = preload("res://capture_panel.gd").new()
	panel.hunter = self
	add_child(panel)
	status_label.hide()

func history_path() -> String:
	return config_path().get_base_dir().path_join("test-capture-history.jsonl" if OS.get_cmdline_user_args().has("--mama-test") else "capture-history.jsonl")

func load_captures():
	captures.clear()
	captured_matches.clear()
	if not FileAccess.file_exists(history_path()): return
	var file = FileAccess.open(history_path(), FileAccess.READ)
	if file == null:
		history_error = "Capture history could not be read."
		return
	while not file.eof_reached():
		var line = file.get_line().strip_edges()
		if line.is_empty(): continue
		var parser = JSON.new()
		if parser.parse(line) != OK: continue
		var entry = parser.data
		if entry is Dictionary and entry.get("key") is String and entry.get("name") is String and entry.get("time") is String:
			if not captured_matches.has(entry.key):
				captures.append(entry)
				captured_matches[entry.key] = true

func record_capture(data: Dictionary, before: Dictionary, after: Dictionary):
	var player_id = str(after.get("player", {}).get("user_id", ""))
	if data.get("captured") != true or player_id.is_empty() or data.get("user_id") != player_id or Server.spectator: return
	var battle_id = str(before.get("match_id", Server.current_battle_id))
	if battle_id.is_empty(): return
	var foe = before.get("foe", {})
	var key = player_id + ":" + battle_id + ":" + str(foe.get("id", "wild"))
	if captured_matches.has(key): return
	var details = foe.duplicate(true)
	if battle_id == match_id and encounter_data.size() == 1:
		for field in ["name", "rating"]:
			if encounter_data[0].has(field): details[field] = encounter_data[0][field]
	var entry = {"key": key, "name": str(details.get("name", "Unknown Miscrit")), "rating": details.get("rating"), "time": Time.get_datetime_string_from_system(false, true), "time_utc": Time.get_datetime_string_from_system(true), "unix": Time.get_unix_time_from_system()}
	captures.append(entry)
	captured_matches[key] = true
	var file = FileAccess.open(history_path(), FileAccess.READ_WRITE if FileAccess.file_exists(history_path()) else FileAccess.WRITE)
	if file == null:
		history_error = "Capture recorded in memory; history file could not be saved."
	else:
		file.seek_end()
		file.store_line(JSON.stringify(entry))
		file.flush()
		if file.get_error() != OK: history_error = "Capture history write failed."
	if is_instance_valid(panel): panel.refresh_history()

func filtered_captures(minimum: float) -> Array:
	return captures.filter(func(entry):
		var rating = entry.get("rating")
		return minimum == 0 or ((rating is float or rating is int) and is_finite(float(rating)) and rating >= minimum))

func live_config(value: Dictionary, persist: bool = true) -> String:
	var error = validate_config(value)
	if not error.is_empty(): return error
	var candidate = normalize_config(value)
	var changed_activity = candidate.campaign_enabled != config.get("campaign_enabled", false)
	var changed_rotation = candidate.auto_replace_max_level != config.get("auto_replace_max_level", false) or candidate.replacement_names != config.get("replacement_names", []) or candidate.train_selected != config.get("train_selected", false)
	if changed_rotation and rotation.busy: return "Wait for the pending team update before changing replacement settings."
	if changed_rotation and (training or name_traveling or pending_search): return "Finish the current training/search/battle/travel before changing team selection."
	# A manually closed wild summary can leave the paused search bookkeeping
	# behind. Clear it only after a known encounter has returned to an idle world;
	# an unanswered search or a battle that is still joining must remain pending.
	var finished_search = pending_search and encounter_checked and not match_id.is_empty() and str(Server.current_battle_id).is_empty() and not is_instance_valid(BattleAnimator.battle) and campaign_world_ready()
	if changed_activity and (enabled or (pending_search and not finished_search) or name_traveling or campaign.busy or campaign.uncertain or rotation.busy or rotation.uncertain or campaign.phase == "joining" or not str(Server.current_battle_id).is_empty() or is_instance_valid(BattleAnimator.battle)):
		return "Pause and finish the current search, battle, or request before changing campaign mode."
	var using_name_search = candidate.auto_search or config.get("auto_search", false)
	var changed_names = candidate.auto_search != config.get("auto_search", false) or candidate.miscrits != config.get("miscrits", [])
	if changed_names and using_name_search and (pending_search or name_traveling): return "Pause and finish the current search/battle/travel before changing targets."
	var changed_route = candidate.search_route != config.get("search_route", []) or candidate.cross_area_search != config.get("cross_area_search", false)
	if changed_route and pending_search: return "Finish the current search/battle before changing the route."
	var found = {}
	var changed_objects = candidate.object_ids != config.get("object_ids", [])
	if changed_objects and area_ref != null and not candidate.cross_area_search and not candidate.auto_search:
		var area = area_ref.get_ref()
		if not is_instance_valid(area) or not area.is_inside_tree(): return "Search area is no longer loaded; re-arm in the new area."
		for id in candidate.object_ids:
			if id >= area.get_child_count(): return "Object %d does not exist in this area." % id
			var object = area.get_child(int(id))
			if not object is Node2D or not object.has_method("can_search") or not object.has_method("check_user_entered"):
				return "Object %d is not searchable in this area." % id
			found[int(id)] = weakref(object)
	if persist:
		var temp = config_path() + ".tmp"
		var file = FileAccess.open(temp, FileAccess.WRITE)
		if file == null: return "Could not save settings; no changes applied."
		var saved_value = value.duplicate(true)
		for key in ["miscrits", "object_ids", "combat_mode", "target_mode"]:
			saved_value[key] = candidate[key]
		file.store_string(JSON.stringify(saved_value, "  ") + "\n")
		file.flush()
		var write_error = file.get_error()
		file.close()
		if write_error != OK or DirAccess.rename_absolute(temp, config_path()) != OK:
			return "Could not save settings; no changes applied."
	apply_config(value)
	if changed_rotation:
		rotation.next_scan = 0
		if not rotation.uncertain:
			rotation.status = "Watching slots 2–4 for level 35." if config.auto_replace_max_level and not config.replacement_names.is_empty() else "Choose replacement names, then enable automatic replacement."
	if changed_names and using_name_search:
		reset_name_search()
		area_ref = null
		objects.clear()
	if changed_route:
		reset_route()
		area_ref = null
		objects.clear()
	if changed_objects:
		cursor = 0
		if area_ref != null: objects = found
	if changed_activity:
		if finished_search:
			pending_search = false
			encounter_checked = false
			match_id = ""
			leaving = false
			reset_battle()
		campaign.reset()
		manual_battle_id = ""
	if not candidate.campaign_enabled and encounter_checked and not encounter_data.is_empty():
		var classification = classify_encounter(encounter_data)
		if classification == "unknown":
			stop("Updated target settings need valid encounter data; battle left open.")
		else:
			set_encounter_behavior(classification)
			if handoff_manual_target(encounter_data): return ""
	announce("settings", "Settings applied. Already submitted actions will finish.")
	return ""

func toggle_running():
	if rotation.uncertain:
		announce("team_wait", "Team update outcome is uncertain. Check your team and reopen the game before restarting.")
		return
	if rotation.busy:
		if enabled:
			enabled = false
			announce("paused", "Paused. The submitted team update may still finish.")
		else:
			announce("team_wait", "Waiting for the submitted team update; no duplicate request was sent.")
		return
	if config.get("campaign_enabled", false):
		campaign.toggle()
		return
	if manual_battle_open():
		announce("manual_wait", "Finish this battle manually, then press Start/F8 to continue searching.")
		return
	manual_battle_id = ""
	if enabled:
		enabled = false
		announce("paused", "Paused. Submitted actions may still finish.")
	elif name_traveling:
		announce("travel_wait", "Waiting for the submitted travel response before restarting.")
	elif config.is_empty() or needs_rearm:
		arm()
	else:
		enabled = true
		route_target = ""
		name_move_key = ""
		deadline = Time.get_ticks_msec() + 60000
		announce("resumed", "Planning selected Miscrits." if config.get("auto_search", false) else ("Resumed." if area_ref != null else "Search a configured object once to start."))

func stop(reason: String):
	enabled = false
	needs_rearm = true
	announce("stopped", reason + " [Start / F8 to re-arm]")

func _input(event):
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F8:
		toggle_running()
		get_viewport().set_input_as_handled()

func search_cooldown_msec() -> int:
	# Match WorldManager.setup_battle instead of adding a fixed 31-second wait
	# for players whose native cooldown-reduction trait already allows 21 seconds.
	return 21000 if Server.Player != null and Server.Player.left_traits.has(100) else 31000

func on_search_result(object_id: int, result: Dictionary):
	var managed_result = object_id == active_object_id and pending_search
	var data = result.get("data", {})
	if data is Dictionary and result.get("success", false) and data.has("matchId") and int(mapping_pending.get("object_id", -1)) == object_id:
		mapping_matches[str(data.matchId)] = mapping_pending.duplicate(true)
		while mapping_matches.size() > 64: mapping_matches.erase(mapping_matches.keys()[0])
	mapping_pending = {}
	if config.get("auto_search", false) and not name_active.is_empty() and data is Dictionary:
		if result.get("success", false) or data.get("cooldown", false) or data.get("drop", false):
			name_cooldowns[route_key(name_active)] = Time.get_ticks_msec() + search_cooldown_msec()
	if data is Dictionary and result.get("success", false) and data.has("matchId"):
		battle_objects[str(data.matchId)] = object_id
	var was_enabled = enabled
	enabled = true
	super.on_search_result(object_id, result)
	if managed_result and data is Dictionary and not result.get("success", false) and data.get("cooldown", false):
		cooldowns[object_id] = Time.get_ticks_msec() + search_cooldown_msec()
	enabled = enabled and was_enabled

func on_flee_result(success: bool):
	if not manual_battle_id.is_empty() and Server.current_battle_id == manual_battle_id: return
	var was_enabled = enabled
	enabled = true
	super.on_flee_result(success)
	enabled = enabled and was_enabled

func watch_notification(popup, kind: String):
	if kind in ["rank_up", "currency_reward", "quest", "daily_quest", "boss_defeated", "clan_accepted", "announcement", "notice"]:
		notice_refs.append(weakref(popup))

func dismiss_notifications():
	if not enabled: return
	var waiting = notice_refs
	notice_refs = []
	for ref in waiting:
		var popup = ref.get_ref()
		if is_instance_valid(popup) and not popup.is_queued_for_deletion():
			popup._on_exit_pressed()

func normalize_config(value: Dictionary) -> Dictionary:
	var c = value.duplicate(true)
	if c.get("mode") in ["fight", "capture_any", "capture_targeted", "capture_rated", "manual_target"]:
		c.combat_mode = c.mode
		c.mode = "multiple"
		c.object_ids = c.get("object_id", [])
		c.target_mode = "targeted" if c.combat_mode in ["capture_targeted", "manual_target"] else "any"
		var targets = c.get("capture_id", [])
		c.miscrits = [targets] if targets is String else targets
	var defaults = {"combat_mode": "capture_any", "auto_level_up": false, "platinum_upgrade": false, "platinum_miscrit_ids": [], "min_rating": 11.0, "other_min_rating": 16.0,
		"capture_threshold": 70, "ability_ids": [], "max_attacks": 40,
		"min_player_hp_percent": 1, "min_target_hp_percent": 1, "damage_margin": 1.5,
		"skip_skill_animations": true, "cross_area_search": false, "search_route": [], "auto_search": false, "flee_non_targets": false}
	defaults.campaign_enabled = false
	defaults.campaign_stage_limit = 10
	defaults.auto_replace_max_level = false
	defaults.replacement_names = []
	defaults.train_selected = false
	defaults.capture_low_rating_targets = false
	defaults.auto_remove_captured_targets = false
	if c.get("replacement_names", []) is Array:
		c.replacement_names = c.get("replacement_names", []).map(func(name): return name.strip_edges().to_lower() if name is String else name)
	for key in defaults:
		if not c.has(key): c[key] = defaults[key]
	if c.auto_level_up in ["on", "off"]:
		c.auto_level_up = c.auto_level_up == "on"
	if c.platinum_upgrade in ["on", "off"]:
		c.platinum_upgrade = c.platinum_upgrade == "on"
	# Retire paid levels even when an old config enabled them.
	c.erase("platinum_training")
	return c

func apply_config(value) -> String:
	if not value is Dictionary: return "Configuration must be a JSON object."
	return super.apply_config(normalize_config(value))

func config_path() -> String:
	return OS.get_executable_path().get_base_dir().get_base_dir().path_join("capture-config.json")

func validate_config(value) -> String:
	if not value is Dictionary:
		return "Capture configuration must be a JSON object."
	value = normalize_config(value)
	for key in ["train_selected", "capture_low_rating_targets", "auto_remove_captured_targets"]:
		if not value[key] is bool: return key + " must be true/false."
	if not value.auto_replace_max_level is bool: return "Automatic replacement must be true/false."
	if not value.replacement_names is Array: return "Replacement names must be a list."
	var selected_replacements = {}
	for name in value.replacement_names:
		if not name is String or name.is_empty() or selected_replacements.has(name): return "Replacement names must be nonempty, unique names."
		selected_replacements[name] = true
	if not value.campaign_enabled is bool: return "Auto Clear Campaign must be true/false."
	var stage_limit = value.campaign_stage_limit
	if not (stage_limit is int or stage_limit is float) or not is_finite(float(stage_limit)) or stage_limit < 1 or stage_limit > Constants.CAMPAIGN_LAST_LEVEL or stage_limit != floor(stage_limit):
		return "Campaign stage limit must be a whole number from 1 to %d." % Constants.CAMPAIGN_LAST_LEVEL
	if not value.flee_non_targets is bool: return "Run from unwanted encounters must be true/false."
	if not value.auto_search is bool: return "Auto search must be true/false."
	if value.auto_search and value.cross_area_search: return "Name search cannot use a manually recorded route."
	if not value.cross_area_search is bool: return "Cross-area search must be true/false."
	var route_validation = route_error(value.search_route)
	if not route_validation.is_empty(): return route_validation
	if value.cross_area_search and value.search_route.is_empty(): return "Record and add at least one route stop first."
	if value.get("combat_mode") not in ["fight", "capture_any", "capture_targeted", "capture_rated", "manual_target"]:
		return "Battle mode must be fight, capture_any, capture_targeted, capture_rated, or manual_target."
	if not value.auto_level_up is bool:
		return "auto_level_up must be on/off or true/false."
	if not value.platinum_upgrade is bool:
		return "platinum_upgrade must be on/off or true/false."
	if not value.platinum_miscrit_ids is Array:
		return "platinum_miscrit_ids must be an array of individual IDs."
	for id in value.platinum_miscrit_ids:
		if not id is String or not id.is_valid_int() or int(id) <= 0 or str(int(id)) != id:
			return "Platinum IDs must be positive integer strings."
	var other_rating = value.other_min_rating
	if not (other_rating is int or other_rating is float) or not is_finite(float(other_rating)) or other_rating < 0 or other_rating > 18:
		return "Other species minimum rating must be a number from 0 to 18."
	if value.get("target_mode") not in ["any", "targeted"]:
		return "target_mode must be any or targeted."
	if not value.get("miscrits") is Array:
		return "miscrits must be an array."
	var search_value = value.duplicate(true)
	if value.auto_search or value.campaign_enabled:
		# Object IDs are resolved at runtime, not supplied by the user.
		search_value.object_ids = [0]
		if value.miscrits.is_empty(): search_value.miscrits = ["*"]
	if value.target_mode == "any" and value.miscrits.is_empty():
		search_value.miscrits = ["*"]
	var error = super.validate_config(search_value)
	if not error.is_empty():
		return error
	for key in ["capture_threshold", "min_player_hp_percent", "min_target_hp_percent"]:
		var number = value.get(key)
		if not (number is int or number is float) or not is_finite(float(number)) or number <= 0 or number > 100:
			return key + " must be above 0 and at most 100."
	var attacks = value.get("max_attacks")
	if not (attacks is int or attacks is float) or not is_finite(float(attacks)) or attacks < 1 or attacks > 100 or attacks != floor(attacks):
		return "max_attacks must be a whole number from 1 to 100."
	var margin = value.get("damage_margin")
	if not (margin is int or margin is float) or not is_finite(float(margin)) or margin < 1 or margin > 10:
		return "damage_margin must be from 1 to 10."
	if not value.get("ability_ids") is Array or not value.get("skip_skill_animations") is bool:
		return "ability_ids must be an array and skip_skill_animations must be true/false."
	for id in value.ability_ids:
		if not (id is int or id is float) or not is_finite(float(id)) or id <= 0 or id != floor(id) or id > 2147483647:
			return "ability_ids must contain positive whole numbers."
	return ""

func reset_battle():
	kept_target_name = ""
	active_foe_id = -1
	encounter_data = []
	history = {"attacks": 0, "flee": false, "damage": {}}
	inflight = ""
	capture_attempted = false
	capture_succeeded = false
	keep_sent = false
	latest_chance = null
	next_turn = ""
	pending = true
	summary_ref = null

func next_available_object(now: int):
	# Capture mode preserves the listed order, including when the next object is cooling down.
	var id = config.object_ids[cursor]
	var object = objects[id].get_ref()
	if not is_instance_valid(object) or not object.is_inside_tree() or object.get_parent() != area_ref.get_ref() or object.get_index() != id:
		stop("A configured object changed; rebind this area.")
		return null
	if object.is_visible_in_tree() and object.can_search() and now >= cooldowns.get(id, 0):
		return object
	return null

func arm():
	needs_rearm = false
	reset_route()
	reset_name_search()
	reset_battle()
	super.arm()
	if enabled and config.get("campaign_enabled", false):
		enabled = false
		announce("ready", "Campaign ready. Press Start / F8 to begin.")
	elif enabled and config.get("auto_search", false): announce("armed", "Planning selected Miscrits; no manual object search is needed.")
	if is_instance_valid(panel): panel.sync_fields()

func announce(event: String, message: String, extra: Dictionary = {}):
	var details = {"message": message, "object_id": active_object_id, "match_id": match_id}
	if OS.get_cmdline_user_args().has("--mama-test") or OS.get_cmdline_user_args().has("--study-log"): details.config = config
	details.merge(extra, true)
	if is_instance_valid(status_label):
		var selection = "%d selected Miscrit(s)" % config.get("miscrits", []).size() if config.get("auto_search", false) else "Objects " + str(config.get("object_ids", []))
		status_label.text = "%s | %s\n%s" % [str(config.get("combat_mode", "Auto capture")).replace("_", " ").capitalize(), selection, message]
		if config.get("campaign_enabled", false): status_label.text = "Campaign | %d win(s) this run\n%s" % [campaign.wins, message]
	Server._study_response_log("capture_hunt_" + event, details)

func on_search_request(object_id: int):
	if config.get("campaign_enabled", false): return
	mapping_pending = mapping_context(object_id)
	record_found_object(object_id)
	if enabled and config.get("auto_search", false):
		return on_name_search(object_id)
	if enabled and config.get("cross_area_search", false):
		on_route_search(object_id)
		return
	if enabled and object_id in config.object_ids:
		reset_battle()
	super.on_search_request(object_id)

func mapping_context(object_id: int) -> Dictionary:
	if not is_instance_valid(WorldManager.player) or not is_instance_valid(WorldManager.location_node) or Server.Player == null: return {}
	if Server.active_rpcs.has("update_location") or WorldManager.loading_lock: return {}
	var object = WorldManager.player.searching_object
	if not is_instance_valid(object) or not WorldManager.location_node.is_ancestor_of(object) or object.get_index() != object_id: return {}
	if not object.has_method("can_search") or not object.has_method("check_user_entered"): return {}
	return {"location": str(Server.Player.location.name), "area_id": Server.Player.area.id,
		"scene": WorldManager.location_node.scene_file_path.trim_prefix("res://"),
		"container": str(WorldManager.location_node.get_path_to(object.get_parent())),
		"object_id": object_id, "object_name": str(object.name), "object_scene": object.scene_file_path}

func record_found_object(object_id: int):
	if not find_objects: return
	var area = "Unknown area"
	var object_name = "Search object"
	if is_instance_valid(WorldManager.player):
		var object = WorldManager.player.searching_object
		if is_instance_valid(object):
			object_name = str(object.name)
			area = str(object.get_parent().get_path())
	if Server.Player != null and Server.Player.area != null:
		area = str(Server.Player.area.name)
		if Server.Player.location != null: area = str(Server.Player.location.name) + " / " + area
	var route = {}
	if is_instance_valid(WorldManager.player) and is_instance_valid(WorldManager.location_node) and Server.Player != null:
		var object = WorldManager.player.searching_object
		if is_instance_valid(object) and WorldManager.location_node.is_ancestor_of(object):
			route = {"location": str(Server.Player.location.name), "area_id": Server.Player.area.id,
				"container": str(WorldManager.location_node.get_path_to(object.get_parent())), "object_id": object_id,
				"object_name": str(object.name), "area": area,
				"x": WorldManager.player.global_position.x, "y": WorldManager.player.global_position.y}
	journal.record_object(object_id, area, object_name, route)
	if is_instance_valid(panel): panel.refresh_objects()

func on_battle_started(opponents: Array, kind: String, player_id: String):
	if Server.spectator: return
	var id = str(Server.current_battle_id)
	if campaign.owns(id): campaign.on_battle_started(kind, id)
	learn_wild_mapping(id, opponents, kind)
	journal.begin_battle(id, player_id, opponents, kind, int(battle_objects.get(id, -1)))
	if is_instance_valid(panel): panel.refresh_battles()

func learn_wild_mapping(id: String, opponents: Array, kind: String):
	var context = mapping_matches.get(id, {})
	mapping_matches.erase(id)
	if kind != "Wild" or context.is_empty(): return
	# Additional encounter slots can have different spawn rules; only the primary
	# wild opponent establishes this object's spawn mapping.
	for foe in opponents.slice(0, 1):
		if not foe is Dictionary or not (foe.get("mId") is int or foe.get("mId") is float): continue
		if not is_finite(float(foe.mId)) or foe.mId != floor(foe.mId): continue
		var species_id = int(foe.mId)
		if catalog.observe_wild(species_id, context, kind):
			var entry = catalog.by_id[species_id]
			if entry.name.to_lower() in config.get("miscrits", []): name_stops.clear()
			announce("mapped", "Mapped " + entry.name + " from a confirmed wild encounter.", {"species_id": species_id, "mapping": context})

func update_battle_history(data: Dictionary, opcode: int, before: Dictionary, after: Dictionary):
	if Server.spectator: return
	var id = str(before.get("match_id", Server.current_battle_id))
	var player_id = str(after.get("player", {}).get("user_id", ""))
	if opcode == BattleEnum.Opcode.CAPTURE and data.get("captured") == true and not player_id.is_empty() and data.get("user_id") == player_id:
		journal.update_battle(id, "Captured", before.get("foe", {}))
	elif opcode == BattleEnum.Opcode.FLEE and data.get("success") == true:
		journal.update_battle(id, "Fled")
	elif opcode in [BattleEnum.Opcode.END, BattleEnum.Opcode.TERMINATE]:
		var victor = str(after.get("winner", ""))
		journal.update_battle(id, "Ended" if victor.is_empty() else ("Won" if victor == player_id else "Lost"))
	elif opcode in [BattleEnum.Opcode.ERROR, BattleEnum.Opcode.DISCONNECT]:
		journal.update_battle(id, "Interrupted")
	else: return
	if is_instance_valid(panel): panel.refresh_battles()

func classify_encounter(miscrits: Array) -> String:
	if config.get("combat_mode") == "manual_target":
		if miscrits.is_empty(): return "unknown"
		var unknown = false
		for foe in miscrits:
			if not foe is Dictionary or not foe.get("name") is String or foe.name.strip_edges().is_empty():
				unknown = true
				continue
			if selected_species(foe): return "match"
		return "unknown" if unknown else "miss"
	if config.get("combat_mode") == "capture_rated":
		if miscrits.is_empty(): return "unknown"
		var unknown = false
		for m in miscrits:
			if not m is Dictionary:
				unknown = true
				continue
			if not m.get("name") is String or m.name.strip_edges().is_empty():
				unknown = true
				continue
			var selected = selected_species(m)
			var threshold = (0 if config.get("capture_low_rating_targets", false) else config.min_rating) if selected else config.other_min_rating
			var rating = m.get("rating")
			if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18:
				unknown = true
			elif rating >= threshold:
				return "match"
		return "unknown" if unknown else "miss"
	if config.target_mode == "targeted":
		if miscrits.is_empty(): return "unknown"
		var unknown = false
		for foe in miscrits:
			if not foe is Dictionary or not foe.get("name") is String or foe.name.strip_edges().is_empty():
				unknown = true
				continue
			if not selected_species(foe): continue
			var rating = foe.get("rating")
			if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18:
				unknown = true
				continue
			if rating >= (0 if config.get("capture_low_rating_targets", false) else config.min_rating): return "match"
		return "unknown" if unknown else "miss"
	if miscrits.is_empty():
		return "unknown"
	for m in miscrits:
		if not m is Dictionary or not m.get("mId") is float and not m.get("mId") is int:
			return "unknown"
	return "match"

func manual_battle_open() -> bool:
	if manual_battle_id.is_empty() or Server.current_battle_id != manual_battle_id: return false
	return is_instance_valid(BattleAnimator.battle) or WorldManager.loading_lock or not is_instance_valid(WorldManager.location_node) or not WorldManager.location_node.is_visible_in_tree()

func set_encounter_behavior(classification: String):
	history.fight = config.combat_mode == "fight" or classification == "miss"
	# Classify the whole encounter so a selected bonus opponent is not lost by
	# fleeing just because the currently active opponent is unwanted.
	history.flee_non_target = config.get("flee_non_targets", false) and classification == "miss" and config.combat_mode != "fight" and not training_farm()

func battle_decision(state: Dictionary) -> Dictionary:
	var choice: Dictionary
	if config.get("flee_non_targets", false) and history.get("flee_non_target", false) and config.combat_mode != "fight":
		choice = {"action":"flee", "reason":"Unwanted encounter; running away without fighting."}
	else: choice = policy.decide(state, config, history)
	capture_audit.record("decision", state, choice)
	return choice

func handoff_manual_target(miscrits: Array) -> bool:
	if config.get("combat_mode") != "manual_target" or classify_encounter(miscrits) != "match": return false
	if match_id.is_empty() or Server.current_battle_id != match_id: return false
	manual_battle_id = match_id
	enabled = false
	needs_rearm = true
	encounter_checked = true
	history.fight = false
	announce("manual_target", "Selected Miscrit found. Automation paused; play this battle manually. Finish it, then press Start/F8 to search again.")
	return true

func on_encounter(miscrits: Array):
	if config.get("campaign_enabled", false): return
	if match_id.is_empty() or Server.current_battle_id != match_id:
		return
	encounter_data = miscrits.duplicate(true)
	capture_audit.record("encounter", {"foes":miscrits, "foe":miscrits[0] if not miscrits.is_empty() else {}})
	if miscrits.is_empty():
		stop("Encounter has no opponents.")
		return
	var classification = classify_encounter(miscrits)
	if classification == "unknown":
		stop("Encounter data is missing or invalid.")
		return
	encounter_checked = true
	if handoff_manual_target(miscrits): return
	set_encounter_behavior(classification)
	var message = "Running from this unwanted encounter at the first legal turn." if history.flee_non_target else ("Fighting this encounter." if history.fight else "Capture target found; waiting for the server's turn and capture chance.")
	announce("encounter", message, {"miscrits": miscrits})

func on_battle_event(data, opcode: int, before: Dictionary, after: Dictionary):
	if data is Dictionary: update_battle_history(data, opcode, before, after)
	if opcode == BattleEnum.Opcode.CAPTURE and data is Dictionary:
		record_capture(data, before, after)
	if Server.current_battle_id != match_id or match_id.is_empty():
		return
	if data is Dictionary and opcode in [BattleEnum.Opcode.CAPTURE, BattleEnum.Opcode.CAPTURE_CONTINUE, BattleEnum.Opcode.FLEE, BattleEnum.Opcode.END, BattleEnum.Opcode.ERROR, BattleEnum.Opcode.TERMINATE]:
		var reply = {"opcode":opcode}
		reply.actor = "own" if data.get("user_id", "") == after.get("player", {}).get("user_id", "unknown") else "other_or_unknown"
		for field in ["success", "captured", "capture_chance"]:
			if data.has(field): reply[field] = data[field]
		capture_audit.record("server_response", after, {}, reply)
	if not manual_battle_id.is_empty() and Server.current_battle_id == manual_battle_id: return
	if not data is Dictionary:
		if campaign.owns(str(Server.current_battle_id)):
			campaign.fail("Unexpected campaign battle response; battle left open.", true)
			return
		stop("Unexpected battle response format.")
		return
	deadline = Time.get_ticks_msec() + 60000
	if opcode in [BattleEnum.Opcode.ERROR, BattleEnum.Opcode.INVALID, BattleEnum.Opcode.DISCONNECT, BattleEnum.Opcode.TERMINATE]:
		if campaign.owns(str(Server.current_battle_id)):
			campaign.fail("Campaign server error or disconnect; battle left open.", true)
			return
		stop("Server reported " + Server._capture_opcode_name(opcode) + ". Review the response.")
		return
	policy.observe(data, opcode, before, history)
	if data.has("capture_chance"):
		latest_chance = data.capture_chance
	elif opcode != BattleEnum.Opcode.READY and opcode != BattleEnum.Opcode.END:
		latest_chance = null
	if data.has("next_turn"):
		next_turn = str(data.next_turn)
		pending = bool(data.get("pending", false))
	var player_id = after.get("player", {}).get("user_id", "")
	if data.get("user_id", "") == player_id:
		if opcode == BattleEnum.Opcode.CAPTURE:
			capture_attempted = true
			capture_succeeded = bool(data.get("captured", false))
			kept_target_name = ""
			if capture_succeeded:
				var foe = before.get("foe", {})
				for name in config.get("miscrits", []):
					if name == str(foe.get("name", "")).strip_edges().to_lower() or int(catalog.by_name.get(name, {}).get("id", -2)) == int(foe.get("mId", -1)):
						kept_target_name = name
						break
			history.flee = not capture_succeeded
			inflight = ""
			announce("capture_result", "Captured; will keep it and continue." if capture_succeeded else "Capture failed; waiting for a legal turn to flee.")
		elif opcode == BattleEnum.Opcode.ABILITY and inflight == "ability":
			inflight = ""
		elif opcode == BattleEnum.Opcode.FLEE and inflight == "flee":
			inflight = ""
		elif opcode == BattleEnum.Opcode.CAPTURE_CONTINUE and inflight == "keep":
			inflight = ""
			if capture_succeeded and keep_sent:
				var error = confirm_kept_target()
				if not error.is_empty(): stop(error)
	if opcode == BattleEnum.Opcode.END:
		inflight = ""

func on_summary_ready(summary, victor: String):
	if not Server.spectator and Server.Player != null:
		journal.update_battle(str(Server.current_battle_id), "Won" if victor == Server.Player.user_id else "Lost")
		if is_instance_valid(panel): panel.refresh_battles()
	if Server.current_battle_id != match_id:
		return
	summary_ref = weakref(summary)
	if campaign.owns(str(Server.current_battle_id)):
		campaign.on_summary(victor)
		return
	if not manual_battle_id.is_empty() and Server.current_battle_id == manual_battle_id:
		announce("manual_summary", "Manual battle finished. Close the summary yourself, then press Start/F8 to search again.")
		return
	announce("summary", "Battle finished; continuing to the next configured object.")

func can_take_turn(battle) -> bool:
	return inflight.is_empty() and not battle.processing_queue and battle.action_queue.is_empty() and not battle.action_bar.block.visible and next_turn == battle.player.user_id and not pending and not battle.player.current_miscrit.handicap

func _process(delta):
	dismiss_notifications()
	if rotation.busy:
		rotation.watch_timeout()
		return
	if config.get("campaign_enabled", false):
		campaign.tick(delta)
		return
	if name_traveling:
		if enabled and Time.get_ticks_msec() > name_travel_deadline:
			stop("Travel confirmation timed out. Waiting for the pending request to finish; no retry was sent.")
		return
	if training or healing: return
	var battle = BattleAnimator.battle
	if not is_instance_valid(battle):
		if enabled and (config.get("auto_replace_max_level", false) or config.get("train_selected", false)) and not training and not healing and Server.Player != null and (not pending_search or (encounter_checked and leaving)) and campaign_world_ready():
			if not await rotation.ensure_ready(): return
			if not enabled or not campaign_world_ready() or is_instance_valid(BattleAnimator.battle) or not str(Server.current_battle_id).is_empty(): return
		if enabled and Server.Player != null and (not pending_search or (encounter_checked and leaving)) and not WorldManager.move_locked() and team_needs_heal():
			if Time.get_ticks_msec() >= heal_retry_at: heal_team()
			return
		if enabled and (config.get("auto_level_up", false) or config.get("train_selected", false)) and Server.Player != null and (not pending_search or (encounter_checked and leaving)) and not WorldManager.move_locked():
			for id in Server.Player.team:
				var m = Server.Player.miscrits.get(id)
				if training_allowed(m):
					train_miscrit(m)
					return
		if enabled and config.get("auto_search", false):
			process_name_search(delta)
			return
		if enabled and config.get("cross_area_search", false):
			process_route(delta)
			return
		super._process(delta)
		return
	elapsed += delta
	if elapsed < 0.25 or not enabled or area_ref == null:
		return
	elapsed = 0.0
	var now = Time.get_ticks_msec()
	if Server.spectator or Server.current_battle_id != match_id:
		stop("An unrelated battle is open.")
		return
	if now > deadline:
		stop("Battle response timed out; no action will be retried blindly.")
		return
	if not Server.socket.is_connected_to_host():
		stop("Connection lost.")
		return
	if not encounter_checked or leaving or now < next_action:
		return
	if battle.battle_type != "Wild":
		stop("Only wild captures are supported.")
		return
	if summary_ref != null:
		var summary = summary_ref.get_ref()
		if is_instance_valid(summary):
			leaving = true
			next_action = now + 2000
			summary._on_continue_pressed()
		return
	if battle.processing_queue or not battle.action_queue.is_empty():
		return
	if is_instance_valid(battle.captured):
		if capture_succeeded and not keep_sent and inflight.is_empty():
			keep_sent = true
			inflight = "keep"
			deadline = now + 60000
			announce("keep", "Keeping captured Miscrit with its original name.")
			battle.captured._on_continue_pressed()
		return
	if battle.winner != "" or not can_take_turn(battle):
		return
	var state = Server._capture_snapshot(battle)
	state.capture_chance = latest_chance
	if not select_active_foe(state.foe): return
	if capture_attempted and not capture_succeeded:
		history.flee = true
	var decision = battle_decision(state)
	if decision.action == "wait":
		return
	announce("decision", decision.reason, {"decision": decision, "state": state})
	if decision.action == "stop":
		stop(decision.reason)
		return
	perform_decision(battle, decision, now)

func send_ability(id: int):
	Server.send_battle_state(BattleEnum.Opcode.ABILITY, {"id": id})

func campaign_connected() -> bool:
	return Server.socket != null and Server.socket.is_connected_to_host()

func campaign_world_ready() -> bool:
	return not WorldManager.loading_lock and is_instance_valid(WorldManager.location_node) and WorldManager.location_node.is_visible_in_tree() and not WorldManager.move_locked()

func request_campaign_info():
	return await Server.Player.load_campaign_info(true)

func request_campaign_battle():
	return await Server.create_campaign_battle()

func request_team_update(team: Array):
	return await Server.rpc_call("update_team", {"team":team}, true)

func spawn_campaign_battle(id: String):
	UiManager.spawn_battle(id)

func campaign_snapshot(battle) -> Dictionary:
	return Server._capture_snapshot(battle)

func perform_decision(battle, decision: Dictionary, now: int):
	if config.get("campaign_enabled", false) and decision.action != "ability": return
	if not enabled or not inflight.is_empty() or (not manual_battle_id.is_empty() and Server.current_battle_id == manual_battle_id):
		return
	next_action = now + 500
	deadline = now + 60000
	inflight = decision.action
	match decision.action:
		"capture":
			if capture_attempted or battle.capture_control.capture_button.disabled:
				inflight = ""
				return
			capture_attempted = true
			capture_audit.record("action_sent", {}, decision)
			battle._on_capture_pressed()
			battle.capture_control._on_capture_confirmed()
		"flee":
			history.flee = true
			capture_audit.record("action_sent", {}, decision)
			battle.action_bar.do_flee()
		"ability":
			capture_audit.record("action_sent", {}, decision)
			if decision.get("healing", false):
				var snapshot = Server._capture_snapshot(battle)
				if not history.has("healed_members"): history.healed_members = []
				history.healed_members.append(str(int(snapshot.player.id)))
			else:
				history.attacks += 1
			battle.action_bar.lock_input()
			battle.player_team.lock()
			battle._on_ability_pressed()
			send_ability(decision.id)

func can_train(m) -> bool:
	return m != null and m.level < 35 and m.ready_to_train() and m.get_level_train_price() == 0

func training_allowed(m) -> bool:
	if not active_team_member(m) or not can_train(m): return false
	if config.get("train_selected", false) and Server.Player.team.find(m.id) > 0:
		return rotation.training_report(Server.Player, config.get("replacement_names", [])).eligible.any(func(row): return row.id == m.id)
	return config.get("auto_level_up", false)

func active_team_member(m) -> bool:
	return m != null and Server.Player != null and m.id in Server.Player.team and Server.Player.miscrits.get(m.id) == m

func platinum_allowed(m) -> bool:
	return enabled and active_team_member(m) and str(m.id) in config.get("platinum_miscrit_ids", [])

func request_training(m):
	return await Server.rpc_call("xp_train", {"miscritId": m.id, "currLevel": m.level}, true)

func train_miscrit(m):
	if training or not enabled or not active_team_member(m): return
	if not training_allowed(m): return
	training = true
	UiManager.block_all_inputs("auto_level")
	announce("level_up", "Training %s with earned XP." % m.get_name())
	var result = await request_training(m)
	if result is Dictionary and result.get("success", false) and result.get("data") is Dictionary:
		m.train_stats(result.data, 1)
		# Recheck selection, team and balance after the asynchronous free level.
		if not config.get("train_selected", false) or Server.Player.team.find(m.id) == 0: await upgrade_platinum(m)
		m.mark_seen()
		m.mark_captured()
		Server.Player.set_prop("team", Server.Player.team)
	else:
		stop("Free level-up failed; paused without retrying.")
	UiManager.release_inputs_block("auto_level")
	training = false

func select_active_foe(foe: Dictionary) -> bool:
	var classification = classify_encounter([foe])
	if classification == "unknown":
		stop("Active opponent name/rating is invalid.")
		return false
	if active_foe_id != int(foe.id):
		active_foe_id = int(foe.id)
		history = {"attacks": 0, "flee": false, "damage": {}, "healed_members": history.get("healed_members", []), "flee_non_target": history.get("flee_non_target", false)}
		capture_attempted = false
		capture_succeeded = false
		keep_sent = false
	history.fight = config.combat_mode == "fight" or classification == "miss"
	return true

func team_needs_heal() -> bool:
	for id in Server.Player.team:
		var m = Server.Player.miscrits.get(id)
		if m != null and m.chp <= 0: return true
	return false

func resolve_route_object(scene, item: Dictionary):
	if not is_instance_valid(scene): return null
	var container = scene.get_node_or_null(NodePath(item.container))
	if not is_instance_valid(container) or not (container == scene or scene.is_ancestor_of(container)): return null
	var id = int(item.object_id)
	if id < 0 or id >= container.get_child_count(): return null
	var object = container.get_child(id)
	if not object is Node2D or str(object.name) != item.object_name: return null
	if not object.has_method("can_search") or not object.has_method("check_user_entered"): return null
	return object

func name_search_position(scene, object) -> Vector2:
	# Teleporting beside an obstacle can make NavigationAgent snap the avatar
	# outside the search radius. Project the object onto the actual walkable mesh.
	var origin: Vector2 = object.global_position
	var closest = Vector2.INF
	var distance = INF
	for region in scene.find_children("*", "NavigationRegion2D", true, false):
		# Rendering visibility does not disable a Godot navigation region.
		if not region.enabled or region.navigation_polygon == null: continue
		var mesh = region.navigation_polygon
		var vertices = mesh.get_vertices()
		for index in mesh.get_polygon_count():
			var polygon = PackedVector2Array()
			for vertex in mesh.get_polygon(index): polygon.append(region.global_transform * vertices[vertex])
			if polygon.size() < 3: continue
			if Geometry2D.is_point_in_polygon(origin, polygon): return origin
			for edge in polygon.size():
				var point = Geometry2D.get_closest_point_to_segment(origin, polygon[edge], polygon[(edge + 1) % polygon.size()])
				var squared = point.distance_squared_to(origin)
				if squared < distance:
					distance = squared
					closest = point
	# Maps without a navigation mesh retain their existing search positioning.
	return origin + Vector2(0, 35) if not closest.is_finite() else closest

func move_for_name(scene, object, item: Dictionary, now: int) -> bool:
	var position = name_search_position(scene, object)
	var distance = position.distance_to(object.global_position)
	if distance > WorldManager.get_max_search_distance():
		announce("position_failed", "No walkable point within search range for " + ", ".join(item.targets), {"distance":distance, "mapping":item})
		skip_name_stop(item, now, "Cannot reach a walkable search position for " + ", ".join(item.targets))
		return false
	WorldManager.player.teleport(position)
	name_move_attempts += 1
	next_action = now + 750
	return true

func skip_name_stop(item: Dictionary, now: int, reason: String):
	# Quarantine this stop for the current run. Other targets and objects continue;
	# a full re-arm explicitly clears this list instead of retrying forever.
	name_skipped_stops[route_key(item)] = reason
	name_move_key = ""
	name_wait_key = ""
	next_action = now + 250
	if not name_stops.is_empty(): name_cursor = (name_cursor + 1) % name_stops.size()
	announce("skipped_position", reason + "; checking other search objects.", {"mapping":item})
	if is_instance_valid(panel): panel.refresh_name_targets()
	if not name_stops.any(func(stop_data): return not name_skipped_stops.has(route_key(stop_data))):
		stop("No reachable search objects remain. Check target status; Start/F8 to retry.")

func route_area_confirmed(item: Dictionary) -> bool:
	return Server.Player != null and Server.Player.location.name == item.location and Server.Player.area.id == int(item.area_id) and not Server.active_rpcs.has("update_location")

func route_area_ready(item: Dictionary) -> bool:
	return route_area_confirmed(item) and not WorldManager.move_locked()

func on_route_search(object_id: int):
	var item = config.search_route[route_cursor]
	var scene = WorldManager.location_node
	var object = resolve_route_object(scene, item)
	if not is_instance_valid(object) or object != WorldManager.player.searching_object or object_id != int(item.object_id) or not route_area_confirmed(item):
		stop("An object outside the current route stop was searched. Pause routing for manual searches.")
		return
	reset_battle()
	area_ref = weakref(object.get_parent())
	active_object_id = object_id
	match_id = ""
	pending_search = true
	encounter_checked = false
	leaving = false
	deadline = Time.get_ticks_msec() + 60000
	route_cursor = (route_cursor + 1) % config.search_route.size()
	route_target = ""
	announce("search", "Searching %s / object %d." % [item.area, object_id])

func process_route(delta):
	elapsed += delta
	if elapsed < 0.25: return
	elapsed = 0.0
	var now = Time.get_ticks_msec()
	if pending_search:
		if encounter_checked and leaving:
			pending_search = false
			match_id = ""
			encounter_checked = false
		elif now > deadline:
			stop("Route search or battle response timed out.")
			return
		else: return
	if not route_target.is_empty() and now > route_deadline:
		stop("Area change was not confirmed. Walk into the route stop's area and record that stop again.")
		return
	var scene = WorldManager.location_node
	if not is_instance_valid(scene) or not scene.is_inside_tree() or not is_instance_valid(WorldManager.player) or Server.Player == null: return
	if route_scene_ref != null and route_scene_ref.get_ref() != scene:
		stop("The loaded map changed. Return to the route's map and re-arm.")
		return
	if route_scene_ref == null: route_scene_ref = weakref(scene)
	var item = config.search_route[route_cursor]
	if Server.Player.location.name != item.location:
		stop("Travel to %s before starting this route." % item.location)
		return
	var object = resolve_route_object(scene, item)
	if object == null:
		stop("Route object changed or is not loaded. Record %s / object %d again." % [item.area, int(item.object_id)])
		return
	if now < next_action or WorldManager.move_locked() or Server.active_rpcs.has("update_location") or WorldManager.player.is_searching or not WorldManager.player.allow_click: return
	if not scene.is_visible_in_tree(): return
	var key = route_key(item)
	if route_target != key:
		WorldManager.player.teleport(Vector2(item.x, item.y))
		route_target = key
		route_deadline = now + 15000
		next_action = now + 750
		announce("route_move", "Moving to %s / object %d; waiting for area confirmation." % [item.area, int(item.object_id)])
		return
	if not route_area_ready(item): return
	# Confirmation succeeded; cooldown waits must not count as failed transitions.
	route_deadline = now + 15000
	if not object.is_visible_in_tree() or not object.get_parent().get("searchable"):
		stop("Route object is not currently searchable in this area.")
		return
	if not object.can_search(): return
	if not object.check_user_entered():
		stop("Recorded position is outside this object's search range. Record this stop again.")
		return
	if Server.Player.all_miscrits_dead(): return
	pending_search = true
	encounter_checked = false
	leaving = false
	deadline = now + 60000
	next_action = now + 1000
	dispatch_route_search(object)

func dispatch_route_search(object):
	WorldManager.user_want_search(object)

func request_healing():
	return await Server.rpc_call("heal_team", {}, true)

func on_name_search(object_id: int) -> bool:
	if name_active.is_empty():
		stop("Unexpected manual search during name search.")
		return false
	var object = resolve_route_object(WorldManager.location_node, name_active)
	# WorldManager.search_object holds its own movement lock while invoking
	# this hook. Only location acknowledgement and object identity matter here.
	if not is_instance_valid(object) or object != WorldManager.player.searching_object or object_id != int(name_active.object_id) or not route_area_confirmed(name_active):
		announce("mapping_mismatch", "Rejected mismatched search before RPC submission.", {"expected": name_active, "requested_object_id": object_id, "actual_location": Server.Player.location.name if Server.Player != null else "", "actual_area": Server.Player.area.id if Server.Player != null else -1, "location_rpc_pending": Server.active_rpcs.has("update_location")})
		stop("Search object/area does not match the selected Miscrit mapping.")
		return false
	reset_battle()
	area_ref = weakref(object.get_parent())
	active_object_id = object_id
	match_id = ""
	pending_search = true
	encounter_checked = false
	leaving = false
	deadline = Time.get_ticks_msec() + 60000
	name_cursor = (name_cursor + 1) % name_stops.size()
	name_move_key = ""
	announce("search", "Searching for %s in %s." % [", ".join(name_active.targets), name_active.area])
	return true

func request_name_location(item: Dictionary):
	return await Server.rpc_call("update_location", {"locationId": Constants.locations[item.location], "areaId": int(item.area_id)}, true, true)

func load_name_location(item: Dictionary):
	await WorldManager.update_user_location(item.location, int(item.area_id), "none", "world", true)

func travel_for_name(item: Dictionary):
	if name_traveling or not enabled: return
	name_traveling = true
	name_travel_deadline = Time.get_ticks_msec() + 60000
	WorldManager.acquire_move_lock()
	UiManager.block_all_inputs("name_travel")
	announce("travel", "Travelling to " + item.area + "; waiting for server confirmation.")
	# Unlike Server.update_location, do not change local state before acceptance.
	var reply = await request_name_location(item)
	if not reply is Dictionary or not reply.get("success", false):
		WorldManager.release_move_lock()
		UiManager.release_inputs_block("name_travel")
		name_traveling = false
		stop("Travel rejected or timed out: " + item.area + ". No search was sent.")
		return
	var scene = WorldManager.location_node
	var same_scene = is_instance_valid(scene) and scene.scene_file_path == "res://" + item.scene
	Server.Player.set_location({"name": Constants.locations_additional[item.location][int(item.area_id)], "area_id": int(item.area_id), "location": {"id": Constants.locations[item.location], "name": item.location}})
	WorldManager.release_move_lock()
	if not same_scene:
		# The server has already accepted the destination. Load through the normal
		# game pipeline without issuing a duplicate update_location request.
		await load_name_location(item)
	# Position immediately after scene load so the default entrance's area
	# trigger does not win a full second before the target position is applied.
	var destination_object = resolve_route_object(WorldManager.location_node, item)
	if is_instance_valid(destination_object) and is_instance_valid(WorldManager.player):
		WorldManager.player.teleport(name_search_position(WorldManager.location_node, destination_object))
	UiManager.release_inputs_block("name_travel")
	name_traveling = false
	name_move_key = ""
	next_action = Time.get_ticks_msec() + 1000

func process_name_search(delta):
	if not enabled or name_traveling: return
	elapsed += delta
	if elapsed < 0.25: return
	elapsed = 0.0
	var now = Time.get_ticks_msec()
	if pending_search:
		if encounter_checked and leaving:
			pending_search = false
			match_id = ""
			encounter_checked = false
		elif now > deadline:
			stop("Name search/battle response timed out.")
			return
		else: return
	if Server.Player == null or not is_instance_valid(WorldManager.player) or not is_instance_valid(WorldManager.location_node): return
	if Server.Player.tutorial:
		stop("Complete the tutorial before starting name search.")
		return
	if now < next_action or WorldManager.loading_lock or WorldManager.move_locked() or Server.active_rpcs.has("update_location") or WorldManager.player.is_searching or not WorldManager.player.allow_click: return
	var today = Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_system())).weekday
	var current_plan_key = str(search_names())
	if name_stops.is_empty() or today != name_day or hunt_plan_key != current_plan_key:
		hunt_plan_key = current_plan_key
		var planned = name_plan()
		name_stops = planned.stops
		name_statuses = planned.statuses
		name_cursor = 0
		name_day = today
		if name_stops.is_empty():
			stop("No searchable targets. Check the Search status beside each selected Miscrit.")
			return
		announce("plan", "%d search stops ready. See the target list for availability." % name_stops.size(), {"target_statuses": name_statuses})
	var found_stop = false
	for offset in name_stops.size():
		var index = (name_cursor + offset) % name_stops.size()
		if not name_skipped_stops.has(route_key(name_stops[index])):
			name_cursor = index
			found_stop = true
			break
	if not found_stop:
		stop("No reachable search objects remain. Check target status; Start/F8 to retry.")
		return
	var item = name_stops[name_cursor]
	var entry = catalog.by_name.get(item.targets[0], {})
	var availability = catalog.stop_error(entry, item, today, Server.Player.boss_achievements, Server.Player.tickets, LocalData.one_time_events)
	if not availability.is_empty():
		reset_name_search()
		announce("replan", availability + "; checking alternative locations.")
		return
	var scene = WorldManager.location_node
	if not scene.is_visible_in_tree(): return
	if scene.scene_file_path != "res://" + item.scene or Server.Player.location.name != item.location or Server.Player.area.id != int(item.area_id):
		travel_for_name(item)
		return
	var object = resolve_route_object(scene, item)
	if object == null or object.scene_file_path != item.object_scene:
		stop("Mapped object changed. Update mapping for " + ", ".join(item.targets) + ".")
		return
	if not object.is_visible_in_tree() or not object.get_parent().get("searchable"):
		if item.get("search_mode", "mapped") == "area_scan":
			name_cursor = (name_cursor + 1) % name_stops.size()
			name_move_key = ""
			next_action = now + 250
			return
		stop("Mapped object is currently unavailable: " + ", ".join(item.targets))
		return
	var key = route_key(item)
	if now < name_cooldowns.get(key, 0) or not object.can_search():
		# Try other targets during cooldown, without a rapid map-change loop.
		for offset in range(1, name_stops.size()):
			var other = name_stops[(name_cursor + offset) % name_stops.size()]
			if not name_skipped_stops.has(route_key(other)) and other.scene == item.scene and now >= name_cooldowns.get(route_key(other), 0):
				var other_object = resolve_route_object(scene, other)
				if is_instance_valid(other_object) and other_object.can_search():
					name_cursor = (name_cursor + offset) % name_stops.size()
					return
		if name_wait_key != key:
			name_wait_key = key
			announce("cooldown", "Waiting for search cooldown: " + ", ".join(item.targets))
		return
	if name_move_key != key:
		name_move_key = key
		name_move_attempts = 0
		move_for_name(scene, object, item, now)
		return
	if not route_area_ready(item): return
	if not object.check_user_entered():
		if name_move_attempts < 3:
			announce("reposition", "Search position moved; repositioning for " + ", ".join(item.targets), {"attempt":name_move_attempts + 1, "distance":object.global_position.distance_to(WorldManager.player.global_position)})
			move_for_name(scene, object, item, now)
			return
		skip_name_stop(item, now, "Cannot reach the mapped search position for " + ", ".join(item.targets))
		return
	name_active = item.duplicate(true)
	name_wait_key = ""
	pending_search = true
	encounter_checked = false
	leaving = false
	deadline = now + 60000
	next_action = now + 1000
	dispatch_route_search(object)

func heal_team():
	if healing: return
	healing = true
	UiManager.block_all_inputs("auto_heal")
	announce("heal", "Healing team before the next search.")
	var result = await request_healing()
	if result is Dictionary and result.get("success", false):
		Server.Player.heal_team()
	else:
		heal_retry_at = Time.get_ticks_msec() + 60000
		announce("heal_wait", "Healing unavailable; search paused, retrying in 60 seconds.")
	UiManager.release_inputs_block("auto_heal")
	healing = false

func request_bonus(m):
	return await Server.rpc_call("add_bonus", {"miscritId": m.id, "currLevel": m.level}, true)

func upgrade_platinum(m):
	if not config.get("platinum_upgrade", false) or not platinum_allowed(m) or m.level > 35: return
	var cost = m.level - m.bonus_level
	if cost != 1 or Server.Player.platinum < cost:
		stop("Platinum stat upgrade needs exactly 1 platinum available; paused before the next level.")
		return
	var result = await request_bonus(m)
	if result is Dictionary and result.get("success", false) and result.get("data") is Dictionary:
		Server.Player.set_prop("platinum", Server.Player.platinum - cost)
		m.add_bonus(result.data)
	else:
		stop("Platinum stat upgrade failed; paused without retrying the purchase.")
