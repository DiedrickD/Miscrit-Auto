extends CanvasLayer
@onready var color_rect: ColorRect = $ColorRect
@onready var control: Control = $Control


func screen_transition(case) -> void:
	if Server._study_fast_visuals():
		SoundManager.mute_bus('World', true if case == 1 else Settings.settings.get('sfx', false))
		control.visible = false
		color_rect.visible = false
		return
	match case:
		1:SoundManager.mute_bus('World', true)
	if not Settings.get_setting('fx', true):
		return
	var viewport = get_viewport()
	var image = viewport.get_texture().get_image()
	#var tex = ImageTexture.create_from_image(image)
	image.resize($Control.size.x, $Control.size.y, Image.INTERPOLATE_LANCZOS)

	var TILES_X = 8
	var TILES_Y = 6

	var tiles_node = $Control

	color_rect.visible = true
	tiles_node.visible = true

	var image_width = image.get_width()
	var image_height = image.get_height()

	var tile_width: float = image_width / TILES_X
	var tile_height: float = image_height / TILES_Y

	var added_width = 0
	var added_height = 0

	for x in range(TILES_X):
		added_height = 0
		added_width += tile_width
		for y in range(TILES_Y):
			var this_tile_height = tile_height
			added_height += tile_height
			if y == TILES_Y - 1:
				# LAST Y TILE
				this_tile_height = image_height - added_height + tile_height

			var this_tile_width = tile_width
			if x == TILES_X - 1:
				this_tile_width = image_width - added_width + tile_width

			var tile = Image.new()
			tile = tile.create(this_tile_width, this_tile_height, false, image.get_format())
			tile.blit_rect(
				image,
				Rect2(
					Vector2(x * tile_width, y * tile_height),
					Vector2(this_tile_width, this_tile_height)
				),
				Vector2.ZERO
			)
			var tile_texture = ImageTexture.new()
			tile_texture = tile_texture.create_from_image(tile)
			var tile_sprite = Sprite2D.new()
			tile_sprite.texture = tile_texture
			tile_sprite.position = Vector2(x * tile_width + this_tile_width / 2, y * tile_height + this_tile_height / 2	)
			tiles_node.add_child(tile_sprite)

	#tex.save('res//test.png')

	match case:
		2:
			_special_case(tiles_node, TILES_X, TILES_Y)
			SoundManager.fadeout_main(1.7)
			await get_tree().create_timer(1.7).timeout
			SoundManager.mute_bus('World',Settings.settings.get("sfx", false))
		1:
			SoundManager.fadeout_main()
			SoundManager.play_once("ui/transition_case1", "SFX")
			for i in control.get_children():
				animate_sprite(i, 1.0)
			await get_tree().create_timer(1.3).timeout

	_free_all()

	hide_me(0.15)

	await get_tree().process_frame


func hide_me(delay: float):
	await get_tree().create_timer(delay).timeout
	control.visible = false
	color_rect.visible = false


func _free_all():
	for i in control.get_children():
		control.remove_child(i)
		i.queue_free()


func animate_sprite(sprite: Sprite2D, _animation_duration: float, _ignore = false):
	match randi() % 3:
		0, 1, 4:
			var delay = [0.15, 0.3, 0.55].pick_random()
			await get_tree().create_timer(delay).timeout
			_increase_size_animation(sprite, 0.08, true)
		2, 3:
			var delay = [0.15, 0.3, 0.55].pick_random()
			await get_tree().create_timer(delay).timeout
			_final_anus(sprite, 0.14, true)


func _special_case(node, tile_x, tile_y):
	for x in range(tile_x):
		var nodes = []
		for y in range(tile_y):
			var index = x * tile_y + y
			nodes.append(node.get_child(index))
			pass
		var delay = 0.1
		await get_tree().create_timer(delay).timeout
		for child in nodes:
			_increase_size_animation(child, 0.08, false)


func _increase_size_animation(sprite: Sprite2D, animation_duration: float, animate_position):
	animation_duration += randf() / 8
	var scale_value = 1.0 + randf() / 1.8 + 0.1
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	(
		tween
		. tween_property(sprite, "scale", Vector2(scale_value, scale_value), animation_duration)
		. set_ease(Tween.EASE_IN)
	)
	await tween.finished
	var delay = 0.01
	delay += randf() / 15
	await get_tree().create_timer(delay).timeout
	_final_anus(sprite, 0.14, animate_position)


func _final_anus(sprite: Sprite2D, animation_duration: float, animate_position):
	var tile_width = sprite.texture.get_width()
	var tile_height = sprite.texture.get_height()
	var x_flip_offset = true if randi_range(0, 1) else false
	var y_flip_offset = true if randi_range(0, 1) else false
	var offset = Vector2(
		(tile_width if x_flip_offset else -tile_width) / 2,
		(tile_height if y_flip_offset else -tile_height) / 2
	)
	var position_with_offset = Vector2(sprite.position.x - offset.x, sprite.position.y - offset.y)
	#position_with_offset.x += 400
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.parallel().tween_property(sprite, "offset", offset, animation_duration * 1.8).set_ease(
		Tween.EASE_OUT
	)
	if animate_position:
		(
			tween
			. parallel()
			. tween_property(sprite, "position", position_with_offset, animation_duration * 1.8)
			. set_ease(Tween.EASE_OUT)
		)
	else:
		position_with_offset.x += 120
		(
			tween
			. parallel()
			. tween_property(sprite, "position", position_with_offset, animation_duration * 1.8)
			. set_ease(Tween.EASE_OUT)
		)
	animation_duration += randf() / 8
	var part_skew = 0
	var part_rotation = 0
	if offset.x >= 0:  # and offset.y >= 1) or (offset.x >= 1 and offset.y <= 1):
		part_skew = 75
		part_rotation = -75
	elif offset.x <= 0:  # and offset.y >= 1) or (offset.x <= 1 and offset.y <= 1):
		part_skew = -75
		part_rotation = 75
	part_skew = deg_to_rad(part_skew)
	part_rotation = deg_to_rad(part_rotation)
	tween.parallel().tween_property(sprite, "global_skew", part_skew, animation_duration).set_ease(
		Tween.EASE_OUT
	)
	tween.parallel().tween_property(sprite, "scale:x", 0.4, animation_duration).set_ease(
		Tween.EASE_OUT
	)
	tween.parallel().tween_property(sprite, "scale:y", 0.4, animation_duration).set_ease(
		Tween.EASE_OUT
	)
	(
		tween
		. parallel()
		. tween_property(sprite, "global_rotation", part_rotation, animation_duration)
		. set_ease(Tween.EASE_OUT)
	)
	(
		tween
		. parallel()
		. tween_callback(func(): sprite.visible = false)
		. set_delay(animation_duration / 1.1)
	)
