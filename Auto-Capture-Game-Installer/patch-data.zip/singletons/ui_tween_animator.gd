extends Node


func animate_property(
	node: Object, property: NodePath, final_val: Variant, duration: float
) -> void:
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, property, final_val, duration)
	await tween.finished


func node_fadein_dark(node, time:float=0.4):
	node.modulate = Color(0.0, 0.0, 0.0)
	var tween : Tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, 'modulate', Color(1.0, 1.0, 1.0), time)
	await tween.finished

func node_fadeout_dark(node, time:float=0.4):
	node.modulate = Color(1.0, 1.0, 1.0)
	var tween : Tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, 'modulate', Color(0.0, 0.0, 0.0), time)
	await tween.finished

func node_fadein_alpha(node, time:float=0.4):
	node.modulate.a = 0.0
	var tween : Tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, 'modulate:a', 1.0, time)
	await tween.finished

func node_fadeout_alpha(node, time:float=0.4):
	node.modulate.a = 1.0
	var tween : Tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, 'modulate:a', 0.0, time)
	await tween.finished

func node_flashing(node, time: float):
	if Server._study_fast_visuals():
		stop_node_flashing(node)
		return
	stop_node_flashing(node)
	var tween: Tween = node.create_tween().set_speed_scale(Server._study_tween_speed())
	tween.set_loops(0)
	tween.tween_property(node, "modulate", Color(1.8,1.8,1.8), 0)
	tween.tween_property(node, "modulate", Color(1.0,1.0,1.0), time)
	node.set_meta("flash_tween",tween)

func stop_node_flashing(node: Node):
	node.modulate = Color(1.0,1.0,1.0)
	if node.has_meta("flash_tween"):
		var node_flash_tween: Tween = node.get_meta("flash_tween")
		if node_flash_tween:
			node_flash_tween.kill()
