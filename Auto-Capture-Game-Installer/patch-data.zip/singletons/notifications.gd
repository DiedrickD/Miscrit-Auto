extends Node

@export var announcement: Variant = false
@export var show_announcement: bool = false
@export var announcement_action: Dictionary = {}

var notification_queue = []
var is_popup_active = false
var is_player_in_battle = false

signal on_new_friend(user_id: String)
signal on_bot_match(match_id: String)
signal on_unfriend(user_id: String)

func login_ready():
	Server.socket.closed.connect(_on_close)
	Server.socket.received_notification.connect(process_notification)
	Server.socket.received_stream_state.connect(process_stream)
	check_notifications()

func create_popup(popup_name: String) -> Node:
	return load("res://scenes/popup/%s.tscn" % popup_name).instantiate()

func process_notification(notif: NakamaAPI.ApiNotification):
	var popup_data = {"type": "", "notif": null, "data": {}}
	
	popup_data.notif = notif
	if notif.content:
		popup_data.data = JSON.parse_string(notif.content)
		
	match notif.code:
		-2:
			popup_data.type = "friend_request"
		-3:
			on_new_friend.emit(notif.sender_id)
			await Server.client.delete_notifications_async(Server._session, [notif.id])
			return
		-4:
			await Server.client.delete_notifications_async(Server._session, [notif.id])
			return
		-5:
			popup_data.type = "clan_request"
		-9:
			on_unfriend.emit(notif.sender_id)
			await Server.client.delete_notifications_async(Server._session, [notif.id])
			return
		1:
			if Server.current_battle_id != "":
				return
			popup_data.type = "duel_request"
		2:
			popup_data.type = "rank_up"
		3:
			popup_data.type = "currency_reward"
		4:
			popup_data.type = "quest"
			if ["Visited", "Heal"].has(popup_data.data.class):
				if !is_instance_valid(WorldManager.location_node):
					await WorldManager.enter_world_finished
			if popup_data.data.class == "Elementum":
				popup_data.type = "boss_defeated"
		5:
			popup_data.type = "daily_quest"
		6:
			popup_data.type = "anon_duel"
		7:
			Main.show_popup(popup_data.data.message, "Notice")
			await Server.client.delete_notifications_async(Server._session, [notif.id])
			return
		8:
			popup_data.type = "clan_invite"
		9:
			popup_data.type = "clan_accepted"
		42:
			if Server.current_battle_id:
				return
			on_bot_match.emit(popup_data.data.matchId)
			return
		_:
			return

	if is_player_in_battle or is_popup_active:
		notification_queue.append(popup_data)
	else:
		show_notification(popup_data)
		
func process_stream(state: NakamaRTAPI.StreamData):
	var notif = {"persistent": false}
	var data = JSON.parse_string(state.state)
	match data.type:
		"restart":
			var popup_data = {"type": "restart", "data": null, "notif": notif}
			show_notification(popup_data)
		"text":
			Main.show_popup(data.notice, "Notice")
		"image":
			var texture = await Utils.download_texture(data.url)
			if not texture:
				return
			var popup_data = {"type": "announcement", "data": {"texture": texture, "action": data.get('action', null)}, "notif": notif}
			show_notification(popup_data)
			

func show_notification(popup_data: Dictionary, block: bool = false):
	var popup = create_popup(popup_data.type)
	
	if block:
		if is_popup_active or is_player_in_battle:
			while is_popup_active or is_player_in_battle:
				await get_tree().process_frame
	
	is_popup_active = true
	UiManager.add_node_to_ui(popup)
	await popup.setup(popup_data.notif, popup_data.data)
	
	popup.tree_exited.connect(func():
		is_popup_active = false
		
		if popup_data.notif.persistent:
			await Server.api_call(func(): return await Server.client.delete_notifications_async(Server._session, [popup_data.notif.id]))
		
		if notification_queue.size() > 0 and !is_player_in_battle:
			var next_popup = notification_queue.pop_front()
			show_notification(next_popup)
	)

	var hunter = Server.get_node_or_null("MamaHunter")
	if hunter and hunter.has_method("watch_notification"):
		hunter.watch_notification(popup, popup_data.type)

func show_blocking_popup(popup_scene: Node) -> Node:
	if is_popup_active or is_player_in_battle:
		while is_popup_active or is_player_in_battle:
			await get_tree().process_frame
	
	is_popup_active = true
	UiManager.add_node_to_ui(popup_scene)
	
	popup_scene.tree_exited.connect(func():
		is_popup_active = false
		if notification_queue.size() > 0 and !is_player_in_battle:
			var next_popup = notification_queue.pop_front()
			show_notification(next_popup)
	)
	
	return popup_scene

func check_notifications():
	if !is_instance_valid(WorldManager.location_node):
		await WorldManager.enter_world_finished
	var result = await Server.api_call(func(): return await Server.client.list_notifications_async(Server._session, 20))
	if result is int:
		Main.show_popup("An error occurred while fetching Notifications (Code %d)" % result)
		return
	for n in result.notifications:
		if n.code == -3:
			await Server.api_call(func(): return await Server.client.delete_notifications_async(Server._session, [n.id]))
		else:
			process_notification(n)


func display_announcement(bypass: bool = false):
	if not bypass and not show_announcement:
		return false
	if not announcement:
		return false
	var texture = await Utils.download_texture(Server.CDN_URL + "/announcements/%s" % announcement)
	if not texture:
		return false
	var popup_data = {"type": "announcement", "data": {"texture": texture, "action": announcement_action}, "notif": {"persistent": false}}
	show_notification(popup_data, true)
	DataService.set_cache_announcement()
	return true

func is_busy():
	return is_popup_active or is_player_in_battle

func enter_battle():
	is_player_in_battle = true

func exit_battle():
	is_player_in_battle = false
	if notification_queue.size() > 0 and !is_popup_active:
		var next_popup = notification_queue.pop_front()
		show_notification(next_popup)

func _on_close():
	Server.socket.received_notification.disconnect(process_notification)
	Server.socket.received_stream_state.disconnect(process_stream)
