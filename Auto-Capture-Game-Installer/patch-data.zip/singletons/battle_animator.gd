extends Node

var ExplosionGuy
var ExplosionGuyParticle
var ExplosionGuyRandom

var MovingAnimatedObject
var SimpleAnimatedSprite
var SimpleSprite

var SimpleParticle
var ThrowGuy


var battle = null

var code_names = { }

var atlas
var animation

var self_forbidden = []
var links = {}

var ANIMATIONS_DIR = 'user://animations/'

var sprite_color_material

var animations_loaded: bool = false

signal finished

signal frame_updated(delta)

func _ready() -> void:
	if not DirAccess.dir_exists_absolute(ANIMATIONS_DIR):
		DirAccess.make_dir_absolute(ANIMATIONS_DIR)

	var animation_project = Utils.get('animation_project') != null

	if animation_project:
		on_resource_pack_loaded()

func start_loading_sprite_frames():
	atlas = str_to_var(FileAccess.open('res://config/atlas.json',FileAccess.READ).get_as_text())
	animation = str_to_var(FileAccess.open('res://config/animation.json',FileAccess.READ).get_as_text())

func on_resource_pack_loaded():	
	var local_json: Dictionary = JSON.parse_string(FileAccess.open("res://animations_config_local.json", FileAccess.READ).get_as_text())
	links.merge(local_json["links"])
	self_forbidden += local_json["self_forbidden"]
	
	start_loading_sprite_frames()
	
	ExplosionGuy = load('res://scenes/battle/effects/classes/ExplosionGuy/Additional/ExplosionGuy.gd')
	ExplosionGuyRandom = load('res://scenes/battle/effects/classes/ExplosionGuy/Additional/ExplosionGuyRandom.gd')
	ExplosionGuyParticle = load('res://scenes/battle/effects/classes/ExplosionGuy/Additional/ExplosionGuyParticle.gd')
	MovingAnimatedObject = load('res://scenes/battle/effects/classes/MovingObject/MovingAnimatedObject.gd')
	SimpleAnimatedSprite = load('res://scenes/battle/effects/classes/SimpleAnimatedSprite/SimpleAnimatedSprite.gd')
	SimpleSprite = load('res://scenes/battle/effects/classes/SimpleSprite/SimpleSprite.gd')
	SimpleParticle = load('res://scenes/battle/effects/classes/SimpleParticle/SimpleParticle.gd')
	ThrowGuy = load('res://scenes/battle/effects/classes/ThrowGuy/ThrowGuy.gd')
	
	code_names = {
	"white":get_asset("effects/overlays/white.webp"),
	"black": get_asset("effects/overlays/black.webp"),
	"red": get_asset("effects/overlays/red.webp"),
	"orange": get_asset("effects/overlays/orange.webp"),
	"yellow": get_asset("effects/overlays/yellow.webp"),
	"green": get_asset("effects/overlays/green.webp"),
	"green_blue": get_asset("effects/overlays/green_blue.webp"),
	"blue":get_asset("effects/overlays/blue.webp"),
	"dark_blue":get_asset("effects/overlays/dark_blue.webp"),
	"aquablue":get_asset("effects/overlays/aquablue.webp"),
	"purple":get_asset("effects/overlays/purple.webp"),
	"green_swamp":get_asset("effects/overlays/green_swamp.webp"),
	"sand":get_asset("effects/overlays/sand.webp"),
	"dark_green":get_asset("effects/overlays/dark_green.webp"),
	"pink":get_asset("effects/overlays/pink.webp"),
	
	"earth":get_asset("effects/overlays/earth.webp"),
	"fire":get_asset("effects/overlays/fire.webp"),
	"nature":get_asset("effects/overlays/nature.webp"),
	"water":get_asset("effects/overlays/water.webp"),
	"wind":get_asset("effects/overlays/wind.webp"),
	"heal":get_asset("effects/overlays/heal.webp"),
	"status":get_asset("effects/overlays/status.webp"),
	
	"kindle":get_asset("effects/overlays/kindle.webp"),
	"oxidation":get_asset("effects/overlays/oxidation.webp"),
	"petrify":get_asset("effects/overlays/petrify.webp"),
	
	"snow":get_asset("effects/overlays/snow.webp")
}
	
	load_and_create_materials()
	
	animations_loaded = true
	finished.emit()

func load_and_create_materials():
	sprite_color_material = load('res://scenes/battle/effects/materials/sprite_color.tres')
	sprite_color_material.shader = load('res://shaders/battle_effects/sprite_color.gdshader')
	sprite_color_material.shader.resource_local_to_scene = true

func get_frame(animation_name:String,frame:int):
	var data = animation[animation_name].frames[frame]
	if data['texture'] is Texture:
		return data['texture']
	elif data['texture'] is String:
		var texture_name = data['texture']
		if '.' in texture_name:
			data['texture'] = BattleAnimator.get_asset(texture_name)
			return data['texture']
		else:
			data['texture'] = create_atlas_texture(atlas[texture_name]['texture_path'],atlas[texture_name]['rect'])
			return data['texture']
	elif data['texture'] == null:
		return null

func create_atlas_texture(texture_path: String, rect_values:Array) -> AtlasTexture:
	var sprite_sheet = BattleAnimator.get_asset(texture_path)
	var region_rect = Rect2(rect_values[0], rect_values[1], rect_values[2], rect_values[3])
	var atlas_texture = AtlasTexture.new()
	atlas_texture.atlas = sprite_sheet
	atlas_texture.region = region_rect
	return atlas_texture

func hit(texture_code, time_start, time_max, time_exit, max_transparency,splash_node):
	var node = load("res://scenes/battle/effects/splash/splash.tscn").instantiate()
	battle.get_node("Control/splash_%s"%[splash_node]).add_child(node)
	var texture = BattleAnimator.name_to_texture(texture_code)
	node.texture = texture
	node.modulate = Color(1, 1, 1, 0)
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(node, "modulate:a", max_transparency, time_start)
	tween.tween_property(node, "modulate:a", 0.0, time_exit).set_delay(time_max - time_exit)
	await tween.finished
	node.queue_free()

func play_recoil(sprite,recoil_distance:float=10.0,recoil_duration:float=0.1,return_duration:float=0.15,times:float=5):
	var original_position: Vector2 = sprite.global_position
	var recoil_tween = create_tween().set_speed_scale(Server._study_tween_speed())
	recoil_distance *= -1 if sprite.flip_h else 1
	for time in times:
		recoil_tween.tween_property(sprite, "global_position", original_position + Vector2(recoil_distance, 0), recoil_duration)
		recoil_tween.tween_property(sprite, "global_position", original_position, return_duration)

func play_jump(sprite,jump_distance:float=10.0,duration:float=0.1,return_duration:float=0.12,times:float=5):
	var original_position: Vector2 = sprite.global_position
	var recoil_tween = create_tween().set_speed_scale(Server._study_tween_speed())
	for time in times:
		recoil_tween.tween_property(sprite, "global_position", original_position - Vector2(0, jump_distance), duration).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		recoil_tween.tween_property(sprite, "global_position", original_position, return_duration).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)

func play_jump_percentages(sprite,jump_distance:float=10.0,duration:float=0.1,return_duration:float=0.12,percentages:Array = [1.0],time_percentages:Array = [1.0]):
	var original_position: Vector2 = sprite.global_position
	var recoil_tween = create_tween().set_speed_scale(Server._study_tween_speed())
	for id in percentages.size():
		var speed_scale:float = time_percentages[id]
		var distance_scale:float = percentages[id]
		recoil_tween.tween_property(sprite, "global_position", original_position - Vector2(0, jump_distance*distance_scale), duration*speed_scale).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		recoil_tween.tween_property(sprite, "global_position", original_position, return_duration*speed_scale).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)

func drag_screen(movement_radius, move_duration, times):
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	var original_background_position = battle.main_activity_layer.position
	for i in times:
		var random_offset = Vector2(randf_range(-movement_radius, movement_radius),randf_range(-movement_radius, movement_radius))
		var target_position_background = original_background_position + random_offset
		tween.tween_property(battle.main_activity_layer, "position", target_position_background, move_duration)
	tween.tween_property(battle.main_activity_layer, "position", original_background_position, move_duration)
	await tween.finished

func set_overlay(sprite,code):
	var texture_code = name_to_texture(code)
	sprite.material.set_shader_parameter("overlay_image", texture_code)

func hit_sprite(sprite, texture_code, time_start, time_max, time_exit, max_transparency):
	set_overlay(sprite,texture_code)
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_method(set_shader_transparency.bind(sprite), 0.0, max_transparency, time_start)
	tween.tween_method(set_shader_transparency.bind(sprite), max_transparency, 0.0, time_exit).set_delay(time_max - time_exit)
	await tween.finished

func hit_sprite_transparency(sprite, time_start, time_max, time_exit, value : float = 0.0):
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(sprite,'modulate:a',value,time_start)
	tween.tween_property(sprite,'modulate:a',1.0,time_exit).set_delay(time_max - time_exit)
	await tween.finished

func play_animation(sprite, Name):
	if Server._study_fast_combat(): return
	await Server._study_play_animation(sprite.animation_player, Name)

func drag_sprite(sprite,movement_radius, move_duration, times):
	var original_position = sprite.position
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	for i in times:
		var random_offset = Vector2(randf_range(-movement_radius, movement_radius),randf_range(-movement_radius, movement_radius))
		var target_position = original_position + random_offset
		tween.tween_property(sprite, "position", target_position, move_duration)
	tween.tween_property(sprite, "position", original_position, move_duration)
	await tween.finished

func drag_sprite_x(sprite, movement_radius, move_duration, times):
	var original_position = sprite.position.x
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	var direction = 1
	for i in times:
		var random_offset = randf_range(0,movement_radius) * direction
		direction *= -1
		var target_position = original_position + random_offset
		tween.tween_property(sprite, "position:x", target_position, move_duration)
	tween.tween_property(sprite, "position:x", original_position, move_duration)
	await tween.finished

func blow_sprite(sprite, enter_time:float, stay_time:float, exit_time:float,blow_distance:float = -90):
	var original_position = sprite.global_position.x
	var direction = 1 if sprite.flip_h else -1
	blow_distance = blow_distance * direction
	var final_position = original_position + blow_distance
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(sprite, "global_position:x", final_position, enter_time).set_trans(Tween.TRANS_QUINT).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(sprite, "global_position:x", original_position, exit_time).set_trans(Tween.TRANS_QUINT).set_ease(Tween.EASE_IN_OUT).set_delay(stay_time-exit_time)
	await tween.finished

func squeeze_sprite(sprite, squeeze_enter_duration:float, time:float, squeeze_exit_duration:float):
	var original_scale_y = sprite.scale.y
	var target_scale_y = original_scale_y * 0.2
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(sprite, "scale:y", target_scale_y, squeeze_enter_duration)
	tween.tween_property(sprite, "scale:y", original_scale_y+0.15, squeeze_exit_duration).set_trans(Tween.TRANS_QUINT).set_delay(time-squeeze_exit_duration)
	tween.tween_property(sprite, "scale:y", original_scale_y-0.12, squeeze_exit_duration*0.8).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:y", original_scale_y+0.09, squeeze_exit_duration*0.65).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:y", original_scale_y-0.06, squeeze_exit_duration*0.58).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:y", original_scale_y+0.03, squeeze_exit_duration*0.45).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:y", original_scale_y, squeeze_exit_duration*0.37).set_trans(Tween.TRANS_QUINT)
	await tween.finished

func squeeze_sprite_x(sprite, squeeze_enter_duration:float, time:float, squeeze_exit_duration:float):
	var original_scale_x = sprite.scale.x
	var target_scale_x = original_scale_x * 0.2
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(sprite, "scale:x", target_scale_x, squeeze_enter_duration)
	tween.tween_property(sprite, "scale:x", original_scale_x+0.15, squeeze_exit_duration).set_trans(Tween.TRANS_QUINT).set_delay(time-squeeze_exit_duration)
	tween.tween_property(sprite, "scale:x", original_scale_x-0.12, squeeze_exit_duration*0.8).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:x", original_scale_x+0.09, squeeze_exit_duration*0.65).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:x", original_scale_x-0.06, squeeze_exit_duration*0.58).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:x", original_scale_x+0.03, squeeze_exit_duration*0.45).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "scale:x", original_scale_x, squeeze_exit_duration*0.37).set_trans(Tween.TRANS_QUINT)
	await tween.finished

func play_scale_boom(sprite,boom_time:float=0.2,_exit_time:float=0.2):
	var original_scale = sprite.scale
	var boom_scale = original_scale
	boom_scale.x = boom_scale.x * 0.8
	boom_scale.y = boom_scale.y * 1.2
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(sprite, "scale", boom_scale, boom_time)
	tween.tween_property(sprite, "scale", original_scale, boom_time)
	await tween.finished

func play_sprint(sprite):
	var original_position = sprite.global_position.x
	var direction = 1 if sprite.flip_h else -1
	sprite.z_index = 1
	var hit_to_offset = 900
	var edge_offset = -600
	var hit_to_pos = original_position + hit_to_offset * direction
	var edge_pos = original_position + edge_offset * direction
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	sprite.material.set_shader_parameter("blurs", Vector2(0.001, 0.001))
	for i in range(3):
		tween.tween_property(sprite, "global_position:x", hit_to_pos, 0.25)
		tween.tween_property(sprite, "global_position:x", edge_pos, 0.0)
	tween.tween_property(sprite, "global_position:x", (original_position + (100)*direction), 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUINT)
	tween.tween_property(sprite, "global_position:x", original_position, 0.25).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_QUINT)
	await tween.finished
	sprite.z_index = 0
	sprite.material.set_shader_parameter("blurs", Vector2(0.0, 0.0))

func play_jerk(attacker,target):
	var first_coordinates =  attacker.get_coordinates_point(Vector2(0,0))
	var final_coordinates = target.get_coordinates_point(Vector2(-76,-70))
	var direction_to_target = (final_coordinates - first_coordinates).normalized() 
	attacker.z_index = 1
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(attacker, "global_position", first_coordinates - direction_to_target * 20, 0.05).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
	tween.tween_property(attacker, "global_position", first_coordinates + direction_to_target * 30, 0.05).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
	tween.tween_property(attacker, "global_position", first_coordinates - direction_to_target * 40, 0.1).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
	tween.tween_property(attacker, "global_position", final_coordinates, 0.12).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
	tween.tween_property(attacker, "global_position", first_coordinates, 0.23).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)
	await tween.finished
	attacker.z_index = 0

func reset_shader_param(sprite):
	sprite.material.set_shader_parameter("rotation", 0)
	sprite.material.set_shader_parameter("offset", Vector2(0.0, 0.0))
	sprite.material.set_shader_parameter("disable_tiling", false)
	sprite.material.set_shader_parameter("blurs", Vector2(0.0, 0.0))
	sprite.material.set_shader_parameter("overlay_scale_centered", Vector2(1.0, 1.0))

var cast_script

func overlay_sprite(sprite, code):
	if Server._study_fast_combat(): return
	if killed:
		return
	reset_shader_param(sprite)
	sprite.animation_player.pause()
	if ResourceLoader.exists('res://scenes/battle/effects/effects/cast_%s/cast.gd'%[code]):
		cast_script = load('res://scenes/battle/effects/effects/cast_%s/cast.gd'%[code]).new(sprite)
		await cast_script.finished
		if is_instance_valid(cast_script):
			cast_script.queue_free()
		else:
			return
	else:
		printerr('Overlay Doesn\'t exist -',code)
	sprite.animation_player.play()

func kill_overlay_sprite():
	if is_instance_valid(cast_script):
		cast_script.finished.emit()
		cast_script.free()

func set_shader_offset(value, sprite):
	sprite.material.set_shader_parameter("offset", value)

func set_shader_transparency(value: float, sprite):
	sprite.material.set_shader_parameter("transparency", value)

func set_shader_rotation(value: float, sprite):
	sprite.material.set_shader_parameter("rotation", value)

func set_hue_shift(value:float, sprite):
	sprite.material.set_shader_parameter("hue_shift", value)

func animate_moving_overlay(sprite,direction_x: String,direction_y: String,enter_time: float,time: float,base_value = 2.4,transparency = 0.9):
	var vector = Vector2(0.0, 0.0)
	if direction_x != "z":
		vector.x = base_value if direction_x == "l" else -base_value
	if direction_y != "z":
		vector.y = base_value if direction_y == "u" else -base_value
	var delay_before_finish = time - enter_time
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.parallel().tween_method(set_shader_transparency.bind(sprite), 0.0, transparency, enter_time)
	tween.parallel().tween_method(set_shader_offset.bind(sprite), Vector2(0.0, 0.0), vector, time)
	tween.parallel().tween_method(set_shader_transparency.bind(sprite), transparency, 0.0, enter_time).set_delay(delay_before_finish)
	await tween.finished

func name_to_texture(code_name):
	if code_name in code_names:
		return code_names[code_name]
	return code_name

func gd_animation_exists(anim_name:String):
	return ResourceLoader.exists('res://scenes/battle/effects/effects/impact_%s/impact.gd'%[anim_name])

func get_gd_animation_name(ability_name:String):
	
	var early_check : String = ability_name.to_lower().replace(" ", "").replace("'", "")
	
	if early_check in links:
		return links[early_check]
	
	if gd_animation_exists(early_check): # If animation exist return it
		return early_check
	
	# If animation not exist, try to get rid of prefixes
	for rem in ['Light ', 'Dark ', 'Foil ', 'Blighted ', 'Petrified ', 'Elite ']:
		if ability_name.begins_with(rem):
			ability_name = ability_name.substr(rem.length())
			break
	
	var anim_name = ability_name.to_lower().replace(" ", "").replace("'", "")
	if anim_name in links: # Check animation without variant prefixes in links 
		return links[anim_name]
	return anim_name

var killed: bool = false

func kill_battle_animator():
	killed = true

func activate_battle_animator():
	killed = false

var animation_script

func animate_scene_gd(attacker,target,anim_name:String):
	if Server._study_fast_combat(): return
	if killed:
		return
	if !ResourceLoader.exists('res://scenes/battle/effects/effects/impact_%s/impact.gd'%[anim_name]):
		printerr(anim_name, ' - doesnt exist')
		return false
	animation_script = load('res://scenes/battle/effects/effects/impact_%s/impact.gd'%[anim_name]).new(attacker,target,anim_name)
	await animation_script.finished
	if is_instance_valid(animation_script):
		animation_script.queue_free()
	return true

func kill_animate_scene_gd():
	if is_instance_valid(animation_script):
		animation_script.finished.emit()
		animation_script.free()

func get_asset(path:String):
	return load("res://assets/" + path)

func play_once(path: String, _bus = "SFX"):
	SoundManager.play_once(path,_bus)

func is_animation_rewritten(current_name: String, animation_name: String):
	if Server._study_fast_combat(): return false
	return ResourceLoader.exists("res://scenes/battle/effects/effects/animation_rewrite_%s_%s/animation_rewrite.gd"%[current_name,animation_name])

func play_rewritten_animation(current_name: String, animation_name: String, user: MiscritSprite):
	if Server._study_fast_combat(): return
	var animation_rewrite_script = load("res://scenes/battle/effects/effects/animation_rewrite_%s_%s/animation_rewrite.gd"%[current_name,animation_name]).new(user)
	await animation_rewrite_script.finished
	animation_rewrite_script.queue_free()

func main_animations_package_exist(animations_pck_path:String):
	var success = ProjectSettings.load_resource_pack(animations_pck_path, false)
	if not success:
		printerr("Failed to load ",animations_pck_path)
	else:
		on_resource_pack_loaded()
	#delete_old_versions('animations',animations_pck_path)

func sound_package_exist(sounds_pck_path:String):
	var success = ProjectSettings.load_resource_pack(sounds_pck_path, false)
	if not success:
		printerr("Failed to load ",sounds_pck_path)
	#delete_old_versions('sounds',sounds_pck_path)

func get_shader_material(material_name: String) -> Material:
	return get(material_name).duplicate(true)

func delete_old_versions(file_body:String,current_version_file_path:String):
	var dir = DirAccess.open(ANIMATIONS_DIR)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			var file_path : String = ANIMATIONS_DIR + file_name
			if file_name.ends_with(".pck") and file_name.begins_with(file_body):
				if file_path != current_version_file_path:
					print("Deleting old version - ", file_path,  ' | new version path - ',current_version_file_path)
					DirAccess.remove_absolute(file_path)
			file_name = dir.get_next()
		dir.list_dir_end()
	else:
		printerr("Failed to open animation dir")

func download_files(file_list):
	# redownloads if config hash different from actual .pcks hash
	for file in file_list:
		var file_body : String = file["body"]
		var file_name = file_body + '.pck'
		var file_hash:String = file["hash"]
		#Server.CDN_URL+'/'+file_body+'.pck' #
		var file_url = "https://animations.worldofmiscrits.com/%s.pck?a=%s" % [file_body, file_hash]
		var file_path = ANIMATIONS_DIR + file_name 
		if FileAccess.file_exists(ANIMATIONS_DIR + file_name):
			var current_file_hash:String = get_hash(file_path)
			if current_file_hash != file_hash:
				print("Updating file, because hash not matched: %s, with link: %s" % [file_name, file_url])
				download_file(file_name, file_url, file_body, file_hash)
			else:
				match file_body:
					'animations':
						main_animations_package_exist(ANIMATIONS_DIR + file_name)
					'sounds':
						sound_package_exist(ANIMATIONS_DIR + file_name)
		else:
			print("Starting download: %s, with link: %s" % [file_name, file_url])
			download_file(file_name, file_url, file_body, file_hash)

signal animations_updated_signal
signal animations_update_failed_signal
var animations_update_available: bool = false
var animations_updated: bool = false

func download_file(file_name:String, file_url: String, file_body: String, file_hash: String):
	var is_animations: bool = file_body == 'animations'
	var is_sounds: bool = file_body == 'sounds'
	
	if is_animations:
		animations_update_available = true
	
	var http_request = HTTPRequest.new()
	http_request.accept_gzip = true
	add_child(http_request)
	var success: bool = false
	var total_attempts: int = 0
	while not success:
		http_request.request(file_url)
		var result = await http_request.request_completed
		success = _handle_file_response(result, file_name, file_hash)
		if not success:
			if is_animations:
				animations_update_failed_signal.emit()
			if total_attempts >= 5:
				if is_sounds:
					break
			print("Retrying download:", file_name)
			await get_tree().create_timer(2.0).timeout  
		else:
			match file_body:
				'animations':
					main_animations_package_exist(ANIMATIONS_DIR + file_name)
					animations_updated = true
					animations_updated_signal.emit()
				'sounds':
					sound_package_exist(ANIMATIONS_DIR + file_name)
		total_attempts += 1
	http_request.queue_free()

func _handle_file_response(result, file_name, file_hash):
	var response_code = result[1]
	var body = result[3]
	if response_code == 200:
		var file_path = ANIMATIONS_DIR + file_name 
		var file = FileAccess.open(file_path, FileAccess.WRITE)
		if file:
			file.store_buffer(body)
			file.close()
			var current_file_hash:String = get_hash(file_path)
			if current_file_hash == file_hash:
				print("Download completed:", file_name)
				return true
			else:
				# keeps redownloadng until hash matches
				print("Download completed but hash not matched, retrying", file_name)
				return false
		else:
			print("Failed to write file:", file_name)
			return false
	else:
		print("Failed to download:", file_name, "Response code:", response_code)
		return false


const CHUNK_SIZE = 32768 * 2 * 2 # 128 kb

func get_hash(path: String):
	if not FileAccess.file_exists(path):
		print("File does not exist.")
		return ''
	var ctx = HashingContext.new()
	ctx.start(HashingContext.HASH_MD5)
	var file = FileAccess.open(path, FileAccess.READ)
	while file.get_position() < file.get_length():
		var remaining = file.get_length() - file.get_position()
		ctx.update(file.get_buffer(min(remaining, CHUNK_SIZE)))
	var res = ctx.finish()
	return res.hex_encode()

func get_config():
	var http_request = HTTPRequest.new()
	http_request.accept_gzip = true
	add_child(http_request)
	var success = false
	while not success:
		var url : String = Server.CDN_URL + "/animations_config.json"
		http_request.request(url)
		var result = await http_request.request_completed
		success = _handle_response(result)
		if not success:
			print("Retrying request")
			await get_tree().create_timer(2.0).timeout
	http_request.queue_free()

func _handle_response(result):
	var response_code = result[1]
	var body = result[3]
	if response_code == 200:
		var text_response: String = body.get_string_from_utf8()
		_parse_text_response(text_response, true)
		return true
	else:
		printt("Failed to get config:", response_code, result[0])
		return false

func _parse_text_response(text_response: String, need_download_files: bool):
	var response_split: PackedStringArray = text_response.replace("\r","").split("\n")
	var animations_hash: String = response_split[0]
	var sounds_hash: String = response_split[1]
	for link_item in response_split[2].split(","):
		if not link_item:
			continue
		var link_split: PackedStringArray = link_item.split(":")
		var link_key: String = link_split[0]
		var link_value: String = link_split[1]
		links[link_key] = link_value
	for self_forbidden_name in response_split[3].split(","):
		if not self_forbidden_name:
			continue
		self_forbidden.append(self_forbidden_name)
	
	if need_download_files:
		var required: Array = [{"body":"animations", "hash": animations_hash}, {"body":"sounds", "hash": sounds_hash}]
		download_files(required)

func _process(delta: float) -> void:
	frame_updated.emit(delta)
