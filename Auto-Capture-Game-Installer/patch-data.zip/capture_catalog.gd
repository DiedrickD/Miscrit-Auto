extends RefCounted

const LABELS = {"forest": "Forest", "hidden_forest": "Hidden Forest", "mount_gemma": "Mount Gemma", "mansion": "Mansion", "sunfall_shores": "Sunfall Shores", "cave": "Cave", "moon": "Moon", "shack": "Shack", "miscrian_jungle": "Miscrian Jungle", "monks_mountain": "Monks Mountain", "emerald_isle": "Emerald Isle", "temple": "Temple"}
var data: Dictionary = {}
var entries: Array = []
var by_name: Dictionary = {}
var by_id: Dictionary = {}
var area_index: Dictionary = {}
var learned_records: Array = []
var mapping_error = ""

func _init():
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://capture_catalog.json"))
	if parsed is Dictionary:
		data = parsed
		entries = data.get("species", []).duplicate(true)
	index_names()
	for stop in data.get("area_objects", []):
		var key = "%s:%d" % [stop.location, int(stop.area_id)]
		if not area_index.has(key): area_index[key] = []
		area_index[key].append(stop)
	load_observations()

func observation_path() -> String:
	var directory = OS.get_executable_path().get_base_dir().get_base_dir()
	if OS.get_cmdline_user_args().has("--mama-test"):
		return directory.path_join("tests/learned-mappings-%d.json" % OS.get_process_id())
	return directory.path_join("learned-mappings.json")

func validated_observation(species_id: int, stop: Dictionary) -> Dictionary:
	if not by_id.has(species_id): return {}
	for field in ["location", "scene", "container", "object_name", "object_scene"]:
		if not stop.get(field) is String: return {}
	for field in ["area_id", "object_id"]:
		var number = stop.get(field)
		if not (number is int or number is float) or not is_finite(float(number)) or number < 0 or number != floor(number): return {}
	var label = LABELS.get(stop.location, "")
	if not by_id[species_id].locations.get(label, {}).has(str(int(stop.area_id))): return {}
	for candidate in area_index.get("%s:%d" % [stop.location, int(stop.area_id)], []):
		if candidate.scene == stop.scene and candidate.container == stop.container and int(candidate.object_id) == int(stop.object_id) and candidate.object_name == stop.object_name and candidate.object_scene == stop.object_scene:
			var result = candidate.duplicate(true)
			result.search_mode = "mapped"
			result.evidence = "confirmed_live_wild_encounter"
			result.live_verified = true
			return result
	return {}

func load_observations():
	if not FileAccess.file_exists(observation_path()): return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(observation_path()))
	if not parsed is Dictionary or not parsed.get("records") is Array: return
	for record in parsed.records:
		if not record is Dictionary or not record.get("stop") is Dictionary: continue
		if not (record.get("species_id") is int or record.get("species_id") is float): continue
		if not is_finite(float(record.species_id)) or record.species_id != floor(record.species_id): continue
		var stop = validated_observation(int(record.species_id), record.stop)
		if stop.is_empty(): continue
		learned_records.append({"species_id": int(record.species_id), "stop": stop, "seen_utc": str(record.get("seen_utc", ""))})

func observe_wild(species_id: int, stop: Dictionary, kind: String) -> bool:
	if kind != "Wild": return false
	var verified = validated_observation(species_id, stop)
	if verified.is_empty(): return false
	for record in learned_records:
		if int(record.species_id) == species_id and record.stop.scene == verified.scene and record.stop.container == verified.container and int(record.stop.object_id) == int(verified.object_id): return false
	learned_records.append({"species_id": species_id, "stop": verified, "seen_utc": Time.get_datetime_string_from_system(true)})
	var file = FileAccess.open(observation_path(), FileAccess.WRITE)
	if file == null:
		mapping_error = "Learned mapping is available in memory but could not be saved."
	else:
		file.store_string(JSON.stringify({"version": 1, "records": learned_records}, "\t"))
		file.flush()
		if file.get_error() != OK: mapping_error = "Could not finish saving learned mappings."
	return true

func index_names():
	by_name.clear()
	by_id.clear()
	for entry in entries:
		by_name[entry.name.to_lower()] = entry
		by_id[int(entry.id)] = entry

func refresh_runtime():
	# Runtime schedules take precedence. New families can use inspected areas.
	for meta in Server.Miscrits:
		if meta.names.is_empty(): continue
		merge_metadata({"id": meta.id, "name": meta.names[0], "names": Array(meta.names), "rarity": meta.rarity, "locations": meta.locations.duplicate(true)})

func merge_metadata(meta: Dictionary):
	var entry = by_id.get(int(meta.id), {})
	if entry.is_empty():
		entry = {"stops": []}
		entries.append(entry)
	else:
		by_name.erase(entry.name.to_lower())
	entry.merge(meta, true)
	by_name[entry.name.to_lower()] = entry
	by_id[int(entry.id)] = entry

func search_stops(entry: Dictionary) -> Array:
	var result = []
	for label in entry.get("locations", {}):
		var location = LABELS.find_key(label)
		if location == null: continue
		for area in entry.locations[label]:
			var mapped = entry.get("stops", []).filter(func(s): return s.location == location and int(s.area_id) == int(area))
			for record in learned_records:
				if int(record.species_id) != int(entry.id): continue
				var learned = validated_observation(int(entry.id), record.stop)
				if learned.is_empty() or learned.location != location or int(learned.area_id) != int(area): continue
				if not mapped.any(func(s): return s.scene == learned.scene and s.container == learned.container and int(s.object_id) == int(learned.object_id)):
					mapped.append(learned)
			if not mapped.is_empty():
				result.append_array(mapped)
			else:
				result.append_array(area_index.get("%s:%d" % [location, int(area)], []))
	return result

func suggestions(query: String) -> Array:
	query = query.strip_edges().to_lower()
	if query.length() < 3: return []
	var matches = []
	for entry in entries:
		var name = entry.name.to_lower()
		var rank = 0.0
		if name.begins_with(query): rank = 3.0
		elif query in name: rank = 2.0
		elif query.length() >= 5:
			var similarity = name.similarity(query)
			if similarity >= 0.65: rank = similarity
		if rank > 0: matches.append({"entry": entry, "rank": rank})
	matches.sort_custom(func(a,b): return a.entry.name < b.entry.name if a.rank == b.rank else a.rank > b.rank)
	return matches.slice(0, 30).map(func(item): return item.entry)

func access_error(stop: Dictionary, achievements: Dictionary, tickets: Dictionary, events: Array) -> String:
	var gate = data.get("teleports", {}).get(stop.location, {})
	var required = gate.get("requirement", "")
	var ticket = gate.get("ticket", "")
	if not required.is_empty() and not achievements.get(required, false): return "Locked: " + required
	if not ticket.is_empty() and not tickets.get(ticket, false): return "Ticket required: " + ticket
	if stop.location == "miscrian_jungle" and not "vi_intro_nox_talk" in events and not achievements.get("magicite_warden", false): return "Locked: Volcano Island introduction"
	if stop.location == "monks_mountain" and not "visit_monks_mountain" in events: return "Visit Monks Mountain first"
	if stop.location == "moon" and int(stop.area_id) == 2 and not achievements.get("singularitas", false): return "Locked: singularitas"
	if stop.location == "shack" and int(stop.area_id) >= 3 and not achievements.get("ylil_nosaj", false): return "Locked: ylil_nosaj"
	if stop.location == "temple" and int(stop.area_id) >= 4 and not achievements.get("the_temple_trial", false): return "Locked: the_temple_trial"
	return ""

func stop_error(entry: Dictionary, stop: Dictionary, weekday: int, achievements: Dictionary, tickets: Dictionary, events: Array) -> String:
	var locations = entry.get("locations", {})
	var areas = locations.get(LABELS.get(stop.location, ""), {})
	if not areas.has(str(int(stop.area_id))): return "Location changed; mapping needs an update"
	var days = areas[str(int(stop.area_id))]
	if not days is Array: return "Availability data is invalid"
	# JSON numbers are floats; Array.has uses strict types for membership.
	if not days.is_empty() and not days.any(func(day): return int(day) == weekday): return "Unavailable today (UTC schedule)"
	return access_error(stop, achievements, tickets, events)

func plan(names: Array, current_location: String, weekday: int, achievements: Dictionary, tickets: Dictionary, events: Array) -> Dictionary:
	var stops = []
	var statuses = {}
	var seen = {}
	for raw in names:
		var name = str(raw).strip_edges().to_lower()
		if not by_name.has(name):
			statuses[name] = "Name is not in the catalog"
			continue
		var entry = by_name[name]
		if entry.get("locations", {}).is_empty():
			statuses[name] = "Location unknown"
			continue
		var options = []
		var errors = []
		for stop in search_stops(entry):
			var error = stop_error(entry, stop, weekday, achievements, tickets, events)
			if error.is_empty(): options.append(stop)
			elif not error in errors: errors.append(error)
		if options.is_empty():
			statuses[name] = "; ".join(errors) if not errors.is_empty() else "Area is not mapped in this client"
			continue
		# Pick one accessible location per species, preferring the current map.
		var selected = options[0].location
		for stop in options:
			if stop.location == current_location: selected = current_location
		statuses[name] = "Ready: " + LABELS.get(selected, selected)
		if options.any(func(s): return s.location == selected and s.get("search_mode", "mapped") == "area_scan"):
			statuses[name] = "Area scan: " + LABELS.get(selected, selected) + " (exact spawn unconfirmed)"
		for stop in options:
			if stop.location != selected: continue
			var key = "%s:%d:%s:%d" % [stop.location, int(stop.area_id), stop.container, int(stop.object_id)]
			if seen.has(key):
				stops[seen[key]].targets.append(name)
				continue
			var item = stop.duplicate(true)
			item.targets = [name]
			seen[key] = stops.size()
			stops.append(item)
	return {"stops": stops, "statuses": statuses}
