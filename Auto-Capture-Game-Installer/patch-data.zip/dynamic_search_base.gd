extends Node

var config = {}
var enabled = false
var area_ref: WeakRef
var objects = {}
var cooldowns = {}
var cursor = 0
var active_object_id = -1
var match_id = ""
var pending_search = false
var encounter_checked = false
var leaving = false
var next_action = 0
var deadline = 0
var elapsed = 0.0
var status_label: Label

func _ready():
	var overlay = CanvasLayer.new()
	overlay.layer = 100
	add_child(overlay)
	status_label = Label.new()
	status_label.position = Vector2(12, 12)
	status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_label.add_theme_color_override("font_color", Color.YELLOW)
	status_label.add_theme_color_override("font_shadow_color", Color.BLACK)
	status_label.add_theme_constant_override("shadow_offset_x", 2)
	status_label.add_theme_constant_override("shadow_offset_y", 2)
	overlay.add_child(status_label)
	if not OS.get_cmdline_user_args().has("--mama-test"):
		arm()

func config_path() -> String:
	return OS.get_executable_path().get_base_dir().get_base_dir().path_join("hunt-config.json")

func validate_config(value) -> String:
	if not value is Dictionary:
		return "Configuration must be a JSON object."
	if value.get("mode") not in ["single", "multiple"]:
		return "Mode must be single or multiple."
	var ids = value.get("object_ids")
	var names = value.get("miscrits")
	if not ids is Array or ids.is_empty():
		return "Enter at least one object ID."
	var seen = []
	for id in ids:
		if not (id is int or id is float) or not is_finite(float(id)) or id < 0 or id != floor(id) or id > 2147483647:
			return "Object IDs must be nonnegative whole numbers."
		if int(id) in seen:
			return "Object IDs must not repeat."
		seen.append(int(id))
	if not names is Array or names.is_empty():
		return "Enter at least one Miscrit name."
	for name in names:
		if not name is String or name.strip_edges().is_empty():
			return "Miscrit names must be nonempty strings."
	if value.mode == "single" and (ids.size() != 1 or names.size() != 1):
		return "Single mode requires exactly one object and one Miscrit name."
	var rating = value.get("min_rating")
	if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18:
		return "Minimum rating must be a number from 0 to 18."
	return ""

func apply_config(value) -> String:
	var error = validate_config(value)
	if not error.is_empty():
		return error
	config = value.duplicate(true)
	for i in range(config.object_ids.size()):
		config.object_ids[i] = int(config.object_ids[i])
	for i in range(config.miscrits.size()):
		config.miscrits[i] = config.miscrits[i].strip_edges().to_lower()
	return ""

func arm():
	enabled = false
	var file = FileAccess.open(config_path(), FileAccess.READ)
	if file == null:
		stop("Cannot read hunt-config.json. Run Configure Search.")
		return
	var parser = JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		stop("Invalid JSON configuration: " + parser.get_error_message())
		return
	var error = apply_config(parser.data)
	if not error.is_empty():
		stop(error)
		return
	area_ref = null
	objects.clear()
	cooldowns.clear()
	cursor = 0
	active_object_id = -1
	match_id = ""
	pending_search = false
	encounter_checked = false
	leaving = false
	next_action = 0
	enabled = true
	announce("armed", "Search any configured object once to start. F8 pauses/reloads.")

func announce(event: String, message: String, extra: Dictionary = {}):
	var summary = ""
	if not config.is_empty():
		summary = "Objects %s | %s | rating >= %s\n" % [str(config.object_ids), ", ".join(config.miscrits), str(config.min_rating)]
	status_label.text = "Dynamic search: " + summary + message
	var details = {"message": message, "object_id": active_object_id, "config": config}
	details.merge(extra, true)
	Server._study_response_log("search_hunt_" + event, details)

func stop(reason: String):
	enabled = false
	announce("stopped", reason + " [F8 to reload settings and re-arm]")

func _input(event):
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F8:
		if enabled:
			stop("Paused.")
		else:
			arm()
		get_viewport().set_input_as_handled()

func bind_objects(object) -> bool:
	var area = object.get_parent()
	var found = {}
	for id in config.object_ids:
		if id >= area.get_child_count():
			stop("Object %d does not exist in this search area." % id)
			return false
		var candidate = area.get_child(id)
		if not candidate is Node2D or not candidate.has_method("can_search") or not candidate.has_method("check_user_entered"):
			stop("Object %d is not searchable in this area." % id)
			return false
		found[id] = weakref(candidate)
	area_ref = weakref(area)
	objects = found
	return true

func on_search_request(object_id: int):
	if not enabled:
		return
	if object_id not in config.object_ids:
		if area_ref != null:
			stop("An object outside the configured list was searched.")
		return
	if not is_instance_valid(WorldManager.player):
		stop("Player is unavailable.")
		return
	var object = WorldManager.player.searching_object
	if not is_instance_valid(object) or object.get_index() != object_id:
		stop("Cannot identify the selected object.")
		return
	if area_ref == null:
		if not bind_objects(object):
			return
	elif area_ref.get_ref() != object.get_parent() or objects[object_id].get_ref() != object:
		stop("Search area changed.")
		return
	active_object_id = object_id
	cursor = (config.object_ids.find(object_id) + 1) % config.object_ids.size()
	pending_search = true
	match_id = ""
	encounter_checked = false
	leaving = false
	deadline = Time.get_ticks_msec() + 60000
	announce("search", "Searching object %d. F8 pauses." % object_id)

func on_search_result(object_id: int, result: Dictionary):
	if not enabled or object_id != active_object_id or not pending_search:
		return
	var data = result.get("data", {})
	if not data is Dictionary:
		stop("Unexpected search response.")
		return
	if result.get("success", false) and data.has("matchId") and not str(data.matchId).is_empty():
		match_id = str(data.matchId)
		return
	pending_search = false
	if data.get("cooldown", false) or data.get("drop", false):
		if data.get("cooldown", false):
			cooldowns[object_id] = Time.get_ticks_msec() + 31000
		next_action = Time.get_ticks_msec() + 1000
		announce("waiting", "Object %d is cooling down; checking the configured objects." % object_id)
	else:
		stop("Search failed, was disabled, or reached its limit.")

# Both conditions must match the SAME Miscrit. Floats are compared numerically.
func classify_encounter(miscrits: Array) -> String:
	if miscrits.is_empty():
		return "unknown"
	var unknown = false
	for miscrit in miscrits:
		if not miscrit is Dictionary or not miscrit.get("name") is String or miscrit.name.strip_edges().is_empty():
			unknown = true
			continue
		if miscrit.name.strip_edges().to_lower() not in config.miscrits:
			continue
		var rating = miscrit.get("rating")
		if not (rating is int or rating is float) or not is_finite(float(rating)) or rating < 0 or rating > 18:
			unknown = true
			continue
		if rating >= config.min_rating:
			return "match"
	return "unknown" if unknown else "miss"

func on_encounter(miscrits: Array):
	if not enabled or match_id.is_empty() or Server.current_battle_id != match_id:
		return
	match classify_encounter(miscrits):
		"match":
			announce("found", "TARGET FOUND! Name and rating match; battle left open.", {"miscrits": miscrits})
			stop("Target found. Battle left open for you.")
		"unknown":
			stop("Encounter name or target rating is missing/invalid; battle left open.")
		"miss":
			encounter_checked = true
			announce("flee_pending", "Name/rating did not match; waiting for a turn to flee.", {"miscrits": miscrits})

func on_flee_result(success: bool):
	if enabled and encounter_checked and Server.current_battle_id == match_id:
		leaving = success
		deadline = Time.get_ticks_msec() + 60000
		next_action = Time.get_ticks_msec() + 2000
		announce("flee_result", "Returning to search the next available object." if success else "Flee failed; retrying on an available turn.")

func next_available_object(now: int):
	for offset in range(config.object_ids.size()):
		var id = config.object_ids[(cursor + offset) % config.object_ids.size()]
		var object = objects[id].get_ref()
		if not is_instance_valid(object) or not object.is_inside_tree() or object.get_parent() != area_ref.get_ref() or object.get_index() != id:
			stop("A configured object was removed or changed; rebind this area.")
			return null
		if object.is_visible_in_tree() and object.can_search() and now >= cooldowns.get(id, 0):
			return object
	return null

func teleport_to_object(player, object):
	# Keep the character slightly below the object rather than inside its sprite.
	player.teleport(object.global_position + Vector2(0, 24))
	announce("teleport", "Moving to object %d." % object.get_index(), {"destination_object_id": object.get_index()})

func prepare_object(player, object) -> bool:
	if config.mode == "multiple":
		teleport_to_object(player, object)
	if not object.check_user_entered():
		stop("Player is outside the object's search range.")
		return false
	return true

func _process(delta):
	elapsed += delta
	if elapsed < 0.25:
		return
	elapsed = 0.0
	if not enabled or area_ref == null:
		return
	var now = Time.get_ticks_msec()
	var battle = BattleAnimator.battle
	if is_instance_valid(battle):
		if Server.spectator or Server.current_battle_id != match_id:
			stop("An unrelated battle is open.")
			return
		if now > deadline:
			stop("Battle response timed out.")
			return
		if not encounter_checked or leaving or now < next_action:
			return
		if battle.battle_type != "Wild" or battle.winner != "" or battle.captured != null:
			stop("Battle state changed.")
			return
		if battle.processing_queue or not battle.action_queue.is_empty() or battle.action_bar.block.visible:
			return
		if not Server.socket.is_connected_to_host():
			stop("Connection lost.")
			return
		next_action = now + 2000
		battle.action_bar.do_flee()
		return
	if pending_search:
		if encounter_checked and leaving:
			pending_search = false
			match_id = ""
			encounter_checked = false
		elif now > deadline:
			stop("Search or battle response timed out.")
			return
		else:
			return
	var area = area_ref.get_ref()
	if not is_instance_valid(area) or not area.is_inside_tree():
		stop("Search area is no longer loaded.")
		return
	if not is_instance_valid(WorldManager.player) or Server.Player == null:
		stop("Player is unavailable.")
		return
	if now < next_action or WorldManager.move_locked() or WorldManager.player.is_searching or not WorldManager.player.allow_click:
		return
	if not area.is_visible_in_tree() or not area.get("searchable"):
		return
	if Server.Player.all_miscrits_dead():
		stop("Heal your team before continuing.")
		return
	var object = next_available_object(now)
	if object == null:
		return
	if not prepare_object(WorldManager.player, object):
		return
	pending_search = true
	deadline = now + 60000
	next_action = now + 1000
	WorldManager.user_want_search(object)
