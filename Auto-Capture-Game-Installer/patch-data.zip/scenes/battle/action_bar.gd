extends Control
class_name ActionBar

signal ability_pressed

@export var pvp: bool = false
@export var type: String
@export var team: BattleTeam

@onready var ability_buttons: Array[Node] = %abilities.get_children()
@onready var items: Array[Node] = %items.get_children()
@onready var containers = [%abilities, %items]

@onready var left: DefaultChanger = %left
@onready var right: DefaultChanger = %right
@onready var emptybg: PanelContainer = %emptybg
@onready var message: MultiLineLabel = %message
@onready var canvas: CanvasGroup = %canvas
@onready var block: Control = %block
@onready var flee: FleeButton = %flee

var pagination_active = load("res://assets/scenes/battle/v2/PaginationActive.png")
var pagination_inactive = load("res://assets/scenes/battle/v2/PaginationInactive.png")
var tab_active = load("res://assets/scenes/battle/v2/TabButtonActive.png")
var tab_inactive = load("res://assets/scenes/battle/v2/TabButtonInactive.png")

var curr_miscrit: BattleMiscrit
var opp_miscrit: BattleMiscrit
var miscrits: Array[BattleMiscrit]
var locked: bool = false
var potions: Array[Potion]

var config = {"items": setup_items, "abilities": setup_abilities}

var max_pages: int = 0
var tab: String = "abilities"
var page: int = 0:
	set(value):
		page = value
		set_changer_opacity()


func _ready():
	for node in [left, right]:
		node.pressed.connect(_on_changer_pressed.bind(node.name))

	for node in ability_buttons:
		node.pressed.connect(_on_ability_pressed.bind(node.get_index()))

	for node in items:
		node.pressed.connect(_on_item_pressed.bind(node.get_index()))
		
	for node in %tabs.get_children():
		node.pressed.connect(_on_tab_change.bind(node.name))
		
	Server.on_switch_miscrit.connect(lock_input)

func spectate():
	%tabs.visible = false
	%spectate.visible = true

func lock_input():
	canvas.self_modulate.a = 0.7
	block.visible = true
	if not Server.spectator:
		flee.disable()


func unlock_input():
	toggle_ready()
	canvas.self_modulate.a = 1.0
	block.visible = false
	flee.enable()


func set_changer_opacity():
	left.visible = tab != "miscrits"
	right.visible = tab != "miscrits"
	left.modulate.a = 0.5 if page == 0 else 1.0
	left.disabled = page == 0
	right.modulate.a = 0.5 if page >= max_pages - 1 else 1.0
	right.disabled = page >= max_pages - 1


func _on_changer_pressed(direction: String):
	if direction == "left" and page > 0:
		page -= 1
		config[tab].call()
	elif direction == "right" and page < max_pages - 1:
		page += 1
		config[tab].call()

	update_pagination()

func update_pagination():
	for child in %pagination.get_children():
		child.queue_free()
	
	for i in range(max_pages):
		var indicator = TextureRect.new()
		if i == page:
			indicator.texture = pagination_active
		else:
			indicator.texture = pagination_inactive
		
		%pagination.add_child(indicator)

func set_current_miscrit(selected_miscrit: BattleMiscrit):
	curr_miscrit = selected_miscrit
	page = 0
	_on_tab_change("abilities")


func set_opponent_miscrit(opponent_miscrit: BattleMiscrit):
	opp_miscrit = opponent_miscrit
	if curr_miscrit:
		setup_abilities()


func toggle_ready():
	for ability in ability_buttons:
		ability.recharge()


func setup_abilities():
	var curr = curr_miscrit.curr_abilities.slice(page * 4, (page + 1) * 4)
	for i in range(4):
		if i > curr.size() - 1:
			ability_buttons[i].visible = false
		else:
			ability_buttons[i].visible = true
			ability_buttons[i].setup(curr[i], curr_miscrit, opp_miscrit)


func setup_items():
	if ["Platinum", "Random", "Daily"].has(type):
		%tabs.get_child(1).visible = false
		return
		
	if potions.size() == 0:
		emptybg.visible = true
		
	if type != "GlobalBoss":
		potions = potions.filter(func(p: Potion): return p.type != "GlobalBoss")
		
	var curr = potions.slice(page * 4, (page + 1) * 4)
	for i in range(4):
		if i > curr.size() - 1:
			items[i].visible = false
		else:
			items[i].visible = true
			items[i].setup(curr[i], curr_miscrit)

func _on_tab_change(_tab: String):
	tab = _tab
	for container in containers:
		container.visible = tab == container.name
		
	for node in %tabs.get_children():
		node.texture_normal = tab_active if node.name == tab else tab_inactive

	emptybg.visible = false
	page = 0
	
	if tab == "abilities":
		max_pages = ceili(curr_miscrit.curr_abilities.size() / 4.0)
		config[tab].call()
	elif tab == "items":
		max_pages = ceili(potions.size() / 4.0)
		config[tab].call()
	
	set_changer_opacity()
	update_pagination()


func recharge_abilities():
	curr_miscrit.recharge_abilities()
	for ability in ability_buttons:
		ability.recharge()


func _on_ability_pressed(idx: int):
	lock_input()
	team.lock()
	var id = ability_buttons[idx].ability.id
	await Server.send_battle_state(BattleEnum.Opcode.ABILITY, {"id": id})
	ability_pressed.emit()


func _on_item_pressed(idx: int):
	lock_input()
	team.lock()
	await Server.send_battle_state(BattleEnum.Opcode.POTION, {"id": items[idx].potion.id})

func start_recharge(id: int, miss: bool):
	for ability in ability_buttons:
		if not ability.visible:
			continue
		if ability.ability.id == id:
			ability.start_recharge(pvp, miss)
			return
	
	for ability in curr_miscrit.curr_abilities:
		if ability.id == id:
			ability.start_recharge(pvp, miss)
			return


func play_ability(data: Dictionary, player: bool = false):
	var initiator = curr_miscrit if player else opp_miscrit
	var miss = data["actions"][0].type == "Miss"
	if player:
		start_recharge(data["id"], miss)
	var crit = 0
	for action in data.get("actions", []):
		if action.type == "Attack":
			crit = action.get("crit", 0)
			if crit: break
	update_message(initiator.get_ability_text(data["id"], crit, miss))


func update_message(text: String):
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(message, "modulate:a", 0.0, 0.2)
	tween.tween_callback(func(): message.position.x = 60.0)
	tween.tween_callback(func(): message.modulate.a = 1.0)
	tween.tween_callback(func(): message.text = text)
	tween.tween_callback(func(): message.update())
	tween.tween_property(message, "position:x", 2.0, 0.12).set_ease(Tween.EASE_IN_OUT)


func _on_flee_button_pressed() -> void:
	if Server.spectator:
		BattleAnimator.kill_battle_animator()
		BattleAnimator.kill_animate_scene_gd()
		BattleAnimator.kill_overlay_sprite()
		owner.flee_battle()
		return
		
	var _message = tr('GBATTLE_FLEE_MESSAGE')
	if type == "Wild":
		_message = tr('GBATTLE_FLEE_WARNING') % _message
	
	Main.show_popup(
		_message, tr('GCONFIRM'), tr('GYES'), true,
		tr('GNO'), do_flee, func(): return
	)
	
func do_flee():
	lock_input()
	team.lock()
	await Server.send_battle_state(BattleEnum.Opcode.FLEE, {})
