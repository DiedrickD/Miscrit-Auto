extends Control
class_name BattleSprites

var wild: bool = false

@onready var foe_miscrit: Sprite2D = %foe
@onready var player_miscrit: Sprite2D = %player

func setup(_wild: bool = false):
	wild = _wild


func faint(side: String):
	var node: MiscritSprite = player_miscrit if side == "player" else foe_miscrit
	
	if BattleAnimator.is_animation_rewritten(node.current_name, "faint"):
		await BattleAnimator.play_rewritten_animation(node.current_name, "faint", node)
	else:
		await Server._study_play_animation(node.animation_player, "faint")


func switch(side: String):
	var node: MiscritSprite = player_miscrit if side == "player" else foe_miscrit
	await Server._study_play_animation(node.animation_player, "return")
