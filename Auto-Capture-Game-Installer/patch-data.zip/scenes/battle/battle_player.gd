extends Node
class_name BattlePlayer

var user_id: String
var username: String = ""
var level: int = 0
var miscrits: Array[BattleMiscrit] = []
var potions: Array[Potion]
var wild: bool = false
var battle_type: String

var miscrit_sprite: MiscritSprite
var battle_team: BattleTeam

var opponent: BattlePlayer
var action_bar: ActionBar
var team_order: Array[int]
var switches: int = 0
var clan: Variant

var current_miscrit: BattleMiscrit
var current_container: BattleContainerV2

signal on_switch_miscrit
signal battle_ended(winner: String)


func _init(data: Dictionary, sprite: MiscritSprite, _container: BattleContainerV2, team: BattleTeam, _action_bar: ActionBar, pvp: bool, _battle_type: String) -> void:
	user_id = data.user_id
	username = data.username
	level = data.level
	battle_type = _battle_type
	clan = data.clan
	wild = (["Wild", "Boss", "GlobalBoss"].has(battle_type)) and user_id == "Wild"
	team_order.assign(data.team_order)

	for miscrit in data.miscrits:
		miscrits.append(BattleMiscrit.new(miscrit, pvp, wild, battle_type))

	miscrit_sprite = sprite
	battle_team = team
	action_bar = _action_bar
	current_miscrit = miscrits[0]
	current_container = _container
	current_container.setup(current_miscrit)
	battle_team.setup(miscrits)

	for potion in data.get("potions", []):
		var pot = Potion.new(potion["potion"], potion["quantity"])
		pot.used = potion.get('used', false)
		potions.append(pot)
	
	potions.sort_custom(func(a, b): return a.level < b.level)
	
	# In case of reconnect
	current_container.restore_statuses(data['buffs'], data['status'])
	current_container.add_bomb_effects(data["bombs"])
	restore_cooldowns(data['cooldowns'])
	restore_uses(data['uses'])
	
	if data.get('switches', 0) > 1:
		current_container.add_status_effects({"Switch": {"type": "Switch", "turns": data['switches']}})

func restore_cooldowns(cooldowns: Dictionary):
	for miscrit in miscrits:
		var cds: Dictionary = cooldowns.get("%d" % miscrit.id, {})
		miscrit.restore_cooldowns(cds)

func restore_uses(uses: Dictionary):
	for miscrit in miscrits:
		var max_uses: Dictionary = uses.get("%d" % miscrit.id, {})
		miscrit.restore_uses(max_uses)


func set_opponent(opp: BattlePlayer):
	opponent = opp

func has_alive_crits():
	for miscrit in miscrits:
		if miscrit.id == current_miscrit.id:
			continue
		if miscrit.chp > 0:
			return true
	return false


func play_ability(id: int, flip_target: bool = false):
	if Server._capture_skip_skill_animation():
		return
	var ability: Ability = current_miscrit.get_ability_by_id(id)
	var target_sprite
	var ability_type = ability.type
	var ability_name = ability.name
	
	if flip_target:
		target_sprite = opponent.miscrit_sprite if ability.target == "Self" else miscrit_sprite
	else:
		target_sprite = miscrit_sprite if ability.target == "Self" else opponent.miscrit_sprite
		
	var animation_name = BattleAnimator.get_gd_animation_name(ability_name)
	var animation_exist = BattleAnimator.gd_animation_exists(animation_name) and Settings.settings.get('fx',true)
	var default_amimation_needed = true

	if ability_type == "Attack":
		var ability_element = ability.element.to_lower()
		if ability_element != "physical":
			await BattleAnimator.overlay_sprite(miscrit_sprite, ability_element)
			default_amimation_needed = false
		else:
			if animation_exist: # if not exist aadefaultattack plays
				SoundManager.play_once('effects/action_attack')
				await BattleAnimator.play_animation(miscrit_sprite, "attack")
				default_amimation_needed = false

	elif ability_type in ["Negate", "Confuse", "Sleep", "Paralyze"]:
		await BattleAnimator.overlay_sprite(miscrit_sprite, "special")
		default_amimation_needed = false

	elif ability_type in ["Buff"]:
		if ! animation_exist:
			SoundManager.play_once('effects/action_attack')
			await BattleAnimator.play_animation(miscrit_sprite, "attack")
			animation_name = 'aabuff'

	await Server._study_battle_delay(0.05)

	if animation_exist:
		if animation_name in BattleAnimator.self_forbidden:
			if target_sprite == miscrit_sprite:
				await BattleAnimator.animate_scene_gd(miscrit_sprite,target_sprite,'aadefaultattack')
			else:
				await BattleAnimator.animate_scene_gd(miscrit_sprite,target_sprite,animation_name)
		else:
			await BattleAnimator.animate_scene_gd(miscrit_sprite,target_sprite,animation_name)
	elif animation_name == 'aabuff':
			var script = load('res://scenes/battle/effects/effects/impact_%s/impact.gd'%[animation_name]).new(miscrit_sprite,target_sprite,animation_name,ability.keys,ability.ap)
			await script.finished
			script.queue_free()
	elif default_amimation_needed:
		await BattleAnimator.animate_scene_gd(miscrit_sprite,target_sprite,'aadefaultattack')


func use_potion(id: int, opp: bool = false):
	var target_sprite = opponent.miscrit_sprite if opp else miscrit_sprite
	if battle_type != "GlobalBoss":
		await BattleAnimator.overlay_sprite(target_sprite, "special")
	else:
		BattleAnimator.hit_sprite(target_sprite, "white", 0.055, 0.2, 0.145, 0.87)
	if user_id == Server.Player.user_id:
		var idx = potions.find_custom(func(p: Potion): return p.id == id)
		potions[idx].quantity -= 1
		potions[idx].used = true
		Server.Player.update_inventory("potions", potions[idx], -1)
		action_bar.setup_items()


func receive_actions(action: Dictionary, hits: int = -1):
	var cd: float = 0.35
	var ignore_cd: bool = false
	match action["type"]:
		"Attack":
			await receive_damage(action, hits)
			ignore_cd = true
		"Buff":
			if action.get("reflected", false):
				await opponent.play_print(tr("BATTLE_ACTION_DEBUFF_REFLECTED"))
				await Server._study_battle_delay(0.2)
			await receive_buff(action)
			ignore_cd = true
		"Miss":
			await play_print(tr("BATTLE_ACTION_MISS_IMMUNE" if action.get("immune", false) else "BATTLE_ACTION_MISS"))
		"Faint":
			await faint_miscrit(action)
		"ForceSwitch":
			if action["id"] == -1:
				await play_print(tr("BATTLE_ACTION_CANNOT_SWITCH"))
			else:
				await play_print(tr("BATTLE_ACTION_FORCE_SWITCHED"))
				if action.get('switches', 0) > 3:
					await Server._study_battle_delay(0.3)
				await switch_miscrit_to(action)
		"Negate":
			await receive_negate()
		"Heal":
			await receive_heal(action)
		"Sleep", "Confuse", "Paralyze", "Antiheal":
			await play_print(tr(Constants.status_texts.get(action["type"], action["type"]+'.')), "yellow")
			await receive_status(action)
			if "immunity" in action and action["immunity"]:
				var immune_dict = {
					"type": action["type"][0].to_upper() + "I", "turns": action["immunity"]
				}
				await receive_status(immune_dict)
			cd = 0.3
		"Poison", "Hot", "Dot", "AI", "CI", "SI", "PI", "Block", "Barbed", "Bleed", "SwitchCurse", "Ethereal", "Disease":
			if action["turns"] != 0:
				await play_print(tr(Constants.status_texts.get(action["type"], action["type"]+'.')), "yellow")
				await Server._study_battle_delay(0.3)
			await receive_status(action)
			cd = 0.2
		"Bot":
			var text = "Buff Over Time" if action["ap"] > 0 else "Debuff Over Time"
			await play_print(text, "yellow")
			await Server._study_battle_delay(0.3)
			await receive_status(action)
			cd = 0.2
		"PoisonDamage", "DotDamage", "BleedDamage", "SwitchCurseDamage", "DiseaseDamage":
			await receive_damage(action)
			action["type"] = action["type"].replace("Damage", "")
			await receive_status(action)
			ignore_cd = true
		"BarbedDamage":
			await Server._study_battle_delay(0.3)
			await receive_damage(action)
		"BlockDamage":
			await play_print("Blocked %d Damage" % action["blocked"])
			action["type"] = action["type"].replace("Damage", "")
			await receive_status(action)
		"HotHeal":
			await receive_heal(action)
			action["type"] = action["type"].replace("Heal", "")
			await receive_status(action)
		"HotAntiheal":
			await receive_damage(action)
			action["type"] = action["type"].replace("Antiheal", "")
			await receive_status(action)
		"AntihealDamage" when int(action.get("damage", 0)) != 0:
			await play_print(tr("BATTLE_ACTION_ANTIHEAL"), "red")
			await Server._study_battle_delay(0.3)
			await receive_damage(action)
		"Immune":
			await play_print("%s Immune!" % action["immunity"])
		"Woken":
			await receive_status({"type": "Sleep", "turns": 0})
		"Cleanser":
			current_miscrit.handicap = false
			current_miscrit.paralyzed = false
			current_miscrit.bleeding = 0
			current_miscrit.diseases = []
			await play_print(tr("BATTLE_ACTION_NEGATIVE_EFFECTS_REMOVED"), "green")
			await current_container.receive_cleanser()
		"Purge":
			current_miscrit.negated = false
			await play_print(tr("BATTLE_ACTION_POSITIVE_EFFECTS_REMOVED"), "red")
			await current_container.receive_purge()
			action_bar.setup_abilities()
		"EtherealBlock":
			await play_print("Blocked %s Damage!" % action.block)
		"TimeBomb":
			await play_print("%s Bomb in %d turns" % [action.element, action.turns])
			await current_container.add_bomb_effects([action])
		"TimeBombDamage":
			await receive_damage(action)
			ignore_cd = true
		"Special":
			pass
		_:
			pass
	
	if cd > 0.0 and not ignore_cd:
		await Server._study_battle_delay(cd)


func receive_buff(effects: Dictionary):
	var messages = Utils.process_battle_buffs(effects)
	for message in messages:
		await play_print(message)
		await Server._study_battle_delay(0.3)
	if not effects.get('stats', null):
		return
	current_container.add_status_effects(effects.stats, effects.maxKeys)


func process_status_effects(type = "round"):
	current_container.process_effects(type)


func receive_damage(attack: Dictionary, _hits: int = -1):
	var hits = attack.get("hits", 1)
	if _hits != -1:
		hits = _hits
	if attack["damage"] == 0:
		if attack["type"] == "Attack":
			await Server._study_battle_delay(0.2)
			await play_print(tr("BATTLE_ACTION_NO_EFFECT"))
			await Server._study_battle_delay(0.2)
		return
	await play_print("-%d" % attack["damage"], "red")
	await update_active_hp(attack["damage"])
	var cd = clamp(1.0 / hits, 0.35, 0.6)
	if attack.get("crit", 1) != 1.0:
		await Server._study_battle_delay(0.2666) 
		await play_print(tr("BATTLE_ACTION_CRITICAL" if attack["crit"] == 2 else "BATTLE_ACTION_WEAK"))
		cd = cd * 0.75 # - If thats crit make it 25% faster
	
	await Server._study_battle_delay(cd)


func receive_negate():
	await play_print(tr("BATTLE_ACTION_ELEMENTAL_WEAKNESS_REMOVED"))
	current_miscrit.negated = true
	current_container.add_status_effects({"Negate": {"type": "Negate", "turns": - 1}})
	action_bar.setup_abilities()


func receive_status(action: Dictionary):
	if action["type"] == "Paralyze":
		current_miscrit.paralyzed = true
	if action["type"] == "Sleep" or action["type"] == "Confuse":
		current_miscrit.handicap = true
	if action["type"] != "Bot":
		current_container.add_status_effects({action["type"]: action})
	else:
		for key in action["keys"]:
			var new_action = JSON.parse_string(JSON.stringify(action))
			new_action["stat"] = key
			current_container.add_status_effects({new_action["type"]: new_action})


func receive_heal(data: Dictionary):
	if data["ap"] == 0:
		return
	await play_print(tr("BATTLE_ACTION_PLUS_X_HEALTH") % data["ap"], "green")
	update_active_hp(-1 * data["ap"])


func receive_capture(captured: bool):
	if not captured:
		await BattleAnimator.animate_scene_gd(opponent.miscrit_sprite,miscrit_sprite, "capture_fail")
		current_miscrit.attempts += 1
	else:
		current_miscrit.captured = true
		await BattleAnimator.animate_scene_gd(opponent.miscrit_sprite,miscrit_sprite, "capture")


func play_print(text: String, type: String = ""):
	if Server._study_fast_combat():
		return
	var node: BattleText = load("res://scenes/battle/battle_text.tscn").instantiate()
	node.setup(text, type)
	center_label(node)


func center_label(node: BattleText):
	miscrit_sprite.get_parent().get_parent().get_parent().add_child(node)
	var spawn_global_position:Vector2 = miscrit_sprite.get_fake_global_position()
	await Server.get_tree().process_frame
	if miscrit_sprite.texture == null:
		node.global_position = spawn_global_position + Vector2(0.0, -90)
	else:
		node.global_position = Vector2(spawn_global_position.x, miscrit_sprite.get_height_at(0.5) + 10)


func faint_miscrit(action: Dictionary, force: bool = false):
	current_miscrit.bleeding = 0
	current_miscrit.diseases = []
	if !current_miscrit.captured:
		if BattleAnimator.is_animation_rewritten(miscrit_sprite.current_name, "faint"):
			await BattleAnimator.play_rewritten_animation(miscrit_sprite.current_name, "faint", miscrit_sprite)
		else:
			await Server._study_play_animation(miscrit_sprite.animation_player, "faint")
	if action["id"] != -1:
		if action["dead"] != current_miscrit.id:
			push_error("Current miscrit ID doesn't match %d, %d" % [action["dead"], current_miscrit.id])
		else:
			if current_miscrit.chp > 0 and !current_miscrit.captured:
				await update_active_hp(current_miscrit.chp, true)
			await _switch_current_miscrit(action["id"])
	else:
		if force:
			await update_active_hp(current_miscrit.chp)
		battle_ended.emit(action["winner"])


func switch_miscrit_to(data: Dictionary):
	if data.get('switches', 0) > 3:
		var damage = 15 + (data['switches'] - 4) * 5
		await play_print(tr("BATTLE_ACTION_SWITCH_PENALTY"), "red")
		await Server._study_battle_delay(0.3)
		await play_print("-%d" % damage, "red")
		await update_active_hp(damage)
		await Server._study_battle_delay(0.3)
		
	if current_miscrit.chp <= 0:
		current_miscrit.bleeding = 0
		current_miscrit.diseases = []
		if BattleAnimator.is_animation_rewritten(miscrit_sprite.current_name, "faint"):
			await BattleAnimator.play_rewritten_animation(miscrit_sprite.current_name, "faint", miscrit_sprite)
		else:
			await Server._study_play_animation(miscrit_sprite.animation_player, "faint")
	
	if current_miscrit.chp != 0:
		await Server._study_play_animation(miscrit_sprite.animation_player, "return")
	
	await _switch_current_miscrit(data["id"])
	if data.get('switches', 0) > 1:
		current_container.add_status_effects({"Switch": {"type": "Switch", "turns": data['switches']}})


func _switch_current_miscrit(switch_to: int):
	current_miscrit.clear_status()
	if user_id == Server.Player.user_id or Server.spectator:
		current_miscrit.reset_abilities()
	var i = miscrits.find_custom(func(miscrit: BattleMiscrit): return miscrit.id == switch_to)
	current_miscrit = miscrits.pop_at(i)
	miscrits.insert(0, current_miscrit)
	var switched_miscrit = miscrits.pop_at(1)

	var last_alive_index = -1
	for j in range(miscrits.size()):
		if miscrits[j].chp > 0:
			last_alive_index = j
	
	if last_alive_index >= 0:
		miscrits.insert(last_alive_index + 1, switched_miscrit)
	else:
		miscrits.append(switched_miscrit)
	
	battle_team.setup(miscrits, true)
	miscrit_sprite.setup(current_miscrit)
	current_container.clear_statuses()
	current_container.setup(current_miscrit)
	await Server._study_battle_delay(1.0)
	on_switch_miscrit.emit()
	
func update_active_hp(damage: int, wait: bool = false):
	await current_miscrit.update_hp(damage)
	await current_container.update_hp(wait)

func remove_switch_penalty():
	current_container.remove_switch_penalty()
	

func mark_seen():
	for miscrit in miscrits:
		miscrit.mark_seen(battle_type == "Wild")


func flee():
	for miscrit in miscrits:
		Server.Player.miscrits[miscrit.id].chp = miscrit.chp
	Server.Player.set_prop("team", Server.Player.team)
	await Server._study_play_animation(miscrit_sprite.animation_player, "run")
	miscrit_sprite.animation_player.stop()
	

func current_name():
	return current_miscrit.name.to_lower().replace(' ', '_')
