extends CanvasLayer
class_name Battle

@onready var settings: TextureButton = $Control/ui/settings

@onready var player_active_miscrit: BattleContainerV2 = %player_active_miscrit
@onready var foe_active_miscrit: BattleContainerV2 = %foe_active_miscrit
@onready var player_team: BattleTeam = %player_team
@onready var foe_team: BattleTeam = %foe_team

@onready var battle_miscrits: BattleSprites = %battle_miscrits
@onready var background: TextureRect = %background
@onready var ui_control: Control = %ui
@onready var action_bar: ActionBar = %ActionBar
@onready var capture_control: CaptureControl = %capture_control
@onready var player_avatar: BattleAvatar = %player_avatar
@onready var foe_avatar: BattleAvatar = %foe_avatar

@onready var player_miscrit: MiscritSprite = %battle_miscrits.player_miscrit
@onready var foe_miscrit: MiscritSprite = %battle_miscrits.foe_miscrit

@onready var effects_behind: Control = %effects_behind
@onready var effects_above: Control = %effects_above

@onready var main_activity_layer: Control = $Control/main_activity_layer
@onready var control: Control = $Control
@onready var timer: Timer = %timer

@onready var player_relics: HBoxContainer = %player_relics
@onready var foe_relics: HBoxContainer = %foe_relics

var is_waiting_for_response: bool = false

var battle_type: String
var player: BattlePlayer
var foe: BattlePlayer
var wild: bool = true
var winner: String
var pvp: bool = false
var campaign: bool = false
var npc: bool = false

var captured: Captured
var miscripedia: Miscripedia
var action_queue = []
var processing_queue = false
var _capture_rx_sequence = 0
var battle_started: bool = false
var curr_user_id: String
var spectators: Array = []

var multihits: Array[int] = [1201, 1068, 781]

func _enter_tree() -> void:
	print("enter tree")
	BattleAnimator.activate_battle_animator()
	UiManager.release_all_inputs_block()
	Notifications.enter_battle()
	WorldManager.acquire_move_lock()

func _ready():
	print("loaded battle scene")
	settings.visible = !Server.Player.tutorial
	UiTweenAnimator.node_fadein_dark(control, 1.0)
	check_battle_started(10.0)
	player_miscrit.effects_above_layer = effects_above
	player_miscrit.effects_behind_layer = effects_behind
	
	foe_miscrit.effects_above_layer = effects_above
	foe_miscrit.effects_behind_layer = effects_behind
	
	UiManager.block_all_inputs('start_battle')
	action_bar.lock_input()
	if Server.spectator:
		action_bar.spectate()
	BattleAnimator.battle = self
	capture_control.capture_pressed.connect(_on_capture_pressed)
	Server.reconnected.connect(_on_connect)
	_on_connect()

func check_battle_started(max_wait: float):
	await Server._study_battle_delay(max_wait)
	if not battle_started:
		await fadein()
		SoundManager.mute_bus('World', Settings.settings.get("sfx", false))
		self.visible = false
		WorldManager.location_node.fadein_world()

		await Server.socket.leave_match_async(Server.current_battle_id)
		SoundManager.stop_sequence()
		self.queue_free()

		if !Server.socket.closed.is_connected(Server._on_socket_close):
			Server.socket.closed.connect(Server._on_socket_close)

		WorldManager.release_move_lock()
		UiManager.release_all_inputs_block()
		UiManager.battle_scene = null
		BattleAnimator.battle = null
		
		UiManager.spawn_battle(Server.current_battle_id, Server.spectator)

func _on_connect():
	spectators = []
	Server.socket.closed.connect(_on_socket_close)
	Server.socket.received_match_state.connect(_on_match_state)
	Server.socket.received_match_presence.connect(_on_match_presence)
	if Server.socket.closed.is_connected(Server._on_socket_close):
		Server.socket.closed.disconnect(Server._on_socket_close)
	var battle = await Server.socket.join_match_async(Server.current_battle_id)
	if battle.is_exception():
		Server.socket.closed.disconnect(_on_socket_close)
		Server.reconnected.disconnect(_on_connect)
		if battle.exception.status_code == 4:
			battle_started = true
			Main.show_blocking_popup("Battle ended or not found")
			flee_battle()
		else:
			push_error("Failed to join battle")
			await Main.fatal_error("battle_socket", 0, "Failed to join battle")
	else:
		set_initial_spectators(battle)

func setup_ui():
	if wild:
		player_avatar.visible = false
		foe_avatar.visible = false
		%foe_relics.visible = false
		player_active_miscrit.position.x = 0
		player_active_miscrit.position.y = 13 # default 26
		foe_active_miscrit.position.y = 13 # default 26
		%player_relics.position.y = 136 # default 149
	else:
		player_avatar.setup(player)
		foe_avatar.setup(foe)
		if player.clan:
			%player_clan.visible = true
			HttpService.load_banner(%player_banner, player.clan.tag)
			%player_tag.text = player.clan.tag
		if foe.clan:
			%foe_clan.visible = true
			HttpService.load_banner(%foe_banner, foe.clan.tag)
			%foe_tag.text = foe.clan.tag
	
	if not player_avatar.timeout.is_connected(_on_timeout):
		player_avatar.timeout.connect(_on_timeout)
		
	player_avatar.pvp = pvp
	foe_avatar.pvp = pvp
	
	action_bar.pvp = pvp or campaign
	action_bar.type = battle_type
	action_bar.potions = player.potions
	action_bar.team = player_team
	action_bar.setup_items()
	
	if not action_bar.ability_pressed.is_connected(_on_ability_pressed):
		action_bar.ability_pressed.connect(_on_ability_pressed)
	_on_foe_switch()
	_on_player_switch()
	print("setup UI")


func _on_player_switch():
	action_bar.set_current_miscrit(player.current_miscrit)
	setup_relics(player.current_miscrit, "player")


func _on_foe_switch():
	if battle_type == "Wild":
		capture_control.set_opponent_miscrit(foe.current_miscrit)
	action_bar.set_opponent_miscrit(foe.current_miscrit)
	setup_relics(foe.current_miscrit, "foe")


func spawn_battle(data: Dictionary):
	print("Spawning battle")
	battle_started = true
	battle_type = data.type
	pvp = data.pvp
	campaign = battle_type == "Campaign"
	
	if Server.spectator:
		curr_user_id = data.player1.user_id
	else:
		curr_user_id = Server.Player.user_id
		
	var curr_player = data.player1 if data.player1.user_id == curr_user_id else data.player2
	var opponent = data.player1 if data.player1.user_id != curr_user_id else data.player2
	var history_hunter = Server.get_node_or_null("MamaHunter")
	if history_hunter:
		history_hunter.on_battle_started(opponent.get("miscrits", []), battle_type, str(curr_user_id))
	if battle_type == "Wild":
		var encounter_miscrits = []
		for encounter in opponent.get("miscrits", []):
			var encounter_summary = {}
			for key in ["mId", "name", "level", "rating", "hp", "chp"]:
				if encounter.has(key):
					encounter_summary[key] = encounter[key]
			encounter_miscrits.append(encounter_summary)
		Server._study_response_log("wild_encounter", {"miscrits": encounter_miscrits, "capture_chance": data.get("capture_chance", null)})
		var hunter = Server.get_node_or_null("MamaHunter")
		if hunter:
			hunter.on_encounter(encounter_miscrits)
	
	%miscripedia.visible = !["Boss", "GlobalBoss"].has(battle_type)
	wild = ["Wild", "Boss", "Campaign", "GlobalBoss"].has(battle_type)
	npc = opponent.user_id == "Wild"
	foe_active_miscrit.wild = wild
	foe_team.wild = battle_type == "Wild"
	foe_team.show_xp = !wild
	
	foe_active_miscrit.show_rating = battle_type == "Wild"
	
	foe = BattlePlayer.new(opponent, foe_miscrit, foe_active_miscrit, %foe_team, action_bar, pvp or campaign, battle_type)
	player = BattlePlayer.new(curr_player, player_miscrit, player_active_miscrit, %player_team, action_bar, pvp or campaign, battle_type)
	foe.set_opponent(player)
	player.set_opponent(foe)
	foe.mark_seen()

	player.on_switch_miscrit.connect(_on_player_switch)
	player.battle_ended.connect(_end_battle)
	foe.on_switch_miscrit.connect(_on_foe_switch)
	foe.battle_ended.connect(_end_battle)
	
	player_team.lock()

	battle_miscrits.setup(wild)
	
	match battle_type:
		"Boss":
			var foe_current_name = foe.current_name()
			if foe_current_name in Constants.boss_name_to_battle_properties:
				if Constants.boss_name_to_battle_properties[foe_current_name]["player_use_house"]:
					player_miscrit.suffix = "house"
		
		"GlobalBoss":
			player_miscrit.suffix = "house"
		
	
	if (battle_type == "Boss" and foe.current_name().ends_with("_elementum")) or battle_type == "GlobalBoss":
		player_miscrit.suffix = "house"
		
	background.load_background(battle_type, foe)
	SoundManager.play_current_battle_sound(battle_type, foe)
	setup_ui()
	
	if data.get("time_left", null):
		if data["next_turn"] == player.user_id:
			player_avatar.start_countdown(data['time_left'])
		else:
			foe_avatar.start_countdown(data['time_left'])
	
	if data.get("pending", false):
		foe.current_miscrit.captured = true
		spawn_captured(data.stars)
	
	print("spawned battle, animation enter")
	await animate_enter()


func animate_enter():
	await Server._study_battle_delay(0.4)
	await ui_control.animate_enter()
	if battle_type == "Wild":
		capture_control.setup()
	UiManager.release_inputs_block('start_battle')
	await Server._study_battle_delay(0.4)
	player_miscrit.setup(player.current_miscrit)
	player_relics.modulate.a = 1
	
	if battle_type == "Boss" and foe.current_name() == "ylil_nosaj":
		await Server._study_battle_delay(0.4)
		SoundManager.play_once("battle_special/ylil_nosaj_background_fade", "SFX")
		%background_additional.texture = load("res://assets/backgrounds/boss/shack.jpg")
		%background_additional.self_modulate.a = 0.0
		var tween: Tween = create_tween().set_speed_scale(Server._study_tween_speed())
		tween.tween_property(%background_additional, "self_modulate:a", 1.0, 2.0).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
		await tween.finished
		await Server._study_battle_delay(0.4)
	else:
		await Server._study_battle_delay(0.8)
	foe_miscrit.setup(foe.current_miscrit)
	if BattleAnimator.is_animation_rewritten(foe_miscrit.current_name, "spawn"):
		await foe_miscrit.rewritten_animation_finished
	await Server._study_battle_delay(0.8)
	foe_relics.modulate.a = 1
	print("Animate entered")
	
func setup_relics(miscrit: BattleMiscrit, side: String):
	if side == "foe" and wild:
		return

	var relics = player_relics if side == "player" else foe_relics
	var count = 0

	for i in miscrit.relic_slots:
		var relic = miscrit.relics.get(i, null)
		relics.get_child(i).setup(false, relic)
		count += 1

	while count < 4:
		relics.get_child(count).setup(true, null)
		count += 1

func _on_timeout():
	action_bar.lock_input()
	player_team.lock()
	
func _on_match_state(state: NakamaRTAPI.MatchData):
	var data = JSON.parse_string(state.data)
	var opcode = int(state.op_code)
	
	_capture_rx_sequence += 1
	var received_ms = Time.get_ticks_msec()
	Server._study_response_log("battle_response", {"match_id": Server.current_battle_id, "rx": _capture_rx_sequence, "opcode": opcode, "opcode_name": Server._capture_opcode_name(opcode), "data": data})
	action_queue.push_back({"data": data, "opcode": opcode, "rx": _capture_rx_sequence, "received_ms": received_ms})
	if not processing_queue:
		processing_queue = true
		call_deferred("process_action_queue")

func process_action_queue():
	while not action_queue.is_empty():
		var action = action_queue.pop_front()
		var started_ms = Time.get_ticks_msec()
		var before = Server._capture_snapshot(self)
		var original_data = action.data.duplicate(true) if action.data is Dictionary else action.data
		if action.opcode == BattleEnum.Opcode.START and action.data is Dictionary:
			Server._capture_register_start(action.data)
		Server._study_fast_processing = action.opcode in [BattleEnum.Opcode.ABILITY, BattleEnum.Opcode.CONFUSE, BattleEnum.Opcode.SLEEP, BattleEnum.Opcode.HANDICAP]
		await process_single_action(action.data, action.opcode)
		Server._study_fast_processing = false
		var after = Server._capture_snapshot(self)
		Server._study_response_log("battle_applied", {"match_id": Server.current_battle_id, "rx": action.rx, "opcode": action.opcode, "opcode_name": Server._capture_opcode_name(action.opcode), "queue_ms": started_ms - action.received_ms, "processing_ms": Time.get_ticks_msec() - started_ms, "before": before, "after": after})
		var capture_hunter = Server.get_node_or_null("MamaHunter")
		if capture_hunter:
			capture_hunter.on_battle_event(original_data, action.opcode, before, after)
	
	processing_queue = false

func process_single_action(data: Variant, opcode: int):
	var initiator: BattlePlayer
	var receiver: BattlePlayer
	
	if pvp and opcode != BattleEnum.Opcode.START:
		is_waiting_for_response = false
		timer.stop()
	
	if !BattleEnum.INFO_CODES.has(opcode):
		initiator = player if player.user_id == data["user_id"] else foe
		receiver = foe if player.user_id == data["user_id"] else player
		player_avatar.stop_countdown()
		foe_avatar.stop_countdown()
	
	match opcode:
		BattleEnum.Opcode.START:
			await spawn_battle(data)

		BattleEnum.Opcode.SWITCH:
			await initiator.switch_miscrit_to(data)

		BattleEnum.Opcode.ABILITY, BattleEnum.Opcode.CONFUSE:
			action_bar.play_ability(data, data["user_id"] == player["user_id"])
			await initiator.play_ability(data["id"], data.get("flip", false))

		BattleEnum.Opcode.POTION:
			var curr_action = data.actions[0]
			await action_bar.update_message(tr('GACTION_BAR_MISCRIT_USED_ACTION') % [initiator.current_miscrit.get_name(), ctr.get_potion_name(curr_action.name)])
			await Server._study_battle_delay(0.5)
			await initiator.use_potion(data["id"], curr_action.get("target", null) == receiver.user_id)
			if curr_action.get("msg", null):
				await initiator.play_print(curr_action["msg"])
		
		BattleEnum.Opcode.FLEE:
			var hunter = Server.get_node_or_null("MamaHunter")
			if hunter:
				hunter.on_flee_result(bool(data.get("success", false)))
			if not data["success"]:
				await player.play_print(tr('BATTLE_ACTION_COULDNT_RUN_AWAY'))
				await Server._study_battle_delay(1)
			else:
				await player.flee()
				flee_battle()

		BattleEnum.Opcode.SLEEP, BattleEnum.Opcode.READY:
			pass

		BattleEnum.Opcode.CAPTURE:
			capture_control.toggle(true)
			capture_control.visible = !data.captured
			await receiver.receive_capture(data.captured)
			if data.captured:
				spawn_captured(data.stars)

		BattleEnum.Opcode.CAPTURE_CONTINUE:
			captured = null
			if foe.miscrits.size() == 1:
				await Server._study_battle_delay(0.2)
			Ui.finish_tutorial_step()
			play_current_sound_again(0.2)

		BattleEnum.Opcode.ERROR:
			fatal_error()
			return

		BattleEnum.Opcode.END:
			captured = null
			Server.socket.received_match_state.disconnect(_on_match_state)
			Server.socket.received_match_presence.disconnect(_on_match_presence)
			show_summary(data)
			return

		BattleEnum.Opcode.TERMINATE:
			Server.socket.received_match_state.disconnect(_on_match_state)
			Server.socket.received_match_presence.disconnect(_on_match_presence)
			var victor = player if data["loser"] == foe.user_id else foe
			var loser = foe if data["loser"] == foe.user_id else player
			winner = victor.user_id
			await loser.faint_miscrit({"id": - 1, "winner": victor.user_id}, pvp)
			show_summary(data)
			return
		
		BattleEnum.Opcode.INVALID:
			printerr("Error in battle: %s" % data['msg'])
		
		BattleEnum.Opcode.DISCONNECT:
			await Main.show_popup(tr('UBATTLE_OPPONENT_DISCONNECTED_ERROR'), tr('GERROR'), tr('GEXIT'), false, null, _animate_battle_exit)
			return
	
	if pvp and initiator and !BattleEnum.PENALTY_CODES.has(opcode):
		initiator.remove_switch_penalty()
	
	for action in data.get("actions", []):
		var idx = int(data.get('id', -1))
		var hits = data['actions'].size() if multihits.has(idx) else -1
		if action.target == receiver.user_id:
			await receiver.receive_actions(action, hits)
		else:
			await initiator.receive_actions(action, hits)
	
	if data.get("turns", null) == 0:
		await Server._study_battle_delay(0.3)
		foe.process_status_effects()
		player.process_status_effects()
		if !data.get("captured", false):
			action_bar.recharge_abilities()
	else:
		if data.get("actions", []).size() == 0:
			await Server._study_battle_delay(0.2)
	

	if initiator:
		initiator.process_status_effects("turn")

	if data.get("next_turn", null):
		if data["next_turn"] == player.user_id:
			if !player.current_miscrit.handicap and !data.get("pending", false):
				if !data.get("time_left", null):
					player_avatar.start_countdown(30)
				await Server._study_battle_delay(0.1)
				printt("Player turn, secs", player_avatar.curr_secs, data.get("time_left", -1))
				if !pvp or player_avatar.curr_secs > 0:
					action_bar.unlock_input()
					if !player.current_miscrit.paralyzed:
						player_team.unlock()
					capture_control.toggle(false)
					if Server.spectator:
						action_bar.update_message("%s is deciding what to do." % player.username)
					else:
						action_bar.update_message(tr('GACTION_BAR_YOUR_TURN'))
					Ui.finish_tutorial_step()
		else:
			capture_control.toggle(true)
			if !foe.current_miscrit.handicap and !npc:
				if !data.get("time_left", null):
					foe_avatar.start_countdown(30)
				var message = tr('GACTION_BAR_PLAYER_DECIDING_WHAT_TO_DO') % foe.username
				action_bar.update_message(message)
	
	if battle_type == "Wild":
		capture_control.set_chance(data.get("capture_chance", 0))
	
	if opcode != BattleEnum.Opcode.READY:
		if Server._study_fast_combat():
			await Server.send_battle_state(BattleEnum.Opcode.READY, {})
		else:
			Server.send_battle_state(BattleEnum.Opcode.READY, {})
		
		if pvp and opcode != BattleEnum.Opcode.START:
			is_waiting_for_response = true
			timer.start(2)
		
		
func _on_ready_retry_timeout():
	if is_waiting_for_response:
		Server.send_battle_state(BattleEnum.Opcode.READY, {})
		timer.start(2)
		

func play_current_sound_again(wait_time: float):
	await Server._study_battle_delay(wait_time)
	if !winner:
		SoundManager.play_current_battle_sound(battle_type, foe)


func _on_ability_pressed():
	capture_control.toggle(true)
	Ui.finish_tutorial_step()

func spawn_captured(stats: Dictionary):
	captured = load("res://scenes/popup/captured.tscn").instantiate()
	SoundManager.play_main("ui/captured")
	UiManager.add_node_to_ui(captured)
	captured.setup(foe.current_miscrit, stats)

func show_summary(data: Dictionary):
	timer.stop()
	if miscripedia:
		miscripedia._on_exit_pressed()
	%miscripedia.disable()
	while !winner:
		await Server._study_battle_delay(0.3)
	if captured:
		captured._on_exit_pressed()
	player_avatar.stop_countdown()
	foe_avatar.stop_countdown()
	await Server._study_battle_delay(0.5)
	var summary: BattleSummary = load("res://scenes/battle/battle_summary.tscn").instantiate()
	await UiManager.add_node_to_ui(summary)

	summary.continued.connect(_animate_battle_exit)
	var player_rewards = data.get(player.user_id, {})
	await summary.setup(winner, battle_type, player, foe, player_rewards)
	var capture_hunter = Server.get_node_or_null("MamaHunter")
	if capture_hunter:
		capture_hunter.on_summary_ready(summary, winner)


func _end_battle(_winner: String):
	winner = _winner
	capture_control.visible = false
	%ui_animator.play("exit")
	if battle_type == "Boss" and winner == player.user_id:
		Server.Player.boss_defeated(foe.current_name())
	if winner == player.user_id:
		var victory = get_victory_music()
		if battle_type == "Boss":
			await SoundManager.play_custom_main(victory)
		else:
			await SoundManager.play_sequence([victory, "ui/results"])
	else:
		await SoundManager.play_sequence(["ui/loss", "ui/results"])

func get_victory_music():
	if battle_type != "Boss":
		return "ui/victory"
	else:
		var foe_current_name: String = foe.current_name()
		if foe_current_name in Constants.boss_name_to_battle_properties:
			return "battles/" + Constants.boss_name_to_battle_properties[foe_current_name]["victory_sound"]
		else:
			return "ui/victory"

func _on_capture_pressed():
	action_bar.lock_input()
	player_team.lock()
	Ui.finish_tutorial_step()


func reset_objects():
	if player:
		for miscrit in player.miscrits:
			miscrit.reset_after_battle()
	if foe:
		for miscrit in foe.miscrits:
			miscrit.reset_after_battle()


func flee_battle() -> void:
	_animate_battle_exit()
	
func set_initial_spectators(battle):
	spectators = []
	var label = JSON.parse_string(battle.label)
	var players = label.players
	for presence in battle.presences:
		if !players.has(presence.user_id) and !spectators.has(presence.username):
			spectators.append(presence.username)
	
	set_spectators()
	
func _on_match_presence(p_presence: NakamaRTAPI.MatchPresenceEvent):
	if not player or not foe:
		return

	for leave in p_presence.leaves:
		if player and player.user_id == leave.user_id:
			continue
		if foe and foe.user_id == leave.user_id:
			continue
		spectators.erase(leave.username)
	
	for join in p_presence.joins:
		if player and player.user_id == join.user_id:
			continue
		if foe and foe.user_id == join.user_id:
			continue
		if !spectators.has(join.username):
			spectators.append(join.username)
	
	set_spectators()

func set_spectators():
	%spectators.visible = spectators.size() > 0
	%spectate_count.text = "%d" % spectators.size()

func _on_socket_close():
	if captured:
		captured._on_exit_pressed()
	if miscripedia:
		miscripedia._on_exit_pressed()
	Server.socket.received_match_state.disconnect(_on_match_state)
	Server.socket.received_match_presence.disconnect(_on_match_presence)
	Server.socket.closed.disconnect(_on_socket_close)
	UiManager.add_node_to_ui(load("res://scenes/popup/retry_battle_socket.tscn").instantiate())
	
	
func fatal_error():
	await Main.fatal_error("battle_socket", 0, "Fatal error during battle")


func _animate_battle_exit():
	UiManager.block_all_inputs('exiting_battle')
	if Ui.finish_tutorial_step():
		await get_tree().create_timer(0.8).timeout
	reset_objects()
	Main.fade_exit_from_batle.emit()
	if Settings.get_setting('fx', true):
		await ScreenTransition.screen_transition(2)
	else:
		await fadein()
		SoundManager.mute_bus('World', Settings.settings.get("sfx", false))
	self.visible = false
	WorldManager.location_node.fadein_world()
	UiManager.release_inputs_block('exiting_battle')
	await Server.socket.leave_match_async(Server.current_battle_id)
	SoundManager.stop_sequence()
	self.queue_free()


func _on_miscripedia_button_pressed() -> void:
	miscripedia = load("res://scenes/miscripedia/miscripedia.tscn").instantiate()
	UiManager.add_node_to_ui(miscripedia)
	miscripedia._on_evo_click(foe.current_miscrit.metadata, foe.current_miscrit.get_evo(), true)


func _exit_tree() -> void:
	if not battle_started:
		return
	
	Main.exit_battle.emit(battle_type, foe.current_name())
	
	if player:
		player.free()
	if foe:
		foe.free()
	
	Server.current_battle_id = ""
	Server.spectator = false
	if !Server.socket.closed.is_connected(Server._on_socket_close):
		Server.socket.closed.connect(Server._on_socket_close)
	
	check_fallen_miscrits()

	WorldManager.release_move_lock()
	UiManager.release_all_inputs_block()
	UiManager.battle_scene = null
	BattleAnimator.battle = null
	Notifications.exit_battle()
	
func check_fallen_miscrits():
	if battle_type == "Wild" and Server.Player.level < 20 and Server.Player.all_miscrits_dead():
		Notifications.show_blocking_popup(load("res://scenes/popup/fallen_miscrits.tscn").instantiate())

func fadein(): # It's Only for case when user disabled transition
	%color_fill.visible = true
	%color_fill.modulate.a = 0.0
	await UiTweenAnimator.node_fadein_alpha(%color_fill, 0.2)
	%color_fill.visible = false


func _on_spectators_mouse_entered() -> void:
	var tooltip = "    Spectators:    \n"
	for spectator in spectators:
		tooltip += "%s\n" % spectator
	tooltip = tooltip.rstrip("\n")
	UiManager.spawn_tooltip(tooltip)
	

func _on_spectators_mouse_exited() -> void:
	UiManager.delete_tooltip()

func _on_player_clan_mouse_entered() -> void:
	UiManager.spawn_tooltip(player.clan.name)

func _on_player_clan_mouse_exited() -> void:
	UiManager.delete_tooltip()

func _on_foe_clan_mouse_entered() -> void:
	UiManager.spawn_tooltip(foe.clan.name)

func _on_foe_clan_mouse_exited() -> void:
	UiManager.delete_tooltip()
