extends Control
class_name BattleTeam

@export var wild: bool = false
@export var opp: bool = false
@export var show_xp: bool = true

@onready var bg = %bg

var bg_large = load("res://assets/scenes/battle/v2/BenchedPanelLarge.png")
var bg_small = load("res://assets/scenes/battle/v2/BenchedPanelSmall.png")
var benched_large = "res://scenes/battle/benched_miscrit_large.tscn"
var benched_large_rev = "res://scenes/battle/benched_miscrit_large_rev.tscn"

func _ready():
	if opp:
		%arrow.flip_h = true
		%direction.flip_h = true
		layout_direction = Control.LAYOUT_DIRECTION_RTL
	else:
		layout_direction = Control.LAYOUT_DIRECTION_LTR
	
	%touch.visible = OS.has_feature("mobile")
	Server.on_switch_miscrit.connect(lock)
	%small_block.visible = Server.spectator

func setup(_miscrits: Array[BattleMiscrit], _lock: bool = false):
	Main.children_clear(%large)
	Main.children_clear(%small)

	if _miscrits.size() == 1:
		visible = false
		return
	else:
		visible = true	
	
	for miscrit in _miscrits.slice(1, 4):
		var large_node: BenchedMiscritLarge = load(benched_large_rev if opp else benched_large).instantiate()
		var small_node: BenchedMiscritSmall = load("res://scenes/battle/benched_miscrit_small.tscn").instantiate()

		%large.add_child(large_node)
		%small.add_child(small_node)
		
		large_node.show_rating = wild
		large_node.show_xp = show_xp
		large_node.setup(miscrit, opp)
		small_node.show_rating = wild
		small_node.setup(miscrit, opp)
		
		if _lock:
			large_node.lock()
			small_node.lock()
		
	if %large.visible:
		_on_arrow_pressed()
	
	if opp:
		lock()

func lock():
	for node in %large.get_children():
		node.lock()
	
	for node in %small.get_children():
		node.lock()

func unlock():
	for node in %large.get_children():
		node.unlock()
	
	for node in %small.get_children():
		node.unlock()

var state_small: bool = true
var tween: Tween

func _on_arrow_pressed() -> void:
	if is_instance_valid(tween):
		return
	
	state_small = !state_small
	if state_small:
		toggle_bar(false)
		%direction.texture = load("res://assets/scenes/battle/v2/ArrowDirectionRight.png")
		if Server.spectator:
			%small_block.visible = true
			%large_block.visible = false
	else:
		toggle_bar(true)
		%direction.texture = load("res://assets/scenes/battle/v2/ArrowDirectionLeft.png")
		if Server.spectator:
			%small_block.visible = false
			%large_block.visible = true

func toggle_bar(large: bool):
	if large:
		bg.texture = bg_large
		bg.patch_margin_right = 32
		bg.patch_margin_bottom = 32
		if opp:
			bg.scale.x = -1
		set_bar_size(222)
		%timer.start(20)
	else:
		bg.texture = bg_small
		bg.patch_margin_right = 10
		bg.patch_margin_bottom = 10
		if opp:
			bg.scale.x = -1
		set_bar_size(80)

func set_bar_size(width: float):
	tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(%bg, "size:x", width, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)
	if state_small:
		move_child(%small, 1)
		tween.parallel().tween_property(%large, "modulate:a", 0.0, 0.075)
		tween.parallel().tween_callback(func(): %large.visible = false).set_delay(0.15)
		tween.parallel().tween_callback(func(): %small.visible = true)
		%small.modulate.a = 1.0
	else:
		move_child(%small, 1)
		%large.modulate.a = 0.0
		tween.parallel().tween_callback(func(): %large.visible = true).set_delay(0.1)
		tween.parallel().tween_property(%large, "modulate:a", 1.0, 0.15).set_delay(0.1)
		tween.parallel().tween_callback(func(): %small.visible = false).set_delay(0.25)
		
	if opp:
		var pos: float = 216
		$bg.position.x = pos
		tween.parallel().tween_property(%arrow,"position:x", pos - width - %arrow.size.x, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)
		%touch.position.x = pos - width - %touch.size.x + 10
	else:
		tween.parallel().tween_property(%arrow, "position:x", width, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)
		%touch.position.x = width - 10
	await tween.finished
	tween = null

func _on_arrow_mouse_entered() -> void:
	%arrow.modulate = Color(1.2, 1.2, 1.2)


func _on_arrow_mouse_exited() -> void:
	%arrow.modulate = Color(1.0, 1.0, 1.0)


func _on_touch_pressed() -> void:
	_on_arrow_pressed()


func _on_timer_timeout() -> void:
	if %large.visible:
		_on_arrow_pressed()
	%timer.stop()
