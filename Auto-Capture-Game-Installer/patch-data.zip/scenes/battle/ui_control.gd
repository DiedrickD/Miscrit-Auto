extends Control

@onready var animation_player: AnimationPlayer = %ui_animator


func animate_enter():
	await Server._study_play_animation(animation_player, "enter")
