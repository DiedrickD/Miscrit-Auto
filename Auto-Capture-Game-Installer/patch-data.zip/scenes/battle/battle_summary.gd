extends PopupMain
class_name BattleSummary

signal continued


func setup(winner: String, type: String, player1: BattlePlayer, player2: BattlePlayer, summary: Dictionary = {}):
	if winner != Server.Player.user_id:
		%title_text.text = "GBATTLE_SUMMARY_LOSE_HEADER"
		%title_text.add_theme_color_override("font_outline_color", Color("#430603"))
		%title.texture = load("res://assets/scenes/common/ButtonBGDarkRed.png")

	if type == "Duel" or type == "Random" or Server.spectator:
		%popup.size.y = 298
		%rewards_text.visible = false
		%rewards.visible = false
		await get_tree().process_frame
		UiManager.center_node(%popup)
	else:
		add_captures(summary.get("captured", []))
		set_hp(player1.miscrits, summary.get("updates", {}))
		setup_rewards(summary.get("rewards", {}))

	Utils.sort_team(player1.miscrits, player1.team_order)
	Utils.sort_team(player2.miscrits, player2.team_order)
	setup_miscrits(%player1_miscrits, player1, summary.get("updates", {}))
	setup_miscrits(%player2_miscrits, player2, {}, summary.get("damage", 0))

	%name1.text = player1.username
	%name2.text = "" if (type == "Wild" or type == "Campaign") else player2.username
	%name2.text = "Global Boss" if type == "GlobalBoss" else %name2.text
	
	if Server.spectator:
		%title.visible = false
		%player1_winner.visible = winner == player1.user_id
		%player2_winner.visible = winner != player1.user_id
		
	await Server._study_battle_delay(0.2)
	%continue.visible = true


func add_captures(miscrits: Array):
	for miscrit in miscrits:
		Server.Player.insert_captured_miscrit(miscrit)


func set_hp(miscrits: Array[BattleMiscrit], updates: Dictionary):
	for miscrit in miscrits:
		var xp = updates.get("%d" % miscrit.id, 0)
		var curr_miscrit = Server.Player.miscrits.get(miscrit.id, null)
		if curr_miscrit:
			curr_miscrit.update_xp(xp)
			curr_miscrit.chp = miscrit.chp
	Server.Player.set_prop("team", Server.Player.team)


func setup_miscrits(node: GridContainer, player: BattlePlayer, updates: Dictionary, damage: int = 0):
	var need_to_play = false
	var miscrits = node.get_children()
	for i in range(4):
		if i > player.miscrits.size() - 1:
			miscrits[i].visible = false
		else:
			var xp = updates.get("%d" % player.miscrits[i].id, 0)
			miscrits[i].setup(player.miscrits[i], xp, damage)
			if xp >= 1:
				need_to_play = true
	if need_to_play:
		await Server._study_battle_delay(0.5)
		SoundManager.play_once("ui/miscrit_xp")


func setup_rewards(rewards: Dictionary):
	for reward in rewards:
		if not rewards[reward]:
			continue
		var battle_reward: BattleReward = load("res://scenes/battle/battle_reward.tscn").instantiate()
		$%rewards_container.add_child(battle_reward)
		battle_reward.setup(reward, rewards[reward])


func _on_continue_pressed() -> void:
	super._on_exit_pressed()
	Server.Player.finished_battle.emit()
	continued.emit()
