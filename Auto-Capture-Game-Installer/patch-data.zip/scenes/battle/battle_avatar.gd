extends Control
class_name BattleAvatar

signal timeout()

@export var pvp: bool = false
@export var opp: bool = false
@onready var secs: Label = %secs

var curr_secs: int
var start_pos = 245.0
var end_pos = 288.0

func setup(player: BattlePlayer):
	HttpService.load_avatar(%avatar, player.user_id, null)
	%rank.text = "%d" % player.level
	if player.username.length() < 14:
		%name.text = player.username
	else:
		%name.text = player.username.split(" ")[0]
	%rank.update()
	%name.update()
	
	if opp:
		%countdown.flip_h = true
		start_pos = 3.0
		end_pos = -33.0

func start_countdown(start_secs: int):
	if !pvp: return
	%Timer.start(1)
	if start_secs <= 0:
		start_secs = 1
	secs.text = ("%02ds" if start_secs < 10 else "%ds") % start_secs
	curr_secs = start_secs
	animate_timer(end_pos)


func stop_countdown():
	if !pvp: return
	%Timer.stop()
	animate_timer(start_pos)


func _on_timer_timeout() -> void:
	curr_secs -= 1
	secs.text = ("%02ds" if curr_secs < 10 else "%ds") % curr_secs
	if curr_secs == 0:
		%Timer.stop()
		animate_timer(start_pos)
		timeout.emit()
	elif curr_secs <= 5:
		SoundManager.play_once("ui/tick_02")


func animate_timer(new_position: float) -> void:
	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_property(%countdown, "position:x", new_position, 0.2).set_ease(Tween.EASE_OUT_IN)
