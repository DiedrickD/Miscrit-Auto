extends Control
class_name SummaryMiscrit

@export var xp: bool = false

@onready var xp_label: MultiLineLabel = %xp


func _ready():
	%xp_bar.visible = xp
	if not xp:
		%hp_bar.position.y = 48


func setup(miscrit: BattleMiscrit, new_xp: int = 0, damage: int = 0):
	%miscrit_avatar.setup(miscrit, true)
	%hp_bar.update(miscrit)
	%xp_bar.update(miscrit)

	await Server._study_battle_delay(0.5)

	%captured.visible = miscrit.captured

	if new_xp > 0:
		%xp.text = "+%dxp" % new_xp
		%xp.visible = true
		%xp.update()

		await get_tree().process_frame
		xp_label.pivot_offset = xp_label.size / 2

		var tween = create_tween().set_speed_scale(Server._study_tween_speed())
		xp_label.scale = Vector2(2.5, 2.5)
		tween.tween_property(xp_label, "scale", Vector2.ONE, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
		await Server._study_battle_delay(0.22)
		%xp_bar.animate_new_xp(miscrit.xp, new_xp)
	
	if damage > 0:
		%damage.visible = true
		%damage.text = "-%d" % damage
		
		await get_tree().process_frame
		%damage.pivot_offset = %damage.size / 2

		var tween = create_tween().set_speed_scale(Server._study_tween_speed())
		%damage.scale = Vector2(2.5, 2.5)
		tween.tween_property(%damage, "scale", Vector2.ONE, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
