extends NinePatchRect
class_name BattleContainerV2

@onready var xp_bar: XpBarV2 = %xp_bar
@onready var hp_bar: HpBarV2 = %hp_bar
@onready var avatar: MiscritAvatarV2 = %avatar
@onready var status_bar: Control = %status
@onready var bombs_bar: Control = %bombs


@export var show_rating = false
@export var wild: bool = false
@export var opponent: bool = false

var miscrit: BattleMiscrit
const effect_name_rules = {"Poison": ["ap"], "Dot": ["element", "ap"], "Hot": ["ap"], "Bot": ["ap", "stat"], "Disease": ["ap"]}
const autoeffects = {
	"round": ["CI", "SI", "PI", "AI", "Antiheal", "Bot", "Ethereal"], "turn": ["Confuse", "Sleep", "Paralyze"]
}
const purge_effects = ["Hot", "CI", "SI", "AI", "PI", "Barbed", "Block", "Negate", "Ethereal"]
const cleanse_effects = ["Poison", "Antiheal", "Bleed", "Dot", "SwitchCurse", "Confuse", "Paralyze", "Disease"]


func setup(_miscrit: BattleMiscrit) -> void:
	miscrit = _miscrit
	hp_bar.setup(miscrit)
	%xp_bar.setup(miscrit)
	%avatar.show_rating = show_rating
	%avatar.wild = wild
	%avatar.setup(miscrit, false)
	%element_icon.element = miscrit.metadata.element
	%element_icon.update()
	%name.text = miscrit.get_name()
	%name.update()
	%level.text = "%d" % miscrit.level
	
	xp_bar.visible = !wild
	
	
func darken():
	if miscrit.chp <= 0:
		self_modulate = Color(0.55, 0.55, 0.55, 1.0)

func update_hp(wait: bool = false):
	if wait:
		await hp_bar.animate_update(miscrit)
	else:
		hp_bar.animate_update(miscrit)
	
func clear_statuses():
	for effect in status_bar.get_children():
		remove_effect(effect)

func remove_effect(status: StatusEffect):
	status_bar.remove_child(status)
	status.queue_free()

func remove_bomb(bomb):
	bombs_bar.remove_child(bomb)
	bomb.queue_free()

func add_effect(key: String, type: String, effect: Variant, maxed: bool = false):
	var status_effect: StatusEffect = load("res://scenes/battle/status_effect.tscn").instantiate()
	status_bar.add_child(status_effect)
	status_effect.name = key
	status_effect.setup(type, effect, maxed)
	return status_effect

func add_bomb(bomb: Dictionary):
	var bomb_effect = load("res://scenes/battle/bomb_effect.tscn").instantiate()
	bombs_bar.add_child(bomb_effect)
	bomb_effect.setup(bomb)
	return bomb_effect

func spawn_effects(effects: Array):
	for effect in effects:
		effect.get_node("%AnimationPlayer").play("spawn")

func spawn_bombs(bombs: Array):
	for bomb in bombs:
		bomb.get_node("%AnimationPlayer").play("spawn")

func add_status_effects(effects: Dictionary, max_keys = []):
	var new_effects = []
	
	if effects.has("Bleed"):
		var data = effects["Bleed"]
		if data["turns"] == 0:
			miscrit.bleeding = 0
		else:
			var dmg = data.get("ap", 0)
			miscrit.bleeding = dmg
	
	if effects.has("Disease"):
		var data = effects["Disease"]
		if data["turns"] == 0:
			miscrit.diseases = []
		else:
			var ap = data.get("ap", 0)
			if !miscrit.diseases.has(ap):
				miscrit.diseases.append(ap)
	
	for effect in effects:
		var find_name: String = effect
		var rules = effect_name_rules.get(effect, [])
		for rule in rules:
			find_name += str(effects[effect][rule])

		find_name = find_name.replace(".0", "")
		var existing_effect: StatusEffect = status_bar.get_node_or_null(find_name)
		if existing_effect:
			existing_effect.get_node("%AnimationPlayer").play("hit")
			if existing_effect.value is Dictionary:
				if effects[effect].turns == 0 or (effect == "Block" and effects[effect].ap == 0):
					if effect == "Sleep" or effect == "Confuse":
						miscrit.handicap = false
					remove_effect(existing_effect)
				else:
					existing_effect.update()
					existing_effect.setup(effect, effects[effect])
			elif effects[effect] == 0:
				remove_effect(existing_effect)
			elif effect == "acc" and effects[effect] == 100:
				remove_effect(existing_effect)
			else:
				existing_effect.setup(effect, effects[effect], max_keys.has(effect))
		else:
			var status_effect: StatusEffect = add_effect(find_name, effect, effects[effect], max_keys.has(effect))
			new_effects.append(status_effect)

	await update_positions(status_bar.get_child_count())

	spawn_effects(new_effects)

func restore_bomb_effects(bombs: Array) -> void:
	for bomb in bombs_bar.get_children():
		remove_bomb(bomb)
	await update_positions(bombs_bar.get_child_count())
	
	add_bomb_effects(bombs)

func add_bomb_effects(bombs: Array) -> void:
	var new_bombs: Array = []
	for bomb in bombs:
		var bomb_effect = add_bomb(bomb)
		new_bombs.append(bomb_effect)
	
	await update_bomb_positions(bombs_bar.get_child_count())
	spawn_bombs(new_bombs)

func restore_statuses(buffs: Dictionary, statuses: Array):
	var effects = []
	
	for effect in status_bar.get_children():
		remove_effect(effect)
	await update_positions(status_bar.get_child_count())
	
	for buff in buffs.keys():
		if buffs[buff] == 0:
			continue
		if buff == "acc" and buffs[buff] == 100:
			continue
		var status_effect: StatusEffect = add_effect(buff, buff, buffs[buff])
		effects.append(status_effect)
	
	var final_statuses = []
	for status in statuses:
		if status.type != "Bot":
			final_statuses.push_back(status)
			continue
		for key in status.keys:
			var new_status = JSON.parse_string(JSON.stringify(status))
			new_status['stat'] = key
			final_statuses.push_back(new_status)
	
	for status in final_statuses:
		var key: String = status.type
		if key == "Negate":
			miscrit.negated = true
		if key == "Paralyze":
			miscrit.paralyzed = true
		if key == "Sleep" or key == "Confuse":
			miscrit.handicap = true
		var rules = effect_name_rules.get(status.type, [])
		for rule in rules:
			key += str(status[rule])
		key = key.replace(".0", "")
		var status_effect: StatusEffect = add_effect(key, status.type, status)
		effects.append(status_effect)
		
	await update_positions(status_bar.get_child_count())
	spawn_effects(effects)
		

func receive_cleanser():
	var to_remove = []
	
	for effect in status_bar.get_children():
		if effect.value is Dictionary:
			if effect.type == "Bot" and effect.value.ap < 0:
				to_remove.append(effect)
			if cleanse_effects.has(effect.type):
				to_remove.append(effect)
		elif effect.value < 0:
			to_remove.append(effect)
	
	for remove in to_remove:
		remove_effect(remove)
	update_positions(status_bar.get_child_count())

func receive_purge():
	var to_remove = []
	
	for effect in status_bar.get_children():
		if effect.value is Dictionary:
			if effect.type == "Bot" and effect.value.ap > 0:
				to_remove.append(effect)
			if purge_effects.has(effect.type):
				to_remove.append(effect)
		elif effect.value > 0:
			to_remove.append(effect)

	for remove in to_remove:
		remove_effect(remove)
	update_positions(status_bar.get_child_count())

const value_to_position: Dictionary[int, int] = {0: 40, 1: 44, 2: 40, 3: 37, 4: 32, 5: 29, 6: 27}
const value_to_position_bombs: Dictionary[int, int] = {0: 36, 1: 40, 2: 36, 3: 33, 4: 28, 5: 25, 6: 23}

func update_positions(value: int):
	await get_tree().process_frame
	var new_position_step: float = value_to_position.get(value, -1)
	if not value in value_to_position:
		new_position_step = 170.0 / value
	if value > 0:
		var tween = create_tween().set_speed_scale(Server._study_tween_speed())
		for effect_node in status_bar.get_children():
			var effect_index = effect_node.get_index()
			var new_position = new_position_step * effect_index
			tween.parallel().tween_property(effect_node, "position:x", new_position, 0.2).set_ease(
				Tween.EASE_IN_OUT
			)
		await tween.finished

func update_bomb_positions(value: int):
	await get_tree().process_frame
	var new_position_step: float = value_to_position_bombs.get(value, -1)
	if not value in value_to_position_bombs:
		new_position_step = 134.0 / value
	if value > 0:
		var tween: Tween = create_tween().set_speed_scale(Server._study_tween_speed())
		for bomb_node in bombs_bar.get_children():
			var bomb_index: int = bomb_node.get_index()
			var new_position: float = new_position_step * bomb_index
			tween.parallel().tween_property(bomb_node, "position:x", new_position, 0.2).set_ease(
				Tween.EASE_IN_OUT
			)
		await tween.finished

func remove_switch_penalty():
	var existing_effect: StatusEffect = status_bar.get_node_or_null("Switch")
	if existing_effect:
		remove_effect(existing_effect)
	
	await update_positions(status_bar.get_child_count())
	

func process_effects(type = "round"):
	var to_remove = []
	var all_statuses = {}
	for effect in status_bar.get_children():
		all_statuses[effect.type] = effect
		if effect.type in autoeffects[type]:
			effect.value.turns -= 1
			if effect.value.turns == 0:
				if effect.type == "Paralyze":
					miscrit.paralyzed = false
				if effect.type == "Sleep" or effect.type == "Confuse":
					miscrit.handicap = false
				to_remove.append(effect)
			else:
				effect.update()
				effect.get_node("%AnimationPlayer").play("hit")
		elif effect.type == "Bleed" and effect.value.turns == 0:
			to_remove.append(effect)
		elif effect.type == "Disease" and effect.value.turns == 0:
			to_remove.append(effect)

	# If sleep and confuse both, remove sleep
	if all_statuses.has("Sleep") and all_statuses.has("Confuse"):
		to_remove.append(all_statuses["Sleep"])

	for remove in to_remove:
		remove_effect(remove)
	update_positions(status_bar.get_child_count())
	
	if type != "turn":
		return
	
	for bomb in bombs_bar.get_children():
		bomb.bomb.turns -= 1
		if bomb.bomb.turns == 0:
			remove_bomb(bomb)
		else:
			bomb.set_turns()
			bomb.get_node("%AnimationPlayer").play("hit")
	update_bomb_positions(bombs_bar.get_child_count())
