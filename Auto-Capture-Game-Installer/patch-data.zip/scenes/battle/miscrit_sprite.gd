extends Sprite2D
class_name MiscritSprite

@onready var animation_player: AnimationPlayer = $AnimationPlayer
@export var skip: bool = false
@export var max_height: int = -1
@export var max_width: int = -1
@export var battle: bool = false
@export var suffix: String = 'miscrits'

var effects_above_layer = null
var effects_behind_layer  = null
var image = null
var default_image = null
var current_name: String 

var player_position_node = null
var foe_position_node = null

signal rewritten_animation_finished

func _ready():
	self.texture_changed.connect(fix_offset)
	if battle:
		player_position_node = get_parent().get_node('%player_position')
		foe_position_node = get_parent().get_node('%foe_position')


func _on_animation_player_animation_finished(_anim_name: StringName) -> void:
	if _anim_name not in ["capture_success", "faint"]:
		animation_player.play("idle")

func setup(selected_miscrit: PlayerMiscrit, _evo: Variant = null):
	if battle:
		current_name = selected_miscrit.metadata.names[selected_miscrit.get_evo()].to_lower().replace(' ','_')
	animation_player.play("RESET")
	animation_player.stop()
	self.texture = null
	self.image = null
	var evo = _evo if _evo != null else selected_miscrit.get_evo()
	HttpService.load_miscrit_sprite(self, selected_miscrit.metadata, evo, max_width, max_height, suffix)
	if not Server._study_fast_combat():
		await animation_player.animation_finished

func set_overlay(code:String = 'white'):
	BattleAnimator.set_overlay(self,code)

func fix_offset():
	if battle:
		var sprite_new_position = get_parent().get_node( '%s_position'% self.name ).position 
		if current_name in Constants.sprite_offsets:
			var position_data: Dictionary = Constants.sprite_offsets[current_name]
			var offset_vector: Vector2 = Vector2(position_data['x'] * ( 1 if flip_h else -1 ), position_data['y'])
			if flip_h and suffix == "house":
				offset_vector *= 0.4
			sprite_new_position += offset_vector
		self.position = sprite_new_position
	if self.texture != null:
		image = texture.get_image()
		if flip_h:
			image.flip_x()
		offset.x = -texture.get_size().x / 2
		offset.y = -texture.get_size().y
		if not skip and not Server._study_fast_combat():
			if battle:
				if BattleAnimator.is_animation_rewritten(current_name, "spawn"):
					await BattleAnimator.play_rewritten_animation(current_name, "spawn", self)
					animation_player.play("idle")
				else:
					animation_player.play("spawn")
			else:
				animation_player.play("appear")
		else:
			animation_player.play("idle")
	else:
		image = null

func play_once(sound_path: String):
	BattleAnimator.play_once(sound_path, "SFX")

func add_above(node):
	effects_above_layer.add_child(node)

func add_behind(node):
	effects_behind_layer.add_child(node)


func add_above_self(node):
	self.add_child(node)

func pause():
	$AnimationPlayer.pause()

func play():
	$AnimationPlayer.play()

func get_opaque_point() -> Vector2:
	var current_image = get_image()
	var loop_count = 0
	var temp_x = 0
	var temp_y = 0
	var temp_color: Color
	var height = current_image.get_height()
	var width = current_image.get_width()
	while loop_count < 100:
		temp_x = int(randf() * width )
		temp_y = int(randf() * height )
		temp_color = current_image.get_pixel(temp_x, temp_y)
		if temp_color.a >= 0.7:
			return Vector2(temp_x-(width/2), temp_y-(height)) * scale + global_position
		loop_count += 1
	return Vector2.ZERO

func get_opaque_point_in_circle(radius: float) -> Vector2:
	var current_image = get_image()
	var loop_count = 0
	var temp_x = 0
	var temp_y = 0
	var temp_color: Color
	var height = current_image.get_height()
	var width = current_image.get_width()
	while loop_count < 100:
		var angle = randf() * TAU
		var dist = sqrt(randf()) * radius
		var offset_x = int(dist * cos(angle))
		var offset_y = int(dist * sin(angle))
		temp_x = clamp(offset_x + width / 2, 0, width - 1)
		temp_y = clamp(offset_y + height / 2, 0, height - 1)
		temp_color = current_image.get_pixel(temp_x, temp_y)
		if temp_color.a >= 0.7:
			return Vector2(temp_x - (width / 2), temp_y - (height)) * scale + global_position
		loop_count += 1
	return Vector2.ZERO

func is_opaque_pixel_at(global_coordinates: Vector2) -> bool:
	var current_image = get_image()
	var local_x = (global_coordinates.x - global_position.x) / scale.x + current_image.get_width() / 2
	var local_y = (global_coordinates.y - global_position.y) / scale.y + current_image.get_height()
	var pixel_x = int(clamp(local_x, 0, current_image.get_width() - 1))
	var pixel_y = int(clamp(local_y, 0, current_image.get_height() - 1))
	var pixel_color = current_image.get_pixel(pixel_x, pixel_y)
	return pixel_color.a >= 0.7

func get_random_width():
	return _get_width_at_percentage(randf())

func get_random_height():
	return _get_height_at_percentage(randf())

func get_height_at(percentage=0.5):
	return _get_height_at_percentage(percentage)

func get_width_at(percentage=0.5):
	return _get_width_at_percentage(percentage)

func get_center_coordinates():
	return Vector2(get_width_at(0.5),get_height_at(0.5))

func get_random_point():
	return Vector2(get_width_at(randf()),get_height_at(randf()))

func get_fake_global_position():
	if flip_h:
		return player_position_node.global_position
	else:
		return foe_position_node.global_position

func get_coordinates_point(coordinates):
	var position_coordinates = get_fake_global_position()
	if flip_h:
		coordinates.x = coordinates.x * -1
	return position_coordinates + coordinates

func get_coordinates_point_ignore(coordinates):
	var position_coordinates = get_fake_global_position()
	return position_coordinates + coordinates

func get_coordinates_point_from_center(coordinates):
	var position_coordinates = get_center_coordinates()
	if flip_h:
		coordinates.x = coordinates.x * -1
	return position_coordinates + coordinates

func get_random_point_on_circle(radius: float) -> Vector2:
	var center = get_center_coordinates()
	var angle = randf() * TAU 
	var distance = sqrt(randf()) * radius
	return center + Vector2(cos(angle), sin(angle)) * distance 

func get_random_point_on_circle_outline(radius: float) -> Vector2:
	var center = get_center_coordinates()
	var angle = randf() * TAU 
	return center + Vector2(cos(angle), sin(angle)) * radius

func expand_coordinate_y(spawn_position,value,align):
	return expand_coordinate(spawn_position,value,align)

func expand_coordinate_x(spawn_position,value,align):
	if flip_h:
		value *= -1
	return expand_coordinate(spawn_position,value,align)

func expand_coordinate(spawn_position,value,align):
	match align:
		'center':
			return [spawn_position-value/2,spawn_position+value/2]
		'upper':
			return [spawn_position-value,spawn_position]
		'lower':
			return [spawn_position,spawn_position+value]
	pass

func _get_height_at_percentage(percentage=0.5):
	var current_image = get_image()
	var height = current_image.get_height()
	var temp = height * percentage
	return (temp-(height)) * scale.y + global_position.y

func _get_width_at_percentage(percentage=0.5):
	var current_image = get_image()
	var width = current_image.get_width()
	var temp = width * percentage
	return (temp-(width/2)) * scale.x + global_position.x

func get_image():
	if image == null:
		if default_image == null:
			default_image = load('res://assets/scenes/common/default_anim_target.png').get_image()
		return default_image
	return image
