extends TextureProgressBar
class_name HpBarV2

@export var battle: bool = false

var LOW_HP_ICON = preload("res://assets/scenes/common/HPIconVeryLow.png")
var MED_HP_ICON = preload("res://assets/scenes/common/HPIconLow.png")
var HIGH_HP_ICON = preload("res://assets/scenes/common/HPIconHigh.png")
var EMPTY_HP_ICON = preload("res://assets/scenes/common/HPIconEmpty.png")

var HIGH_TEXTURE = load("res://assets/scenes/common/HPBarFillHigh.png")
var MED_TEXTURE = load("res://assets/scenes/common/HPBarFillLow.png")
var LOW_TEXTURE = load("res://assets/scenes/common/HPBarFillVeryLow.png")


func setup(miscrit: Variant):
	max_value = int(miscrit.stats.hp)
	value = clamp(miscrit.chp, 0, max_value)

	%hp.visible = !battle
	if max_value < 100_000:
		%hp.text = "%d/%d" % [value, max_value]
	else:
		%hp.text = "%d" % value
		
	var pct = value / max_value
	var icon_texture
	
	if pct < 0.66 and pct > 0.33:
		icon_texture = MED_HP_ICON
		texture_progress = MED_TEXTURE
	elif pct <= 0.33:
		if pct == 0:
			icon_texture = EMPTY_HP_ICON
		else:
			icon_texture = LOW_HP_ICON
		texture_progress = LOW_TEXTURE
	else:
		icon_texture = HIGH_HP_ICON
		texture_progress = HIGH_TEXTURE

	%icon.texture = icon_texture


func animate_update(miscrit: BattleMiscrit):
	if Server._study_fast_combat():
		setup(miscrit)
		return
	var chp = clamp(miscrit.chp, 0, max_value)
	if max_value < 100_000:
		%hp.text = "%d/%d" % [chp, max_value]
	else:
		%hp.text = "%d" % value
	var tween = Server.create_tween()
	tween.tween_property(self, "value", float(chp), 0.14).set_ease(Tween.EASE_IN_OUT)
	await tween.finished
	setup(miscrit)
