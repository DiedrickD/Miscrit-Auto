extends TextureProgressBar
class_name XpBarV2

@onready var xp_label: MultiLineLabel = %xp


func _get_gradient_point(num: float) -> float:
	return min(float(num / max_value), 1.0)


func setup(miscrit: Variant):
	if miscrit.level >= 35:
		value = 0
		max_value = 969
		xp_label.text = 'MAX'
		return

	max_value = Utils.get_exp_needed(miscrit.level)
	value = min(miscrit.xp, max_value)

	if value == max_value:
		xp_label.text = tr('UXP_READY_TO_TRAIN')
	else:
		xp_label.text = "%d/%d" % [value, max_value]

	xp_label.update()
