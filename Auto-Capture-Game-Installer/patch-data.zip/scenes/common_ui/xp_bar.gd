extends TextureProgressBar
class_name XpBar

const CUR_FILL_COLORS: Array = [Color("344AEA"), Color("3496EA")]
const NEW_FILL_COLORS: Array = [Color("5EFFDD"), Color("C7F3C9")]
const FULL_FILL_COLORS: Array = [Color("FFBF3C"), Color("FFE79B")]

@onready var xp_label: MultiLineLabel = %xp


func _get_gradient_point(num: float) -> float:
	return min(float(num / max_value), 1.0)


func update(miscrit: Variant):
	if miscrit.level >= 35:
		value = 0
		max_value = 969
		xp_label.text = tr('UXP_MAX_LEVEL')
		return

	max_value = Utils.get_exp_needed(miscrit.level)
	value = min(miscrit.xp, max_value)

	var colors: Array
	if value == max_value:
		colors = FULL_FILL_COLORS
		xp_label.text = tr('UXP_READY_TO_TRAIN')
	else:
		colors = CUR_FILL_COLORS
		xp_label.text = "%d/%d" % [value, max_value]

	set_gradient(colors)
	xp_label.update()


func set_gradient(colors: Array):
	var gradient = Gradient.new()
	gradient.add_point(0.0, colors[0])
	gradient.add_point(_get_gradient_point(value), colors[1])

	var gradient_texture = GradientTexture2D.new()
	gradient_texture.gradient = gradient
	gradient_texture.width = 256
	gradient_texture.repeat = false
	texture_progress = gradient_texture
	queue_redraw()


func ready_to_train():
	set_gradient(FULL_FILL_COLORS)
	xp_label.modulate.a = 0
	xp_label.text = tr('UXP_READY_TO_TRAIN')
	xp_label.update()
	var flash_tween = create_tween().set_speed_scale(Server._study_tween_speed())
	xp_label.modulate = Color(2.0, 2.0, 2.0, 2.0)
	flash_tween.tween_property(xp_label, "modulate", Color.WHITE, 0.3)
	flash_tween.parallel().tween_property(xp_label, "scale", Vector2(1.2, 1.2), 0.15)
	flash_tween.parallel().chain().tween_property(xp_label, "scale", Vector2.ONE, 0.15)
	SoundManager.play_once("ui/miscrit_ready_train")


func animate_new_xp(current_xp: float, new_xp: float):
	if current_xp >= max_value:
		return

	var final_xp = min(current_xp + new_xp, max_value)
	var actual_new_xp = final_xp - current_xp

	var tween = create_tween().set_speed_scale(Server._study_tween_speed())
	tween.tween_method(
		func(progress: float):
			var gradient = texture_progress.gradient
			while gradient.get_point_count() > 2:
				gradient.remove_point(2)

			xp_label.text = "%d/%d" % [current_xp + (actual_new_xp * progress), max_value]

			var transition_point = _get_gradient_point(current_xp)
			gradient.add_point(transition_point, CUR_FILL_COLORS[1])
			gradient.add_point(transition_point, NEW_FILL_COLORS[0])
			gradient.add_point(
				_get_gradient_point(current_xp + (actual_new_xp * progress)), NEW_FILL_COLORS[1]
			),
		0.0,
		1.0,
		0.5
	)

	tween.parallel().tween_property(self, "value", final_xp, 0.5)

	if final_xp == max_value:
		tween.finished.connect(func(): ready_to_train())
