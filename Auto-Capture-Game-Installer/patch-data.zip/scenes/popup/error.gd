extends PopupMain
class_name ErrorPopup


func setup(
	_title: String,
	_error: String,
	_button1: String = "GOKAY",
	_close: bool = true,
	_button2: Variant = null,
	button1_callable: Variant = null,
	button2_callable: Variant = null
):
	%title_text.text = _title
	
	%message.text = _error
	var height = %message.get_minimum_size().y

	%popup.size.y = height + 61
	%content.size.y = height + 45
	if _error != "UDUEL_REQUEST_CANCELLED_MESSAGE" and _error != "Battle ended or not found":
		%content.position.y = 8.0
	else:
		%content.position.y = -32.0
	%buttons.position.y = height + 56
	
	%close.visible = _close
	%button1.text = _button1
	
	if _button2:
		%button2.text = _button2
		%button2.pressed.connect(
			func():
				%button1.disable()
				%button2.disable()
				_on_exit_pressed()
				if button2_callable:
					button2_callable.call()
		)
	else:
		%button2.visible = false

	if _button1 == "GOKAY" or _button1 == "GRETRY":
		%button1.pressed.connect(_on_exit_pressed)
	else:
		%button1.pressed.connect(
			func():
				%button1.disable()
				%button2.disable()
				_on_exit_pressed()
				button1_callable.call()
		)


	if _title == "Notice" and not _button2 and not button1_callable and not button2_callable:
		var hunter = Server.get_node_or_null("MamaHunter")
		if hunter and hunter.has_method("watch_notification"):
			hunter.watch_notification(self, "notice")

func _on_exit_pressed() -> void:
	super._on_exit_pressed()
