extends RefCounted

var host
var cases = {}
var last_states = {}
var error = ""
var ordinal = 0
const MAX_CASES = 64
const MAX_BYTES = 65536

func directory() -> String:
	var suffix = "-%d" % OS.get_process_id() if OS.get_cmdline_user_args().has("--mama-test") else ""
	return host.config_path().get_base_dir().path_join("target-capture-diagnostics" + suffix)

func member(value: Dictionary) -> Dictionary:
	var result = {}
	for key in ["mId", "name", "level", "rating", "hp", "chp", "attempts", "captured", "handicap"]:
		if value.has(key): result[key] = value[key] if not value[key] is String else str(value[key]).left(96)
	var moves = []
	for ability in value.get("abilities", []).slice(0, 20):
		if not ability is Dictionary: continue
		var move = {}
		for key in ["id", "name", "type", "target", "element", "ap", "times", "recharge", "max_uses", "enchanted"]:
			if ability.has(key): move[key] = ability[key] if not ability[key] is String else str(ability[key]).left(96)
		move.additional_types = ability.get("additional", []).slice(0, 12).map(func(item): return str(item.get("type", "unknown")).left(40) if item is Dictionary else "invalid")
		move.enchant_keys = Array(ability.get("enchant", {}).keys()).slice(0, 12)
		move.enchant_ap = ability.get("enchant", {}).get("ap", 0)
		moves.append(move)
	result.abilities = moves
	return result

func snapshot(state: Dictionary) -> Dictionary:
	var player = state.get("player", {})
	var foe = state.get("foe", {})
	var observations = []
	var prefix = "%d:%d:" % [int(player.get("id", -1)), int(foe.get("id", -1))]
	for key in host.history.get("damage", {}):
		if str(key).begins_with(prefix) and observations.size() < 20:
			observations.append({"ability_id":int(str(key).get_slice(":", 2)), "damage":host.history.damage[key], "uncertainty":host.history.get("damage_uncertainty", {}).get(key, 1)})
	return {"player":member(player), "foe":member(foe), "capture_chance":state.get("capture_chance"), "attacks":host.history.get("attacks", 0), "capture_attempted":host.capture_attempted, "capture_succeeded":host.capture_succeeded, "flee_flag":host.history.get("flee", false), "flee_non_target":host.history.get("flee_non_target", false), "damage_risk":host.history.get("target_damage_risk", false), "observed_damage":observations, "pending":host.pending, "turn":"own" if not player.is_empty() and host.next_turn == player.get("user_id") else "other_or_unknown"}

func matches(foes: Array) -> Array:
	var found = []
	var visible = host.config.get("miscrits", [])
	var replacements = host.config.get("replacement_names", [])
	var effective = host.hunt_names()
	for name in visible + replacements:
		var entry = host.catalog.by_name.get(name, {})
		if entry.is_empty() or found.any(func(item): return item.name == name): continue
		var aliases = entry.get("names", [entry.name]).map(func(alias): return str(alias).to_lower())
		if not foes.any(func(foe): return foe is Dictionary and (int(foe.get("mId", -1)) == int(entry.id) or str(foe.get("name", "")).to_lower() in aliases)): continue
		found.append({"name":name, "species_id":int(entry.id), "visible_target":name in visible, "replacement_selected":name in replacements, "effective_hunt_target":name in effective, "family_complete":host.rotation.completed(Server.Player, int(entry.id))})
	return found

func record(phase: String, state: Dictionary = {}, decision: Dictionary = {}, response: Dictionary = {}) -> bool:
	if not error.is_empty(): return false
	if host.config.get("campaign_enabled", false) or host.match_id.is_empty(): return false
	var key = host.match_id
	if not cases.has(key):
		var foes = state.get("foes", [state.get("foe", {})])
		var selected = matches(foes)
		if selected.is_empty(): return false
		DirAccess.make_dir_recursive_absolute(directory())
		var existing = Array(DirAccess.get_files_at(directory())).filter(func(name): return name.ends_with(".json"))
		if existing.size() >= MAX_CASES:
			error = "Target diagnostics reached 64 cases; archive the diagnostic folder to record more."
			return false
		ordinal += 1
		var reference = "target-%d-%d-%03d" % [int(Time.get_unix_time_from_system()), OS.get_process_id(), ordinal]
		var rules = {}
		for name in ["combat_mode", "target_mode", "min_rating", "other_min_rating", "capture_low_rating_targets", "capture_threshold", "max_attacks", "flee_non_targets", "min_player_hp_percent", "min_target_hp_percent", "damage_margin", "train_selected"]:
			rules[name] = host.config.get(name)
		var location = {}
		for name in ["location", "area_id", "object_id", "search_mode", "evidence"]:
			if host.name_active.has(name): location[name] = host.name_active[name]
		if not location.has("object_id"): location.object_id = host.active_object_id
		cases[key] = {"schema":1, "reference":reference, "client":"desktop", "started_utc":Time.get_datetime_string_from_system(true), "targets":selected, "rules":rules, "search":location, "encounter":foes.slice(0, 4).map(func(foe): return member(foe) if foe is Dictionary else {"invalid":true}), "events":[], "older_events_omitted":0}
		# Keep only current case state in memory. Existing files remain untouched.
		for previous in cases.keys():
			if previous != key:
				cases.erase(previous)
				last_states.erase(previous)
	var item = cases[key]
	if not state.is_empty(): last_states[key] = snapshot(state)
	var event = {"phase":phase, "utc":Time.get_datetime_string_from_system(true), "action":str(decision.get("action", "")), "reason":str(decision.get("reason", "")).left(600)}
	if decision.has("id"): event.ability_id = decision.id
	if last_states.has(key): event.state = last_states[key]
	if not response.is_empty(): event.response = response
	item.events.append(event)
	while item.events.size() > 32 or (JSON.stringify(item).to_utf8_buffer().size() > MAX_BYTES and item.events.size() > 1):
		item.events.pop_front()
		item.older_events_omitted += 1
	if JSON.stringify(item).to_utf8_buffer().size() > MAX_BYTES:
		error = "Target diagnostic exceeds its case size limit."
		return false
	var body = "# Target capture diagnostic: %s\n\nClient: desktop. Times: UTC.\n\n" % item.reference
	body += "This records decisions and acknowledgements; an action_sent entry alone does not prove a successful flee.\n\n"
	body += "## Encounter and settings\n\n```json\n" + JSON.stringify({"targets":item.targets, "rules":item.rules, "search":item.search, "encounter":item.encounter}, "  ") + "\n```\n\n## Timeline\n\n"
	for entry in item.events:
		body += "- %s | %s | %s | %s%s\n" % [entry.utc, entry.phase, entry.action, entry.reason.replace("\n", " "), " | response " + JSON.stringify(entry.response) if entry.has("response") else ""]
	body += "\nOlder events omitted: %d. Full retained snapshots: [%s.json](%s.json).\n" % [item.older_events_omitted, item.reference, item.reference]
	body += "\n## Latest snapshot\n\n```json\n" + JSON.stringify(last_states.get(key, {}), "  ") + "\n```\n"
	for extension in ["json", "md"]:
		var target = directory().path_join(item.reference + "." + extension)
		var file = FileAccess.open(target + ".tmp", FileAccess.WRITE)
		if file == null:
			error = "Could not save target diagnostics; automation behavior was not changed."
			return false
		file.store_string(JSON.stringify(item) if extension == "json" else body)
		file.flush()
		var status = file.get_error()
		file.close()
		if status != OK or DirAccess.rename_absolute(target + ".tmp", target) != OK:
			error = "Could not finish saving target diagnostics."
			return false
	return true
